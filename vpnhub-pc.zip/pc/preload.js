'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
  call: (name, ...args) => ipcRenderer.invoke('call', name, args),
  onState: (cb) => ipcRenderer.on('state', (_e, s) => cb(s))
});
