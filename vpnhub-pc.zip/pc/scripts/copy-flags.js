'use strict';
// Копирует SVG-флаги из пакета flag-icons в renderer/flags (Windows не рисует эмодзи-флаги, показывает буквы).
const fs = require('fs');
const path = require('path');
try {
  const src = path.join(__dirname, '..', 'node_modules', 'flag-icons', 'flags', '4x3');
  const dst = path.join(__dirname, '..', 'renderer', 'flags');
  fs.mkdirSync(dst, { recursive: true });
  let n = 0;
  for (const f of fs.readdirSync(src)) { if (f.endsWith('.svg')) { fs.copyFileSync(path.join(src, f), path.join(dst, f)); n++; } }
  console.log('flags copied:', n);
} catch (e) { console.log('flags skipped:', e.message); }
