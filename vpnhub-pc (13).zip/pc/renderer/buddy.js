'use strict';
const $ = (s) => document.querySelector(s);
const buddy = $('#buddy'), bubble = $('#bubble'), fx = $('#fx');
const api = window.buddyApi;
let manual = 'sit', aware = '', hugging = false, petting = false, petMove = 0, petTimer = null, petSince = 0, heartTimer = null, bubbleTimer = null, lastHit = false, lastMeow = 0;

const SAY = {
  tea: ['ооо, ютуб! я с чаем 🍵', 'смотрим вместе? я укутался 🧣', 'чай, плед и видосики… идеально 💗'],
  read: ['ой, а что это вы там пишете… 👀', 'я не подсматриваю! почти… 🫣', 'так, кто тебе пишет?? 👀'],
  shy: ['я не смотрю!! 🙈', 'ой-ой, что ты открыл!! 😳', 'я закрыл глазки!! >///<'],
  idle: ['привет, фембойчек! 💗', 'погладь меня 🥺', 'UwU', 'мурр~ 🐾', 'как твой впн? быстро?']
};
const pick = (a) => a[Math.floor(Math.random() * a.length)];

function say(t, ms) {
  bubble.textContent = t; bubble.classList.add('show');
  clearTimeout(bubbleTimer); bubbleTimer = setTimeout(() => bubble.classList.remove('show'), ms || 3200);
}
function heart() {
  const h = document.createElement('span'); h.className = 'heart'; h.textContent = '❤';
  h.style.left = (70 + Math.random() * 150) + 'px'; fx.appendChild(h); setTimeout(() => h.remove(), 1300);
}

// ---- звуки (синтез, как у котика) ----
let actx = null, purrNode = null;
function audio() { if (!actx) { try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return null; } } if (actx.state === 'suspended') actx.resume(); return actx; }
function meow() {
  const c = audio(); if (!c) return;
  const t = c.currentTime, pitch = 1.05 + Math.random() * 0.3, dur = 0.5 + Math.random() * 0.2;
  const osc = c.createOscillator(); osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(460 * pitch, t); osc.frequency.linearRampToValueAtTime(860 * pitch, t + dur * 0.3); osc.frequency.linearRampToValueAtTime(600 * pitch, t + dur * 0.75); osc.frequency.linearRampToValueAtTime(420 * pitch, t + dur);
  const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 2; bp.frequency.setValueAtTime(900, t); bp.frequency.linearRampToValueAtTime(2100, t + dur * 0.35); bp.frequency.linearRampToValueAtTime(1000, t + dur);
  const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.7, t + 0.06); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.connect(bp); bp.connect(g); g.connect(c.destination); osc.start(t); osc.stop(t + dur + 0.05);
}
function purrStart() {
  const c = audio(); if (!c || purrNode) return;
  const len = c.sampleRate * 2, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0); let last = 0;
  for (let i = 0; i < len; i++) { last = (last + 0.02 * (Math.random() * 2 - 1)) / 1.02; d[i] = last * 4; }
  const src = c.createBufferSource(); src.buffer = buf; src.loop = true;
  const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 420;
  const am = c.createGain(); am.gain.value = 0.5; const lfo = c.createOscillator(); lfo.frequency.value = 25;
  const lg = c.createGain(); lg.gain.value = 0.5; lfo.connect(lg); lg.connect(am.gain);
  const master = c.createGain(); master.gain.setValueAtTime(0.0001, c.currentTime); master.gain.linearRampToValueAtTime(1, c.currentTime + 0.25);
  src.connect(lp); lp.connect(am); am.connect(master); master.connect(c.destination); src.start(); lfo.start(); purrNode = { src, lfo, master };
}
function purrStop() {
  if (!purrNode || !actx) return; const { src, lfo, master } = purrNode; purrNode = null; const t = actx.currentTime;
  master.gain.cancelScheduledValues(t); master.gain.setValueAtTime(master.gain.value, t); master.gain.linearRampToValueAtTime(0.0001, t + 0.3); src.stop(t + 0.35); lfo.stop(t + 0.35);
}

// ---- состояние ----
let current = '';
function effective() { if (aware === 'shy') return 'shy'; if (hugging) return 'hug'; if (aware) return aware; return manual; }
function render() {
  const e = effective();
  buddy.className = e + (petting ? ' pet' : '') + (buddy.classList.contains('hover') ? ' hover' : '');
  if (e !== current) {
    current = e;
    if (SAY[e]) say(pick(SAY[e]), 4200);
    else if (e === 'lie') say('zzz… ладно, полежу 😴', 2600);
    else if (e === 'sit') say('сижу 💗', 1800);
    else if (e === 'hug') say('поймал!! не отпущу 🥺', 3000);
  }
}
function setPet(on) {
  if (on === petting) return;
  petting = on;
  if (on) { petSince = Date.now(); purrStart(); say('мурр~ 💗', 2200); heart(); heartTimer = setInterval(heart, 380); }
  else { purrStop(); clearInterval(heartTimer); petSince = 0; }
  render();
}

// ---- события от главного процесса ----
if (api) api.onEvent((d) => {
  if (d.t === 'mode') { aware = d.v || ''; render(); }
  else if (d.t === 'hug') {
    hugging = !!d.on; render();
    if (!d.on) say(d.escaped ? 'ой… вырвался 🥺 приходи ещё!' : 'ладно, отпускаю 💗', 3200);
  } else if (d.t === 'cursor') {
    if (!hugging && (current === 'sit')) {
      const dx = d.x - 150; $('.look').style.setProperty('--look', Math.max(-9, Math.min(9, dx / 40)) + 'deg');
    }
    if (hugging && d.hp > 0.5 && Math.random() < 0.05) say('не вырывайся… 🥺', 1200);
  }
});

// ---- мышь: прозрачные места пропускают клики, на персонаже и меню — ловим ----
document.addEventListener('mousemove', (e) => {
  const el = document.elementFromPoint(e.clientX, e.clientY);
  const hit = !!(el && el.closest && el.closest('.hit'));
  if (hit !== lastHit) { lastHit = hit; buddy.classList.toggle('hover', hit); if (api) api.call('interactive', hit); }
  if (el && el.closest && el.closest('#char')) {
    petMove += Math.abs(e.movementX) + Math.abs(e.movementY);
    if (petMove > 160) setPet(true);
    if (petting) { clearTimeout(petTimer); petTimer = setTimeout(() => setPet(false), 700); }
  }
});
document.addEventListener('mouseleave', () => { setPet(false); lastHit = false; buddy.classList.remove('hover'); if (api) api.call('interactive', false); });
setInterval(() => { petMove = Math.max(0, petMove - 30); if (petting && petSince && Date.now() - petSince > 5500 && !hugging && api) { setPet(false); api.call('hug'); } }, 200);
$('#char').addEventListener('click', () => { heart(); const n = Date.now(); if (n - lastMeow > 450) { lastMeow = n; meow(); } say(pick(['мяу!', 'мур?', 'мрр 💗', '🐾', 'ой! щекотно~']), 1600); });
$('#menu').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  const c = b.dataset.c;
  if (c === 'sit' || c === 'lie') { manual = c; render(); }
  else if (c === 'hug') { if (api) api.call('hug'); }
  else if (c === 'bye') { say('пока-пока 👋', 800); setTimeout(() => api && api.call('close'), 600); }
});
setInterval(() => { if (!aware && !hugging && !petting && Math.random() < 0.25) say(pick(SAY.idle), 3000); }, 22000);
render(); setTimeout(() => say(pick(SAY.idle), 3500), 700);
