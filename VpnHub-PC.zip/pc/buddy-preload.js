'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('buddyApi', {
  call: (name, ...args) => ipcRenderer.invoke('buddy-call', name, args),
  onEvent: (cb) => ipcRenderer.on('buddy-evt', (_e, d) => cb(d))
});
