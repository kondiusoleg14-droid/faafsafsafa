'use strict';
// ---------- вспомогательное ----------
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const flagify = (h) => h.replace(/([\u{1F1E6}-\u{1F1FF}])([\u{1F1E6}-\u{1F1FF}])/gu, (m, a, b) => {
  const c = (x) => String.fromCharCode(x.codePointAt(0) - 0x1F1E6 + 97);
  return `<img class="flag" src="flags/${c(a)}${c(b)}.svg" alt="${c(a)}${c(b)}">`;
});
const fl = (s) => flagify(esc(s));
const POWER = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v9"/><path d="M6.4 6.7a8 8 0 1 0 11.2 0"/></svg>';
const GRADS = [['Закат', [255, 122, 89], [142, 45, 226]], ['Океан', [0, 198, 255], [0, 82, 212]], ['Лес', [56, 239, 125], [11, 110, 79]],
  ['Роза', [255, 111, 216], [56, 19, 194]], ['Лава', [255, 81, 47], [221, 36, 118]], ['Лёд', [161, 196, 253], [91, 108, 255]]];
const ACCENTS = ['6C7BFF', '9B5CFF', '2ED3A0', '3AA0FF', 'FF7A59', 'FF4D8D', 'F5C542', 'FF5A5A'];


// ---------- пасхалка: котик (10 нажатий на название) ----------
const CAT_SVG = '<svg viewBox="0 0 140 150" width="120" height="129" xmlns="http://www.w3.org/2000/svg">' +
  '<path class="tail" d="M102 130 C136 130 142 92 122 84" stroke="#E8964A" stroke-width="12" fill="none" stroke-linecap="round"/>' +
  '<ellipse cx="70" cy="112" rx="38" ry="34" fill="#F2A65A"/><ellipse cx="70" cy="122" rx="22" ry="22" fill="#FBE3C4"/>' +
  '<ellipse cx="54" cy="142" rx="11" ry="7" fill="#FBE3C4"/><ellipse cx="86" cy="142" rx="11" ry="7" fill="#FBE3C4"/>' +
  '<g class="head">' +
  '<polygon points="44,42 47,12 68,32" fill="#F2A65A"/><polygon points="96,42 93,12 72,32" fill="#F2A65A"/>' +
  '<polygon points="49,35 51,20 62,31" fill="#F7B7B0"/><polygon points="91,35 89,20 78,31" fill="#F7B7B0"/>' +
  '<circle cx="70" cy="62" r="32" fill="#F2A65A"/>' +
  '<path d="M70 32v10M60 34l2 8M80 34l-2 8" stroke="#D98339" stroke-width="3" stroke-linecap="round" fill="none"/>' +
  '<circle class="blush" cx="48" cy="72" r="6" fill="#F28B9B"/><circle class="blush" cx="92" cy="72" r="6" fill="#F28B9B"/>' +
  '<g class="eo"><ellipse class="eye" cx="57" cy="60" rx="8" ry="9" fill="#fff"/>' +
  '<g class="pup" data-x="57" data-y="60" transform="translate(57,60)"><circle r="4.6" fill="#222"/><circle cx="-1.6" cy="-1.8" r="1.5" fill="#fff"/></g>' +
  '<ellipse class="eye" cx="83" cy="60" rx="8" ry="9" fill="#fff"/>' +
  '<g class="pup" data-x="83" data-y="60" transform="translate(83,60)"><circle r="4.6" fill="#222"/><circle cx="-1.6" cy="-1.8" r="1.5" fill="#fff"/></g></g>' +
  '<g class="ec"><path d="M49 61Q57 69 65 61M75 61Q83 69 91 61" stroke="#5a3a1a" stroke-width="2.6" stroke-linecap="round" fill="none"/></g>' +
  '<path d="M66 71h8l-4 5z" fill="#E7777F"/>' +
  '<path d="M70 76q-5 6-10 2M70 76q5 6 10 2" stroke="#5a3a1a" stroke-width="1.8" stroke-linecap="round" fill="none"/>' +
  '<path d="M50 74L26 70M50 78L26 80M90 74L114 70M90 78L114 80" stroke="#fff" stroke-opacity=".85" stroke-width="1.5" stroke-linecap="round"/>' +
  '</g></svg>';


// ---------- пасхалка: UwU-оформление (слово в поле «Подмена SNI») ----------
const PAW = '<svg viewBox="0 0 100 100" fill="currentColor"><path d="M50 52c-14 0-26 12-26 24 0 9 7 14 15 14 5 0 8-2 11-2s6 2 11 2c8 0 15-5 15-14 0-12-12-24-26-24z"/><ellipse cx="21" cy="47" rx="9" ry="12" transform="rotate(-22 21 47)"/><ellipse cx="40" cy="30" rx="9" ry="13"/><ellipse cx="60" cy="30" rx="9" ry="13"/><ellipse cx="79" cy="47" rx="9" ry="12" transform="rotate(22 79 47)"/></svg>';
const FEM_TILE = '<svg xmlns="http://www.w3.org/2000/svg" width="130" height="130"><g fill="#FF8FC8" opacity="0.28">' +
  '<path d="M32 40c-10-9-16-15-16-22 0-6 4-9 9-9 3 0 6 2 7 4 1-2 4-4 7-4 5 0 9 3 9 9 0 7-6 13-16 22z"/>' +
  '<circle cx="92" cy="86" r="9"/><circle cx="76" cy="72" r="4.5"/><circle cx="88" cy="68" r="4.5"/><circle cx="100" cy="72" r="4.5"/></g></svg>';
const svgUri = (x) => 'data:image/svg+xml;utf8,' + encodeURIComponent(x);

// ---------- палитра (порт Ui.kt) ----------
function parseHex(s) { s = String(s || '').trim().replace(/^#/, ''); if (!/^[0-9a-fA-F]{6}$/.test(s)) return null; return [0, 2, 4].map((i) => parseInt(s.slice(i, i + 2), 16)); }
const lerp = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
const lum = (c) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
const rgb = (c, a) => (a === undefined ? `rgb(${c.join(',')})` : `rgba(${c.join(',')},${a})`);
function shiftHue(c) {
  const r = c[0] / 255, g = c[1] / 255, b = c[2] / 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
  let h = 0;
  if (d) { if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; if (h < 0) h += 360; }
  const s = mx === 0 ? 0 : d / mx, v = mx;
  h = (h + 35) % 360;
  const k = (n) => (n + h / 60) % 6;
  const f = (n) => v - v * s * Math.max(0, Math.min(k(n), 4 - k(n), 1));
  return [f(5), f(3), f(1)].map((x) => Math.round(x * 255));
}
function palette(ui, sysDark) {
  let light = false, bg = parseHex('0B0F1A'), card = parseHex('151B2B');
  if (ui.mode === 'light') light = true;
  else if (ui.mode === 'system') light = !sysDark;
  else if (ui.mode === 'custom') { bg = parseHex(ui.customBg) || bg; card = parseHex(ui.customCard) || card; light = lum(bg) > 0.5; }
  if (ui.mode === 'light' || (ui.mode === 'system' && light)) { bg = parseHex('F2F4FA'); card = [255, 255, 255]; }
  let text = light ? [20, 26, 46] : [255, 255, 255];
  let dim = light ? [102, 112, 134] : [138, 147, 168];
  let green = light ? [18, 163, 124] : [46, 211, 160];
  const custom = parseHex(ui.accent);
  let accent = custom || (light ? [79, 93, 255] : [108, 123, 255]);
  let accent2 = custom ? shiftHue(custom) : (light ? [138, 77, 255] : [155, 92, 255]);
  let on2 = [26, 163, 122];
  if (ui.femboy) { light = true; bg = [255, 226, 240]; card = [255, 255, 255]; text = [88, 24, 69]; dim = [170, 98, 140]; green = [255, 79, 163]; accent = [255, 105, 180]; accent2 = [190, 130, 255]; on2 = [255, 154, 203]; }
  else if (ui.scorpion) { light = false; bg = [10, 7, 6]; card = [28, 18, 16]; text = [255, 231, 194]; dim = [185, 139, 94]; green = [255, 194, 26]; accent = [255, 106, 0]; accent2 = [224, 35, 27]; on2 = [255, 106, 0]; }
  return {
    light, bg, text, dim, green, accent, accent2, on2,
    card: rgb(card, ui.cardAlpha), sheet: lerp(bg, card, 0.5), sel: lerp(card, accent, 0.28), chip: lerp(card, text, 0.10), hdr: lerp(card, accent, 0.12)
  };
}

// ---------- группы ----------
function groupsOf(list) {
  const m = new Map();
  for (const s of list) { if (!m.has(s.gkey)) m.set(s.gkey, { key: s.gkey, name: s.clean, items: [] }); m.get(s.gkey).items.push(s); }
  return [...m.values()];
}
const pickTarget = (g) => (g.items.length > 1 ? 'g:' + g.key : g.items[0].id);

function groupHtml(S, g) {
  const sel = S.selected;
  const groupSel = sel === 'g:' + g.key;
  const here = groupSel || (sel && (sel.startsWith('gk:' + g.key + '|') || g.items.some((i) => i.id === sel)));
  const kinds = new Map();
  for (const it of g.items) { if (!kinds.has(it.kind)) kinds.set(it.kind, []); kinds.get(it.kind).push(it); }
  let chips = '';
  for (const [kind, list] of kinds) {
    const target = list.length === 1 ? list[0].id : 'gk:' + g.key + '|' + kind;
    const pings = list.filter((i) => !i.isUdp).map((i) => S.pings[i.id]).filter((p) => p !== undefined && p >= 0);
    const ping = pings.length ? Math.min(...pings) : null;
    chips += `<span class="chip ${sel === target ? 'sel' : ''}" data-act="pick" data-t="${esc(target)}">${esc(list.length > 1 ? kind + ' ×' + list.length : kind)}${ping !== null ? `<span class="p">${ping} мс</span>` : ''}</span>`;
  }
  return `<div class="card grp ${here ? 'sel' : ''}"><div class="grow"><div class="gname" data-act="pick" data-t="${esc(pickTarget(g))}">${fl(g.name)}</div><button class="x" data-act="rmg" data-k="${esc(g.key)}" title="Удалить">✕</button></div>` +
    (groupSel ? `<div class="acc sm" style="padding-bottom:6px">авто: само выберет рабочий из ${g.items.length}</div>` : '') + `<div class="chips">${chips}</div></div>`;
}

function serversHtml(S) {
  const sv = S.servers;
  let h = '<div class="row gap wrap"><button class="btn pri" data-act="addopen">+ Добавить</button><button class="btn" data-act="ping">Пинг</button><button class="btn" data-act="copylist">Список</button></div>';
  if (S.busy) h += '<div class="prog"><i></i></div>';
  if (!S.subs.length && !sv.length) h += '<p class="dim">Нажми «+ Добавить» и вставь ключ или ссылку подписки — приложение само разберётся, что это.</p>';
  if (sv.length) h += `<div class="card auto ${S.selected === 'auto' ? 'sel' : ''}" data-act="pick" data-t="auto"><div>⚡ Авто</div><div class="sm ${S.selected === 'auto' ? 'acc' : 'dim'}">Сам выбирает рабочий сервер из всех${S.selected === 'auto' ? ' • по умолчанию' : ''}</div></div>`;
  const known = new Set(S.subs.map((s) => s.id));
  for (const sub of S.subs) {
    const groups = groupsOf(sv.filter((s) => s.subId === sub.id));
    const total = groups.reduce((a, g) => a + g.items.length, 0);
    h += `<div class="sub"><div><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">📡 ${fl(sub.name)}</div><div class="dim sm">Серверов: ${groups.length} · подключений: ${total}</div></div><button class="btn" data-act="refresh" data-id="${esc(sub.id)}">Обновить</button><button class="x" data-act="rmsub" data-id="${esc(sub.id)}">✕</button></div>`;
    if (!groups.length && S.subInfo[sub.id]) h += `<div class="warn">${esc(S.subInfo[sub.id])}</div>`;
    h += groups.map((g) => groupHtml(S, g)).join('');
  }
  const own = groupsOf(sv.filter((s) => !s.subId || !known.has(s.subId)));
  if (own.length) h += '<div class="sub"><div>🔑 Отдельные ключи</div></div>' + own.map((g) => groupHtml(S, g)).join('');
  return h;
}

// ---------- правила для программ ----------
function targetOptions(S, current) {
  const groups = groupsOf(S.servers);
  let h = `<option value="default" ${!current ? 'selected' : ''}>По умолчанию</option><option value="direct" ${current === 'direct' ? 'selected' : ''}>Напрямую (без VPN)</option>`;
  let found = !current || current === 'direct';
  for (const g of groups) {
    const v = pickTarget(g);
    if (v === current) found = true;
    h += `<option value="${esc(v)}" ${v === current ? 'selected' : ''}>${esc(g.name + (g.items.length > 1 ? ' (авто)' : ''))}</option>`;
  }
  if (!found) h += `<option value="${esc(current)}" selected>${esc(current)}</option>`;
  return h;
}
function appsHtml(S, procs) {
  let h = '<p class="dim sm">Здесь можно отправить отдельную программу через другой сервер (или мимо VPN). Правила работают по имени программы, например <b>chrome.exe</b>. Остальные программы идут через сервер по умолчанию. Изменения применяются сами, если VPN включён.</p>';
  h += `<div class="card cardp" style="padding:12px"><input type="text" id="procin" list="proclist" placeholder="Имя программы, например chrome.exe"><datalist id="proclist">${procs.map((p) => `<option value="${esc(p)}">`).join('')}</datalist>` +
    `<div style="height:8px"></div><select id="proctarget">${targetOptions(S, '').replace(/<option value="default"[^>]*>[^<]*<\/option>/, '')}</select>` +
    '<div class="row gap wrap" style="margin-top:8px"><button class="btn" data-act="loadprocs">↻ Запущенные программы</button><button class="btn pri" data-act="addrule">Добавить правило</button></div></div>';
  const names = Object.keys(S.rules);
  if (!names.length) h += '<p class="dim">Правил пока нет.</p>';
  for (const p of names) h += `<div class="card rule"><div class="n" title="${esc(p)}">${esc(p)}</div><select data-chg="rule" data-p="${esc(p)}">${targetOptions(S, S.rules[p])}</select><button class="x" data-act="rmrule" data-p="${esc(p)}">✕</button></div>`;
  return h;
}

// ---------- настройки ----------
const trow = (title, desc, attrs, checked) => `<label class="trow"><div><div>${esc(title)}</div><div class="dim sm">${esc(desc)}</div></div><input type="checkbox" class="tg" ${attrs} ${checked ? 'checked' : ''}></label>`;
const opt = (label, k, v, cur) => `<span class="opt ${cur === v ? 'sel' : ''}" data-act="ui" data-k="${k}" data-v="${v}">${esc(label)}</span>`;
const slider = (title, k, min, max, step, val, label) => `<div style="margin-top:6px"><div class="row"><div style="flex:1">${esc(title)}</div><span class="dim sm" id="lbl-${k}">${esc(label)}</span></div><input type="range" data-inp="ui" data-k="${k}" min="${min}" max="${max}" step="${step}" value="${val}"></div>`;

function connHtml(S, x) {
  let h = trow('Запускать подключение при старте', 'Программа сама включит VPN при открытии', 'data-chg="uiBool" data-k="autoConnect"', S.ui.autoConnect);
  h += trow('Не закрывать в трее', 'Крестик сворачивает окно в трей, VPN продолжает работать', 'data-chg="uiBool" data-k="trayClose"', S.ui.trayClose);
  h += trow('Сайты .ru напрямую', 'Домены .ru, .su, .рф идут мимо VPN', 'data-chg="opt" data-k="ruDirect"', S.opts.ruDirect);
  h += trow('Авто: сначала обычные серверы (TCP)', 'Hysteria2 по UDP часто режется провайдером — видео грузится долго. «Авто» и группы выбирают среди обычных серверов; Hysteria2 можно выбрать вручную', 'data-chg="opt" data-k="preferTcp"', S.opts.preferTcp);
  h += trow('Отключить IPv6', 'Убирает зависания, когда сайт (например YouTube в Chrome) пытается открыться по IPv6, которого нет у сервера', 'data-chg="opt" data-k="blockIpv6"', S.opts.blockIpv6);
  h += trow('Блокировать QUIC (UDP 443)', 'Рекомендуется: программы переходят на обычный HTTPS, это быстрее и стабильнее', 'data-chg="opt" data-k="blockQuic"', S.opts.blockQuic);
  h += `<div class="h">Подмена SNI</div><input type="text" id="sni" data-chg="sni" placeholder="Например: www.microsoft.com (пусто — не менять)" value="${esc(S.opts.sni)}"><p class="dim sm">Для серверов с TLS (не Reality). Нужна, если провайдер блокирует по имени сайта. Меняется только после переподключения.</p>`;
  h += '<div class="h">Режим</div><p class="dim sm">Работает через виртуальный адаптер (TUN) — перехватывает весь трафик компьютера, поэтому программа запускается от имени администратора.</p>';
  h += '<div class="h">Диагностика</div><div class="row gap wrap"><button class="btn pri" data-act="nettest">Проверить интернет</button><button class="btn" data-act="showlog">Журнал ядра</button></div>';
  if (x.net) h += `<pre class="log">${esc(x.net)}</pre><button class="btn" data-act="copynet">Скопировать результат</button>`;
  if (x.log !== null) h += `<pre class="log">${esc(x.log || '(пусто)')}</pre><div class="row gap"><button class="btn" data-act="showlog">Обновить</button><button class="btn" data-act="copylog">Скопировать</button></div>`;
  return h;
}
function looksHtml(S) {
  const u = S.ui;
  let h = '<div class="h" style="margin-top:6px">Тема</div><div class="scroll">' + opt('Системная', 'mode', 'system', u.mode) + opt('Тёмная', 'mode', 'dark', u.mode) + opt('Светлая', 'mode', 'light', u.mode) + opt('Своя', 'mode', 'custom', u.mode) + '</div>';
  if (u.mode === 'custom') {
    h += `<div style="margin-top:6px"><input type="text" data-chg="uiText" data-k="customBg" class="${parseHex(u.customBg) ? '' : 'bad'}" placeholder="Цвет фона (HEX), например 0B0F1A" value="${esc(u.customBg)}"></div>`;
    h += `<div style="margin-top:6px"><input type="text" data-chg="uiText" data-k="customCard" class="${parseHex(u.customCard) ? '' : 'bad'}" placeholder="Цвет карточек (HEX)" value="${esc(u.customCard)}"></div>`;
  }
  h += '<div class="h">Цвет акцента</div><div class="scroll"><div class="sw2 ' + (!u.accent ? 'sel' : '') + '" style="background:var(--chip)" data-act="ui" data-k="accent" data-v="">авто</div>' +
    ACCENTS.map((a) => `<div class="sw2 ${u.accent.toUpperCase() === a ? 'sel' : ''}" style="background:#${a}" data-act="ui" data-k="accent" data-v="${a}"></div>`).join('') + '</div>';
  h += '<div class="h">Фон</div><div class="scroll">';
  h += `<div class="tile ${u.bgKind === 'none' ? 'sel' : ''}" data-act="ui" data-k="bgKind" data-v="none"><div class="t">∅</div>Нет</div>`;
  GRADS.forEach((g, i) => { h += `<div class="tile ${u.bgKind === 'grad' + i ? 'sel' : ''}" data-act="ui" data-k="bgKind" data-v="grad${i}"><div class="t" style="background:linear-gradient(180deg,${rgb(g[1])},${rgb(g[2])})"></div>${esc(g[0])}</div>`; });
  if (u.bgFile && u.bgUrl) h += `<div class="tile ${u.bgKind === 'image' ? 'sel' : ''}" data-act="ui" data-k="bgKind" data-v="image"><div class="t" style="background-image:url('${esc(u.bgUrl)}')"></div>Моё фото</div>`;
  h += '<div class="tile" data-act="pickbg"><div class="t">🖼</div>Выбрать…</div></div>';
  h += '<p class="dim sm">«Выбрать…» открывает окно выбора файла: любая картинка JPG, PNG или WEBP.</p>';
  if (u.bgKind !== 'none') h += slider('Затемнение фона', 'dim', 0, 0.85, 0.01, u.dim, Math.round(u.dim * 100) + '%');
  if (u.bgKind === 'image') h += slider('Размытие фона', 'blur', 0, 30, 1, u.blur, String(Math.round(u.blur)));
  h += '<div class="h">Кнопка подключения</div><div class="scroll">' + opt('Кнопка', 'control', 'button', u.control) + opt('Тумблер', 'control', 'switch', u.control) + '</div>';
  h += '<div class="h">Карточки</div>' + slider('Прозрачность', 'cardAlpha', 0.25, 1, 0.01, u.cardAlpha, Math.round(u.cardAlpha * 100) + '%') + slider('Скругление углов', 'corner', 0.2, 1.8, 0.05, u.corner, Math.round(u.corner * 100) + '%');
  h += `<div class="h">Название вверху окна</div><input type="text" data-chg="uiText" data-k="title" maxlength="24" value="${esc(u.title)}">`;
  h += '<div style="margin-top:16px"><button class="btn" data-act="resetui">Сбросить оформление</button></div><p class="dim sm">Оформление не переподключает VPN.</p>';
  return h;
}
function settingsHtml(S, tab, x) {
  return `<div class="tabs"><span class="opt ${tab === 0 ? 'sel' : ''}" data-act="tab" data-v="0">Подключение</span><span class="opt ${tab === 1 ? 'sel' : ''}" data-act="tab" data-v="1">Оформление</span></div>` + (tab === 0 ? connHtml(S, x) : looksHtml(S));
}

// ---------- работа в окне ----------
if (typeof document !== 'undefined') {
  const $ = (id) => document.getElementById(id);
  let S = null, sheet = null, tab = 0, procs = [], netText = '', logText = null;
  const sysMq = window.matchMedia('(prefers-color-scheme: dark)');

  function toast(m) { const t = $('toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 4200); }
  async function call(name, ...a) { const r = await window.api.call(name, ...a); if (r && r.error) { toast('Ошибка: ' + r.error); return null; } if (r && r.msg) toast(r.msg); return r; }

  function applyTheme() {
    const p = palette(S.ui, sysMq.matches);
    const r = document.documentElement.style;
    r.setProperty('--bg', rgb(p.bg)); r.setProperty('--card', p.card); r.setProperty('--sheet', rgb(p.sheet)); r.setProperty('--sel', rgb(p.sel));
    r.setProperty('--chip', rgb(p.chip)); r.setProperty('--hdr', rgb(p.hdr)); r.setProperty('--text', rgb(p.text)); r.setProperty('--dim', rgb(p.dim));
    r.setProperty('--accent', rgb(p.accent)); r.setProperty('--accent2', rgb(p.accent2)); r.setProperty('--green', rgb(p.green)); r.setProperty('--on2', rgb(p.on2)); r.setProperty('--r', String(S.ui.corner));
    const img = $('bgimg'), dim = $('bgdim'); const u = S.ui;
    img.style.backgroundImage = 'none'; img.style.filter = 'none'; img.style.transform = 'none';
    img.style.backgroundRepeat = ''; img.style.backgroundSize = ''; img.style.backgroundPosition = '';
    dim.style.background = 'transparent';
    const femBg = !!u.femboy && !(u.bgKind === 'image' && u.bgUrl);
    const mkBg = !!u.scorpion && !u.femboy && !(u.bgKind === 'image' && u.bgUrl);
    if (femBg) {
      img.style.backgroundImage = `url("boy.png"), url("${svgUri(FEM_TILE)}"), linear-gradient(180deg,#FFE3F1,#FFC4E3)`;
      img.style.backgroundRepeat = 'no-repeat, repeat, no-repeat';
      img.style.backgroundSize = 'min(82%, 440px) auto, 130px 130px, cover';
      img.style.backgroundPosition = 'center 64%, 0 0, center';
    } else if (mkBg) {
      img.style.backgroundImage = 'url("scorpion.jpg")';
      img.style.backgroundSize = 'cover';
      img.style.backgroundPosition = 'center top';
      dim.style.background = 'rgba(0,0,0,0.45)';
    } else if (u.bgKind === 'image' && u.bgUrl) {
      img.style.backgroundImage = `url("${u.bgUrl}")`;
      if (u.blur > 0) { img.style.filter = `blur(${u.blur}px)`; img.style.transform = 'scale(1.08)'; }
    } else if (u.bgKind.startsWith('grad')) {
      const g = GRADS[parseInt(u.bgKind.slice(4), 10)];
      if (g) img.style.backgroundImage = `linear-gradient(180deg,${rgb(lerp(p.bg, g[1], 0.55))},${rgb(lerp(p.bg, g[2], 0.55))})`;
    }
    if (!femBg && !mkBg && u.bgKind !== 'none' && !(u.bgKind === 'image' && !u.bgUrl)) dim.style.background = rgb(p.light ? [255, 255, 255] : [0, 0, 0], u.dim);
  }
  let lastIcon = '';
  function updateHome() {
    const v = S.vpn, on = v.state === 'on', busyS = v.state === 'starting' || v.state === 'stopping';
    const fem = !!S.ui.femboy;
    const mk = !!S.ui.scorpion && !fem;
    const ttl = fem ? 'только для фембойчиков UwU' : (mk ? 'GET OVER HERE!' : (S.ui.title || 'VPN Hub'));
    $('title').textContent = ttl;
    document.title = ttl;
    const sw = S.ui.control === 'switch';
    $('pbtn').classList.toggle('hide', sw); $('sw').classList.toggle('hide', !sw);
    $('pbtn').classList.toggle('on', on); $('sw').classList.toggle('on', on); $('sw').classList.toggle('mid', busyS);
    $('pbtn').classList.toggle('fem', fem && !sw);
    const icon = (busyS ? 's' : 'p') + sw + (fem ? 'f' : '');
    if (icon !== lastIcon) { lastIcon = icon; document.querySelectorAll('.ico').forEach((e) => { e.innerHTML = busyS ? '<div class="spin"></div>' : (fem ? PAW : POWER); }); }
    $('status').textContent = (v.state === 'on' ? 'Подключено' : v.state === 'starting' ? 'Подключение…' : v.state === 'stopping' ? 'Отключение…' : 'Отключено') + (fem && v.state === 'on' ? ' UwU' : '');
    if (mk && v.state === 'on') $('status').textContent = 'FLAWLESS VICTORY 🔥';
    $('status').style.color = on ? 'var(--green)' : 'var(--text)';
    $('err').textContent = v.error || '';
    $('srvname').innerHTML = fl(S.describe);
    const sel = S.selected ? S.servers.find((s) => s.id === S.selected) : null;
    $('srvkind').textContent = sel ? sel.kind : '';
    $('now').innerHTML = on && v.now ? 'Сейчас: ' + fl(v.now) : '';
  }
  const titles = { servers: 'Серверы', apps: 'Серверы для программ', settings: 'Настройки' };
  function renderSheet(fromPush) {
    if (!sheet) return;
    const body = $('sh-body');
    const ae = document.activeElement;
    if (fromPush && ae && body.contains(ae) && /INPUT|TEXTAREA|SELECT/.test(ae.tagName)) return;
    const top = body.scrollTop;
    $('sh-title').textContent = titles[sheet];
    body.innerHTML = sheet === 'servers' ? serversHtml(S) : sheet === 'apps' ? appsHtml(S, procs) : settingsHtml(S, tab, { net: netText, log: logText });
    body.scrollTop = top;
  }
  function openSheet(n) { sheet = n; $('overlay').classList.remove('hidden'); if (n === 'settings') { logText = null; } renderSheet(); if (n === 'apps' && !procs.length) loadProcs(); }
  function closeSheet() { sheet = null; $('overlay').classList.add('hidden'); }
  async function loadProcs() { const r = await window.api.call('listProcs'); if (Array.isArray(r)) { procs = r; if (sheet === 'apps') { const keep = $('procin') ? $('procin').value : ''; renderSheet(); if ($('procin')) $('procin').value = keep; } } }
  function openAdd() { $('dlg').classList.remove('hidden'); $('addtxt').value = ''; $('addtxt').focus(); }
  function closeAdd() { $('dlg').classList.add('hidden'); }
  async function doAdd() {
    const t = $('addtxt').value;
    closeAdd();
    if (sheet !== 'servers') openSheet('servers');
    await call('add', t);
  }
  const copy = async (t, m) => { try { await navigator.clipboard.writeText(t); toast(m); } catch (e) { toast('Не удалось скопировать'); } };
  function setUi(k, v) { S.ui[k] = v; applyTheme(); updateHome(); window.api.call('setUi', k, v); }

  const acts = {
    toggle: () => call('toggle'),
    sheet: (d) => openSheet(d.s),
    close: closeSheet,
    overlay: (d, e) => { if (e.target.id === 'overlay') closeSheet(); },
    addopen: openAdd, addclose: closeAdd, addgo: doAdd,
    paste: async () => { try { $('addtxt').value = await navigator.clipboard.readText(); } catch (e) { toast('Не удалось прочитать буфер — вставь через Ctrl+V'); } },
    pick: (d) => { call('select', d.t); closeSheet(); },
    rmg: (d) => call('removeGroup', d.k),
    rmsub: (d) => call('removeSub', d.id),
    refresh: (d) => call('refreshSub', d.id),
    ping: () => call('pingAll'),
    copylist: () => copy(S.servers.map((s, i) => `${i + 1}. ${s.name} | ${s.kind}`).join('\n'), 'Список серверов скопирован (' + S.servers.length + ')'),
    loadprocs: loadProcs,
    addrule: () => { const p = $('procin').value.trim(); if (!p) return toast('Впиши имя программы или выбери из списка'); call('setRule', p, $('proctarget').value); $('procin').value = ''; },
    rmrule: (d) => call('setRule', d.p, 'default'),
    tab: (d) => { tab = parseInt(d.v, 10); renderSheet(); },
    ui: (d) => { setUi(d.k, d.v); renderSheet(); },
    pickbg: () => call('pickBg'),
    resetui: async () => { await call('resetUi'); },
    nettest: async () => { netText = 'Проверяю…'; renderSheet(); const r = await window.api.call('testNet'); netText = typeof r === 'string' ? r : 'Ошибка'; renderSheet(); },
    copynet: () => copy(netText, 'Результат скопирован'),
    showlog: async () => { const r = await window.api.call('getLog'); logText = typeof r === 'string' ? r : ''; renderSheet(); },
    copylog: () => copy(logText || '', 'Журнал скопирован')
  };
  document.addEventListener('click', (e) => { const el = e.target.closest('[data-act]'); if (!el) return; const f = acts[el.dataset.act]; if (f) f(el.dataset, e); });
  document.addEventListener('change', (e) => {
    const el = e.target.closest('[data-chg]'); if (!el) return;
    const k = el.dataset.k;
    switch (el.dataset.chg) {
      case 'opt': call('setOpt', k, el.checked); break;
      case 'sni': {
        const w = el.value.toLowerCase().replace(/ё/g, 'е');
        if (/фембой(чек|чик)|femboy/.test(w)) {
          el.value = S.opts.sni;
          const on = !S.ui.femboy; setUi('femboy', on); if (on) setUi('scorpion', false); renderSheet();
          toast(on ? 'UwU-режим включён 💖 Добро пожаловать, фембойчек!' : 'UwU-режим выключен');
        } else if (w.includes('скорпион') || w.includes('мортал') || w.trim() === 'scorpion' || w.trim() === 'mortal kombat') {
          el.value = S.opts.sni;
          const on = !S.ui.scorpion; setUi('scorpion', on); if (on) setUi('femboy', false); renderSheet();
          toast(on ? '🔥 Скорпион: GET OVER HERE!' : 'Тема Скорпиона выключена');
        } else call('setOpt', 'sni', el.value);
        break;
      }
      case 'uiBool': setUi(k, el.checked); break;
      case 'uiText': { let v = el.value; if (k === 'customBg' || k === 'customCard') v = v.replace('#', '').trim(); setUi(k, v); if (k !== 'title') renderSheet(); break; }
      case 'rule': call('setRule', el.dataset.p, el.value); break;
      default: break;
    }
  });
  document.addEventListener('input', (e) => {
    const el = e.target.closest('[data-inp]'); if (!el) return;
    const k = el.dataset.k, v = parseFloat(el.value);
    setUi(k, v);
    const l = $('lbl-' + k);
    if (l) l.textContent = k === 'blur' ? String(Math.round(v)) : Math.round(v * 100) + '%';
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { if (!$('dlg').classList.contains('hidden')) closeAdd(); else closeSheet(); }
    if (e.key === 'Enter' && e.ctrlKey && !$('dlg').classList.contains('hidden')) doAdd();
  });
  document.addEventListener('error', (e) => { const t = e.target; if (t && t.tagName === 'IMG' && t.classList.contains('flag')) t.replaceWith(document.createTextNode(String(t.alt).toUpperCase())); }, true);

  // ---------- пасхалка: котик ----------
  let tapCount = 0, tapTimer = null, catEl = null, mx = innerWidth / 2, my = innerHeight / 2;
  let pet = 0, petTimer = null, heartTimer = null, sayTimer = null;
  function say(t) { const b = catEl && catEl.querySelector('#catsay'); if (!b) return; b.textContent = t; b.classList.add('show'); clearTimeout(sayTimer); sayTimer = setTimeout(() => b.classList.remove('show'), 1600); }
  function heart() { if (!catEl) return; const h = document.createElement('span'); h.className = 'heart'; h.textContent = '❤'; h.style.left = (25 + Math.random() * 70) + 'px'; catEl.appendChild(h); setTimeout(() => h.remove(), 1300); }
  function startPet() { if (!catEl || catEl.classList.contains('pet')) return; catEl.classList.add('pet'); say('мурр~'); heart(); purrStart(); heartTimer = setInterval(heart, 380); }
  function stopPet() { clearInterval(heartTimer); purrStop(); pet = 0; if (catEl) catEl.classList.remove('pet'); }
  function look() {
    if (!catEl) return;
    catEl.querySelectorAll('.pup').forEach((p) => {
      const r = p.previousElementSibling.getBoundingClientRect();
      const dx = mx - (r.left + r.width / 2), dy = my - (r.top + r.height / 2), d = Math.hypot(dx, dy) || 1, k = Math.min(1, d / 90) * 4;
      p.setAttribute('transform', `translate(${(+p.dataset.x) + dx / d * k},${(+p.dataset.y) + dy / d * k * 1.1})`);
    });
    const hr = catEl.getBoundingClientRect();
    const head = catEl.querySelector('.head');
    if (head && !catEl.classList.contains('pet')) head.style.transform = `rotate(${Math.max(-7, Math.min(7, (mx - (hr.left + hr.width / 2)) / 60))}deg)`;
  }

  // ---------- звуки котика (синтез в браузере, без файлов) ----------
  let actx = null, purrNode = null, lastMeow = 0;
  function audio() {
    if (!actx) { try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return null; } }
    if (actx.state === 'suspended') actx.resume();
    return actx;
  }
  function meow(kind) {
    const c = audio(); if (!c) return;
    const t = c.currentTime, pitch = 0.9 + Math.random() * 0.35, short = kind === 'short';
    const dur = short ? 0.2 : 0.55 + Math.random() * 0.25;
    const osc = c.createOscillator(); osc.type = 'sawtooth';
    const f = osc.frequency;
    if (short) { f.setValueAtTime(330 * pitch, t); f.linearRampToValueAtTime(520 * pitch, t + dur * 0.6); f.linearRampToValueAtTime(420 * pitch, t + dur); }
    else { f.setValueAtTime(420 * pitch, t); f.linearRampToValueAtTime(820 * pitch, t + dur * 0.3); f.linearRampToValueAtTime(560 * pitch, t + dur * 0.75); f.linearRampToValueAtTime(380 * pitch, t + dur); }
    const vib = c.createOscillator(); vib.frequency.value = 6;
    const vg = c.createGain(); vg.gain.value = 12; vib.connect(vg); vg.connect(f);
    const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 2;
    bp.frequency.setValueAtTime(900, t); bp.frequency.linearRampToValueAtTime(2100, t + dur * 0.35); bp.frequency.linearRampToValueAtTime(1000, t + dur);
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 3500;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.9, t + 0.06); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(bp); bp.connect(lp); lp.connect(g); g.connect(c.destination);
    osc.start(t); vib.start(t); osc.stop(t + dur + 0.05); vib.stop(t + dur + 0.05);
  }
  function purrStart() {
    const c = audio(); if (!c || purrNode) return;
    const len = c.sampleRate * 2, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) { last = (last + 0.02 * (Math.random() * 2 - 1)) / 1.02; d[i] = last * 4; }
    const src = c.createBufferSource(); src.buffer = buf; src.loop = true;
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 420;
    const am = c.createGain(); am.gain.value = 0.5;
    const lfo = c.createOscillator(); lfo.frequency.value = 25;
    const lg = c.createGain(); lg.gain.value = 0.5; lfo.connect(lg); lg.connect(am.gain);
    const master = c.createGain(); master.gain.setValueAtTime(0.0001, c.currentTime); master.gain.linearRampToValueAtTime(1, c.currentTime + 0.25);
    src.connect(lp); lp.connect(am); am.connect(master); master.connect(c.destination);
    src.start(); lfo.start();
    purrNode = { src, lfo, master };
  }
  function purrStop() {
    if (!purrNode || !actx) return;
    const { src, lfo, master } = purrNode; purrNode = null;
    const t = actx.currentTime;
    master.gain.cancelScheduledValues(t); master.gain.setValueAtTime(master.gain.value, t); master.gain.linearRampToValueAtTime(0.0001, t + 0.3);
    src.stop(t + 0.35); lfo.stop(t + 0.35);
  }
  function toggleCat() {
    if (catEl) { stopPet(); catEl.remove(); catEl = null; toast('Котик ушёл спать 😴'); return; }
    catEl = document.createElement('div');
    catEl.id = 'cat';
    catEl.innerHTML = CAT_SVG + '<div id="catsay"></div>';
    document.body.appendChild(catEl);
    catEl.addEventListener('mousemove', (e) => { pet += Math.abs(e.movementX) + Math.abs(e.movementY); if (pet > 140) startPet(); if (catEl.classList.contains('pet')) { clearTimeout(petTimer); petTimer = setTimeout(stopPet, 800); } });
    catEl.addEventListener('mouseleave', stopPet);
    catEl.addEventListener('click', () => { heart(); const now = Date.now(); if (now - lastMeow > 450) { lastMeow = now; meow(Math.random() < 0.4 ? 'short' : 'long'); } say(['мяу!', 'мур?', 'мрр', '🐾', 'мяу~'][Math.floor(Math.random() * 5)]); });
    look(); meow('long'); toast('Котик пришёл! Погладь его мышкой 🐱');
    let blink = null;
    const doBlink = () => { if (!catEl) return; catEl.classList.add('blink'); setTimeout(() => catEl && catEl.classList.remove('blink'), 140); blink = setTimeout(doBlink, 2500 + Math.random() * 3500); };
    blink = setTimeout(doBlink, 2000);
  }
  setInterval(() => { pet = Math.max(0, pet - 30); }, 200);
  document.addEventListener('mousemove', (e) => { mx = e.clientX; my = e.clientY; look(); });
  $('title').addEventListener('click', () => { tapCount++; clearTimeout(tapTimer); tapTimer = setTimeout(() => { tapCount = 0; }, 2000); if (tapCount >= 10) { tapCount = 0; toggleCat(); } });
  sysMq.addEventListener('change', () => { if (S) applyTheme(); });
  window.api.onState((s) => { S = s; applyTheme(); updateHome(); renderSheet(true); });
}

if (typeof module !== 'undefined') module.exports = { esc, palette, groupsOf, serversHtml, appsHtml, settingsHtml, targetOptions };
