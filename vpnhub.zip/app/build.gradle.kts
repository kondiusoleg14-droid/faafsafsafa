plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "app.vpnhub"
    compileSdk = 34
    // Один и тот же ключ подписи для ВСЕХ сборок — иначе Android не даёт обновить приложение «поверх» ("конфликтует с другими файлами").
    signingConfigs {
        create("vpnhub") {
            storeFile = file("vpnhub.jks")
            storePassword = "vpnhub123"
            keyAlias = "vpnhub"
            keyPassword = "vpnhub123"
        }
    }
    defaultConfig {
        applicationId = "app.vpnhub"
        minSdk = 26
        targetSdk = 33
        versionCode = System.getenv("BUILD_NUM")?.toIntOrNull() ?: 1
        versionName = System.getenv("BUILD_ID") ?: "0.1"
        resValue("string", "build_id", System.getenv("BUILD_ID") ?: "dev")
        resValue("string", "update_repo", System.getenv("GITHUB_REPOSITORY") ?: "kondiusoleg14-droid/faafsafsafa")
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    buildTypes {
        debug {
            isDebuggable = false // быстрый режим: без отладочных замедлений
            signingConfig = signingConfigs.getByName("vpnhub")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(files("libs/libbox.aar"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
}
