package app.vpnhub

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Скин Бойкиссера: свои спрайты (res/drawable-nodpi/bk_<id>.webp, bk_<id>_b.webp — моргание, bk_<id>_e1a… — уши) и СВОИ реплики.
 * Пока включён скин, говорит только фразы из pools (недостающие наборы берутся из "idle").
 * Чтобы добавить фразы — допиши строки в pools["idle"]. Строки с пометкой «доп.» — от разработчика, их можно удалить.
 */
class BuddySkin(val id: String, val name: String, val blink: Boolean, val ears: Boolean, val pools: Map<String, List<String>>)

object BuddySkins {
    var current by mutableStateOf("classic")

    val all: List<BuddySkin> = listOf(
        BuddySkin("kyle", "Кайл Крейн", true, true, mapOf("idle" to listOf(
            "Эй, я Кайл! Я победил вооружённую армию людей Раиса, людей Барона. А ты даже домашку не можешь сделать… не расстраивай дядю Крейна",
            "Мама Гази самая лучшая ❤️",
            "Я не уберёг всех своих близких, а ты даже не можешь кровать заправить",
            "Кошька",
            "Оп оп + легенда",
            "Паркур — это не побег, это стиль 🏃",          // доп.
            "Ночью лучше сидеть дома и пить чай 🍵",        // доп.
            "Дядя Крейн гордится тобой 💪"                   // доп.
        ))),
        BuddySkin("smk", "Скорпион", false, false, mapOf("idle" to listOf(
            "Я мстил Саб-Зиро. Не выбирай Саб-Зиро — у тебя есть только я и Джони",
            "Не давай Саб-Зиро петрушевый чай 😡",
            "Ну и сколько ты там выучил комбо на Саб-Зиро?",
            "Get over here! 🦂",                              // доп.
            "Месть — блюдо, которое подают горячим 🔥",      // доп.
            "Тихо. Я тренирую комбо."                        // доп.
        )))
    )

    fun def(id: String?): BuddySkin? = all.firstOrNull { it.id == id }
    fun active(): BuddySkin? = def(current)
    fun name(id: String): String = if (id == "classic") "Классика" else (def(id)?.name ?: "Классика")
    fun load(ctx: Context) { current = BuddyPrefs.skin(ctx) }
    fun set(ctx: Context, id: String) { current = if (def(id) != null) id else "classic"; BuddyPrefs.setSkin(ctx, current) }
    fun cycle(ctx: Context) { val ids = listOf("classic") + all.map { it.id }; set(ctx, ids[(ids.indexOf(current) + 1) % ids.size]) }
}
