package app.vpnhub

import android.animation.ValueAnimator
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.IdentityHashMap
import kotlin.math.abs
import kotlin.random.Random

/** Настройки плавающего Бойкиссера (хранятся отдельно, чтобы служба читала их и после перезагрузки). */
object BuddyPrefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("buddy", Context.MODE_PRIVATE)
    fun overlay(ctx: Context) = sp(ctx).getBoolean("overlay", false)
    fun setOverlay(ctx: Context, v: Boolean) { sp(ctx).edit().putBoolean("overlay", v).apply() }
    fun react(ctx: Context) = sp(ctx).getBoolean("react", true)
    fun setReact(ctx: Context, v: Boolean) { sp(ctx).edit().putBoolean("react", v).apply() }
    fun boot(ctx: Context) = sp(ctx).getBoolean("boot", true)
    fun setBoot(ctx: Context, v: Boolean) { sp(ctx).edit().putBoolean("boot", v).apply() }
    fun skin(ctx: Context): String = sp(ctx).getString("skin", "classic") ?: "classic"
    fun setSkin(ctx: Context, v: String) { sp(ctx).edit().putString("skin", v).apply() }
    fun x(ctx: Context, def: Int) = sp(ctx).getInt("x", def)
    fun y(ctx: Context, def: Int) = sp(ctx).getInt("y", def)
    fun setPos(ctx: Context, x: Int, y: Int) { sp(ctx).edit().putInt("x", x).putInt("y", y).apply() }
}

/** После перезагрузки телефона возвращаем Бойкиссера, если он был включён. */
class BuddyBootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && BuddyPrefs.overlay(ctx) && BuddyPrefs.boot(ctx) && Settings.canDrawOverlays(ctx))
            BuddyOverlayService.start(ctx)
    }
}

/**
 * Бойкиссер поверх всех приложений. Тот же характер, что в ПК-версии: моргает и дёргает ушками, гладится рукой, ложится
 * спать, обнимает экран; по запущенному приложению (YouTube, музыка, игры, мессенджеры…) меняет вид и фразы.
 * Какое приложение открыто — читается через «Доступ к использованию» и обрабатывается только на телефоне.
 */
class BuddyOverlayService : Service() {
    companion object {
        const val ACTION_STOP = "app.vpnhub.BUDDY_STOP"
        private const val CH = "buddy"
        private const val NID = 7
        private val BLINK = setOf("sit", "tea", "cs")
        private val EARS = setOf("sit", "tea")
        private const val LIE_N = 9
        private const val HUG_N = 9

        fun start(ctx: Context) {
            try { ctx.startForegroundService(Intent(ctx, BuddyOverlayService::class.java)) } catch (_: Exception) { }
        }
        fun stop(ctx: Context) { try { ctx.stopService(Intent(ctx, BuddyOverlayService::class.java)) } catch (_: Exception) { } }

        fun usageGranted(ctx: Context): Boolean {
            val ao = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            @Suppress("DEPRECATION")
            val mode = if (Build.VERSION.SDK_INT >= 29)
                ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            else ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            return mode == AppOpsManager.MODE_ALLOWED
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private lateinit var bubble: TextView
    private lateinit var menuBox: LinearLayout
    private lateinit var frame: FrameLayout
    private lateinit var sprite: ImageView
    private lateinit var hand: ImageView
    private lateinit var zzz: TextView
    private var hugView: ImageView? = null

    private var ctxMode = ""
    private var variant = ""
    private var curSprite = ""
    private var lying = false
    private var lieBusy = false
    private var lieFrame = 1
    private var petting = false
    private var petStart = 0L
    private var handFrame = 1
    private var hugBusy = false
    private var lastSayAt = 0L
    private var nextGap = 9000L
    private var lastActive = System.currentTimeMillis()
    private var lastMeow = 0L
    private var lastPkg: String? = null
    private var lastVpn = ""
    private var lastSkin = ""
    private val clicks = ArrayList<Long>()
    private val mem = IdentityHashMap<List<String>, MutableList<String>>()

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()
    private fun pool(key: String): List<String> {
        val sk = BuddySkins.active()
        if (sk != null) return sk.pools[key] ?: sk.pools.getValue("idle")      // в скине — только его реплики
        return BuddyPhrases.SAY[key] ?: BuddyPhrases.SAY.getValue("idle")
    }
    private fun canBlink(): Boolean { val b = baseSprite(); return b in BLINK || BuddySkins.def(b)?.blink == true }
    private fun canEars(): Boolean { val b = baseSprite(); return b in EARS || BuddySkins.def(b)?.ears == true }
    private fun hourPool(): List<String> {
        val hh = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return pool(if (hh < 5) "night" else if (hh < 11) "morning" else if (hh < 17) "day" else if (hh < 23) "evening" else "night")
    }
    private fun pick(p: List<String>): String {
        if (p.isEmpty()) return ""
        val hist = mem.getOrPut(p) { mutableListOf() }
        var t = p.random(); var n = 0
        while (p.size > 3 && t in hist && n < 8) { t = p.random(); n++ }
        hist.add(t)
        while (hist.size > minOf(5, p.size - 1)) hist.removeAt(0)
        return t
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Ui.init(this)
        BuddySkins.load(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NID, notification())
        if (intent?.action == ACTION_STOP) { BuddyPrefs.setOverlay(this, false); stopSelf(); return START_NOT_STICKY }
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (root == null) {
            try { buildOverlay() } catch (e: Exception) { CrashLog.step(this, "бойкиссер: " + (e.message ?: e.javaClass.simpleName).take(100)); stopSelf(); return START_NOT_STICKY }
        }
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Бойкиссер", NotificationManager.IMPORTANCE_MIN))
        val stopPi = PendingIntent.getService(this, 1, Intent(this, BuddyOverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val openPi = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CH)
            .setContentTitle("Бойкиссер на связи").setContentText("Живёт поверх приложений")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(openPi).setOngoing(true)
            .addAction(Notification.Action.Builder(0, "Спрятать", stopPi).build()).build()
    }

    private fun rounded(fill: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(14f).toFloat(); setStroke(dp(2f), stroke)
    }

    private fun buildOverlay() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END; clipChildren = false; clipToPadding = false }

        bubble = TextView(this).apply {
            visibility = View.GONE; setTextColor(0xFF581845.toInt()); textSize = 12.5f
            setPadding(dp(10f), dp(6f), dp(10f), dp(6f)); maxWidth = dp(150f)
            background = rounded(0xFFFFFFFF.toInt(), 0xFFFF7AB8.toInt())
        }
        col.addView(bubble, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.END; bottomMargin = dp(4f) })

        menuBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setPadding(dp(4f), dp(4f), dp(4f), dp(4f)); background = rounded(0xFFFFFFFF.toInt(), 0xFFFF7AB8.toInt())
        }
        col.addView(menuBox, LinearLayout.LayoutParams(dp(150f), LinearLayout.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.END; bottomMargin = dp(4f) })

        frame = FrameLayout(this).apply { clipChildren = false; clipToPadding = false }
        sprite = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER }
        frame.addView(sprite, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, dp(138f)))
        hand = ImageView(this).apply {
            visibility = View.GONE; pivotX = 0.88f * dp(90f); pivotY = 0.52f * dp(92f); rotation = 14f
            setImageResource(resources.getIdentifier("bk_hand1", "drawable", packageName))
        }
        frame.addView(hand, FrameLayout.LayoutParams(dp(90f), dp(92f)))
        zzz = TextView(this).apply { text = "💤"; textSize = 20f; visibility = View.GONE }
        frame.addView(zzz, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.TOP or Gravity.END; topMargin = dp(2f); rightMargin = dp(8f) })
        col.addView(frame, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.END })

        frame.setOnTouchListener { _, e -> onTouch(e) }
        col.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) hideMenu(); false }

        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            dp(150f), WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.START
        lp.x = BuddyPrefs.x(this, dm.widthPixels - dp(160f))
        lp.y = BuddyPrefs.y(this, dp(110f))
        params = lp
        root = col
        wm.addView(col, lp)

        refreshSprite()
        h.postDelayed({ speak(pick(if (Random.nextBoolean()) pool("hello") else hourPool())) }, 800)
        h.postDelayed(blink, 2500); h.postDelayed(ears, 4000); h.postDelayed(talk, 1500); h.post(poll)
        registerReceiver(batteryRx, IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_LOW); addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED)
        })
    }

    // ---------- вид ----------
    private fun baseSprite(): String {
        BuddySkins.active()?.let { return it.id }
        if (Ui.scorpion) return "mask"
        return when (ctxMode) {
            "tea" -> "tea"
            "music" -> "music"
            "cs", "game" -> "cs"
            "bank" -> "shy"
            else -> if (Vpn.error != null && Vpn.state != "on") "shy" else if (Vpn.state == "on") "tea" else "sit"
        }
    }

    private fun refreshSprite() {
        if (!::sprite.isInitialized) return
        val base = baseSprite()
        val showLie = lying && !Ui.scorpion && BuddySkins.active() == null
        val name = if (showLie) "bk_lie$lieFrame" else "bk_$base$variant"
        if (name != curSprite) {
            var id = resources.getIdentifier(name, "drawable", packageName)
            if (id == 0) id = resources.getIdentifier("bk_$base", "drawable", packageName)
            if (id == 0) id = resources.getIdentifier("bk_sit", "drawable", packageName)
            curSprite = name
            sprite.setImageResource(id)
        }
        val hPx = dp(if (showLie) 110f else if (base == "mask" || base == "smk") 150f else 138f)
        val slp = sprite.layoutParams
        if (slp.height != hPx) { slp.height = hPx; sprite.layoutParams = slp }
        zzz.visibility = if (lying && !lieBusy) View.VISIBLE else View.GONE
    }

    private val hideBubble = Runnable { if (::bubble.isInitialized) bubble.visibility = View.GONE }
    private fun speak(t: String, ms: Long = 3800L) {
        if (!::bubble.isInitialized) return
        bubble.text = t; bubble.visibility = View.VISIBLE
        lastSayAt = System.currentTimeMillis()
        h.removeCallbacks(hideBubble); h.postDelayed(hideBubble, ms)
    }

    // моргание и дёргание ушками
    private val blink = object : Runnable {
        override fun run() {
            if (!petting && !lying && canBlink()) { variant = "_b"; refreshSprite(); h.postDelayed({ variant = ""; refreshSprite() }, 130) }
            h.postDelayed(this, 2200L + Random.nextLong(3200L))
        }
    }
    private val ears = object : Runnable {
        override fun run() {
            if (!petting && !lying && canEars()) {
                val n = 1 + Random.nextInt(2)
                variant = "_e${n}a"; refreshSprite()
                h.postDelayed({ variant = "_e${n}b"; refreshSprite() }, 110)
                h.postDelayed({ variant = "_e${n}a"; refreshSprite() }, 220)
                h.postDelayed({ variant = ""; refreshSprite() }, 330)
            }
            h.postDelayed(this, 3500L + Random.nextLong(4500L))
        }
    }

    // реплики: по приложению, в покое, по времени суток
    private val talk = object : Runnable {
        override fun run() {
            val t = System.currentTimeMillis()
            if (!petting && !hugBusy && menuBox.visibility != View.VISIBLE && t - lastSayAt > nextGap) {
                val idle = t - lastActive
                val p = when {
                    lying -> pool("lie")
                    Ui.scorpion -> pool("mask")
                    ctxMode.isNotEmpty() && Random.nextFloat() < 0.6f -> pool(ctxMode)
                    idle > 120000L && Random.nextFloat() < 0.4f -> pool("bored")
                    Vpn.error != null && Vpn.state != "on" -> pool("vpnError")
                    Vpn.state == "on" && Random.nextFloat() < 0.4f -> pool("vpnOnIdle")
                    Random.nextFloat() < 0.3f -> hourPool()
                    else -> pool("idle")
                }
                speak(pick(p)); nextGap = 15000L + Random.nextLong(10000L)
            }
            h.postDelayed(this, 1500)
        }
    }

    // какое приложение сейчас открыто (раз в 2 секунды) и состояние VPN
    private val poll = object : Runnable {
        override fun run() {
            try { tick() } catch (_: Exception) { }
            h.postDelayed(this, 2000)
        }
    }

    private fun foregroundPkg(): String? {
        val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val ev = um.queryEvents(end - 20000L, end) ?: return lastPkg
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == 1) lastPkg = e.packageName      // ACTIVITY_RESUMED (на старых версиях MOVE_TO_FOREGROUND — то же значение)
        }
        return lastPkg
    }

    private fun tick() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return
        val pkg = if (BuddyPrefs.react(this) && usageGranted(this)) foregroundPkg() else null
        val mine = pkg == packageName
        root?.visibility = if (mine) View.INVISIBLE else View.VISIBLE        // внутри VPN Hub есть свой Бойкиссер
        val m = if (mine) ctxMode else BuddyContext.classify(pkg)
        if (m != ctxMode) {
            ctxMode = m; lastActive = System.currentTimeMillis()
            refreshSprite()
            if (m.isNotEmpty() && !lying && !hugBusy) speak(pick(pool(m)))
        }
        if (BuddySkins.current != lastSkin) { lastSkin = BuddySkins.current; curSprite = ""; refreshSprite() }
        val vs = Vpn.state + (Vpn.error ?: "")
        if (vs != lastVpn) {
            val first = lastVpn.isEmpty(); lastVpn = vs
            refreshSprite()
            if (!first && !lying && !hugBusy) speak(pick(pool(when { Vpn.error != null && Vpn.state != "on" -> "vpnError"; Vpn.state == "on" -> "vpnOn"; Vpn.state == "starting" -> "vpnConnecting"; else -> "vpnOff" })))
        }
    }

    private val batteryRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_BATTERY_LOW -> speak(pick(pool("batteryLow")))
                Intent.ACTION_POWER_CONNECTED -> speak(pick(pool("charging")))
                Intent.ACTION_POWER_DISCONNECTED -> speak(pick(pool("unplugged")))
            }
        }
    }

    // ---------- касания: тап, поглаживание (проводи пальцем), долгое нажатие + движение = перетащить, долгое нажатие = меню ----------
    private var downX = 0f; private var downY = 0f; private var lastX = 0f; private var lastY = 0f
    private var startWx = 0; private var startWy = 0
    private var acc = 0f
    private var moved = false; private var longPressed = false; private var dragging = false
    private val longPress = Runnable { longPressed = true; frame.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) }

    private fun onTouch(e: MotionEvent): Boolean {
        val lp = params ?: return false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; lastX = e.x; lastY = e.y; acc = 0f
                moved = false; longPressed = false; dragging = false
                startWx = lp.x; startWy = lp.y
                lastActive = System.currentTimeMillis()
                h.postDelayed(longPress, 450)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX; val dy = e.rawY - downY
                if (!moved && (abs(dx) > slop || abs(dy) > slop)) { moved = true; if (!longPressed) h.removeCallbacks(longPress) }
                if (moved && longPressed) {
                    dragging = true; hideMenu()
                    lp.x = startWx + dx.toInt(); lp.y = startWy - dy.toInt()      // gravity BOTTOM: y считается снизу
                    try { wm.updateViewLayout(root, lp) } catch (_: Exception) { }
                } else if (moved) {
                    acc += abs(e.x - lastX) + abs(e.y - lastY)
                    if (acc > 220f) startPet()
                    if (petting) moveHand(e.x, e.y)
                }
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                h.removeCallbacks(longPress)
                when {
                    dragging -> savePos()
                    petting -> stopPet()
                    !moved && longPressed -> showMenu()
                    !moved && e.actionMasked == MotionEvent.ACTION_UP -> tap()
                }
            }
        }
        return true
    }

    private fun savePos() {
        val lp = params ?: return
        val dm = resources.displayMetrics
        val w = root?.width ?: dp(150f); val hh = root?.height ?: dp(200f)
        lp.x = lp.x.coerceIn(0, maxOf(0, dm.widthPixels - w)); lp.y = lp.y.coerceIn(0, maxOf(0, dm.heightPixels - hh))
        try { wm.updateViewLayout(root, lp) } catch (_: Exception) { }
        BuddyPrefs.setPos(this, lp.x, lp.y)
    }

    private fun tap() {
        val t = System.currentTimeMillis(); lastActive = t
        clicks.removeAll { t - it > 2500L }; clicks.add(t)
        heart(frame.width * (0.25f + 0.5f * Random.nextFloat()), frame.height * 0.35f)
        speak(pick(pool(if (clicks.size >= 5) "annoyed" else "click")), 2600)
        if (t - lastMeow > 450) { lastMeow = t; Sound.meow(Random.nextFloat() < 0.4f) }
    }

    private fun heart(px: Float, py: Float) {
        val t = TextView(this).apply { text = "❤"; textSize = 18f; setTextColor(0xFFFF5C8A.toInt()); x = px; y = py }
        frame.addView(t, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        t.animate().translationYBy(-dp(70f).toFloat()).alpha(0f).setDuration(1100).withEndAction { frame.removeView(t) }.start()
    }

    // ---------- поглаживание ----------
    private val handLoop = object : Runnable {
        override fun run() {
            if (!petting) return
            handFrame = handFrame % 7 + 1
            val id = resources.getIdentifier("bk_hand$handFrame", "drawable", packageName)
            if (id != 0) hand.setImageResource(id)
            h.postDelayed(this, 60)
        }
    }
    private val heartLoop = object : Runnable {
        override fun run() {
            if (!petting) return
            heart(frame.width * (0.2f + 0.6f * Random.nextFloat()), frame.height * 0.25f)
            h.postDelayed(this, 380)
        }
    }
    private fun startPet() {
        if (petting) return
        petting = true; petStart = System.currentTimeMillis()
        hand.visibility = View.VISIBLE
        Sound.purrStart(); speak(pick(pool("pet")), 2400)
        h.post(handLoop); h.post(heartLoop)
    }
    private fun stopPet() {
        if (!petting) return
        petting = false
        hand.visibility = View.GONE
        Sound.purrStop()
        if (System.currentTimeMillis() - petStart > 6000L) speak(pick(pool("petLong")), 3200)
    }
    private fun moveHand(px: Float, py: Float) { hand.x = px - 0.88f * dp(90f); hand.y = py - 0.52f * dp(92f) }

    // ---------- меню ----------
    private val hideMenuRun = Runnable { hideMenu() }
    private fun hideMenu() { if (::menuBox.isInitialized) menuBox.visibility = View.GONE }
    private fun addItem(label: String, action: () -> Unit) {
        menuBox.addView(TextView(this).apply {
            text = label; textSize = 14f; setTextColor(0xFF581845.toInt()); setPadding(dp(10f), dp(9f), dp(10f), dp(9f))
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }
    private fun showMenu() {
        menuBox.removeAllViews()
        addItem(if (lying) "Сесть" else "Лечь") { if (lying) standUp() else lieDown() }
        if (BuddySkins.active() == null) addItem("Обнять экран") { hug() }
        addItem("Скин: " + BuddySkins.name(BuddySkins.current)) { BuddySkins.cycle(this); hideMenu(); refreshSprite(); speak(pick(pool("idle")), 4200) }
        addItem("Открыть VPN Hub") {
            hideMenu()
            try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
        }
        addItem("Спрятать Бойкиссера") { BuddyPrefs.setOverlay(this, false); stopSelf() }
        menuBox.visibility = View.VISIBLE
        h.removeCallbacks(hideMenuRun); h.postDelayed(hideMenuRun, 6000)
    }

    // ---------- лечь / встать ----------
    private fun lieDown() {
        hideMenu()
        if (lying || lieBusy) return
        if (Ui.scorpion || BuddySkins.active() != null) { lying = true; refreshSprite(); speak(pick(pool("lie"))); return }
        lieBusy = true; lying = true; lieFrame = 1; refreshSprite()
        speak(pick(pool("lieStart")), 2400)
        for (i in 2..LIE_N) h.postDelayed({
            lieFrame = i
            if (i == LIE_N) { lieBusy = false }
            refreshSprite()
            if (i == LIE_N) speak(pick(pool("lie")))
        }, 420L * (i - 1))
    }
    private fun standUp() {
        hideMenu()
        if (!lying || lieBusy) return
        if (Ui.scorpion || BuddySkins.active() != null) { lying = false; refreshSprite(); speak(pick(pool("wake"))); return }
        lieBusy = true
        var k = 0
        for (i in LIE_N - 1 downTo 1) {
            k++
            h.postDelayed({
                lieFrame = i
                if (i == 1) { lying = false; lieBusy = false }
                refreshSprite()
                if (i == 1) speak(pick(pool("wake")))
            }, 240L * k)
        }
    }

    // ---------- обнять экран: кадры на весь экран, кот «подъезжает» с места, где сидит ----------
    private fun hug() {
        hideMenu()
        if (hugBusy) return
        stopPet()
        hugBusy = true
        speak(pick(pool("hugStart")), 2200)
        val dm = resources.displayMetrics
        val sw = dm.widthPixels.toFloat(); val sh = dm.heightPixels.toFloat()
        val v = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0f }
        fun frameRes(n: Int) = resources.getIdentifier("bk_hug$n", "drawable", packageName)
        v.setImageResource(frameRes(1))
        val hp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        try { wm.addView(v, hp) } catch (_: Exception) { hugBusy = false; return }
        hugView = v
        root?.alpha = 0f
        val lp = params
        val cx = (lp?.x ?: 0) + dp(75f).toFloat()
        val cy = sh - (lp?.y ?: dp(110f)) - dp(70f)
        val k0 = 0.28f
        val tx0 = cx - sw / 2f; val ty0 = cy - sh / 2f
        fun place(pr: Float) {
            val k = k0 + (1f - k0) * pr
            v.scaleX = k; v.scaleY = k; v.translationX = (1f - pr) * tx0; v.translationY = (1f - pr) * ty0
        }
        place(0f)
        v.animate().alpha(1f).setDuration(250).start()
        ValueAnimator.ofFloat(0f, 1f).apply { duration = 1500; interpolator = DecelerateInterpolator(); addUpdateListener { place(it.animatedValue as Float) } }.start()
        for (n in 2..HUG_N) h.postDelayed({ v.setImageResource(frameRes(n)) }, 60L + 230L * (n - 1))
        // назад
        h.postDelayed({
            ValueAnimator.ofFloat(1f, 0f).apply { duration = 1100; interpolator = DecelerateInterpolator(); addUpdateListener { place(it.animatedValue as Float) } }.start()
            for (n in HUG_N - 1 downTo 1) h.postDelayed({ v.setImageResource(frameRes(n)) }, 120L * (HUG_N - n))
        }, 3800)
        h.postDelayed({ v.animate().alpha(0f).setDuration(250).start() }, 4900)
        h.postDelayed({
            try { wm.removeView(v) } catch (_: Exception) { }
            hugView = null; root?.alpha = 1f; hugBusy = false
            speak(pick(pool("hugEnd")), 3400)
        }, 5250)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { unregisterReceiver(batteryRx) } catch (_: Exception) { }
        try { Sound.purrStop() } catch (_: Exception) { }
        hugView?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        root?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        root = null
        super.onDestroy()
    }
}
