package app.vpnhub

import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

private fun findActivity(ctx: Context): ComponentActivity? {
    var c: Context? = ctx
    while (c is ContextWrapper) { if (c is ComponentActivity) return c; c = c.baseContext }
    return null
}

/** Карточка «Бойкиссер» на вкладке «Оформление»: внутри приложения и поверх других приложений. На ТВ не показывается. */
@Composable
fun BuddySection() {
    if (Ui.tv) return
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var overlayOn by remember { mutableStateOf(BuddyPrefs.overlay(ctx)) }
    var react by remember { mutableStateOf(BuddyPrefs.react(ctx)) }
    var boot by remember { mutableStateOf(BuddyPrefs.boot(ctx)) }

    // после возврата из системных настроек перепроверяем разрешения
    DisposableEffect(ctx) {
        val act = findActivity(ctx)
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        act?.lifecycle?.addObserver(obs)
        onDispose { act?.lifecycle?.removeObserver(obs) }
    }
    val canDraw = remember(tick) { Settings.canDrawOverlays(ctx) }
    val usage = remember(tick) { BuddyOverlayService.usageGranted(ctx) }

    LaunchedEffect(tick, overlayOn, canDraw) {
        if (overlayOn && canDraw) BuddyOverlayService.start(ctx)
        else if (!overlayOn) BuddyOverlayService.stop(ctx)
    }

    fun open(intent: Intent) { try { ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { } }

    Spacer(Modifier.height(14.dp))
    Text("Бойкиссер", color = Ui.pal.text, fontWeight = FontWeight.SemiBold)
    SwitchRow("Внутри приложения", "Котик в углу экрана VPN Hub (его же включают 10 нажатиями на название)", Egg.cat) { Egg.cat = it }
    SwitchRow("Поверх других приложений", "Живёт на экране, пока ты в браузере, видео или играх: можно гладить, перетаскивать, укладывать спать и обнимать экран", overlayOn) { v ->
        overlayOn = v; BuddyPrefs.setOverlay(ctx, v)
        if (v && !Settings.canDrawOverlays(ctx)) open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
    }
    if (overlayOn && !canDraw) {
        Text("Нужно разрешение «Поверх других окон»", color = Ui.pal.dim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        OutlinedButton(
            onClick = { open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))) },
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
        ) { Text("Разрешить показ поверх окон") }
    }
    if (overlayOn) {
        SwitchRow("Реагировать на приложения", "Узнаёт, что открыто: YouTube — плед и чай, музыка — наушники, игры — каска, банк — отвернулся. Название приложения обрабатывается только на телефоне и никуда не отправляется.", react) { v ->
            react = v; BuddyPrefs.setReact(ctx, v)
            if (v && !BuddyOverlayService.usageGranted(ctx)) open(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        if (react && !usage) {
            Text("Нужен «Доступ к использованию»: найди VPN Hub в списке и включи", color = Ui.pal.dim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(
                onClick = { open(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) },
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            ) { Text("Открыть доступ к использованию") }
        }
        SwitchRow("Запускать после перезагрузки", "Бойкиссер вернётся сам, когда телефон включится", boot) { v -> boot = v; BuddyPrefs.setBoot(ctx, v) }
    }
}
