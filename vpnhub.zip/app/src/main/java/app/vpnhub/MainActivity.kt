package app.vpnhub

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.core.view.WindowCompat
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.ui.focus.focusRequester
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

private val Bg get() = Ui.pal.bg
private val Card get() = Ui.pal.card
private val Accent get() = Ui.pal.accent
private val Accent2 get() = Ui.pal.accent2
private val Green get() = Ui.pal.green
private val Dim get() = Ui.pal.dim
private val Tx get() = Ui.pal.text

fun Rd(x: Int): androidx.compose.ui.unit.Dp = (x * Ui.corner).dp

class MainActivity : ComponentActivity() {
    private val vpnPerm = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) startVpn()
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(applicationContext)
        Ui.init(applicationContext)
        Ui.systemDark = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val um = getSystemService(android.content.Context.UI_MODE_SERVICE) as android.app.UiModeManager
        Ui.tv = um.currentModeType == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION || packageManager.hasSystemFeature("android.software.leanback")
        AppIcon.apply(applicationContext)
        CrashLog.install(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            val d0 = androidx.compose.ui.platform.LocalDensity.current
            val cfg = androidx.compose.ui.platform.LocalConfiguration.current
            val tvScale = if (Ui.tv) (cfg.screenHeightDp / 560f).coerceIn(1f, 1.4f) else 1f
            androidx.compose.runtime.CompositionLocalProvider(
                androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(d0.density * tvScale, d0.fontScale)
            ) {
                HubTheme { Root { toggle() } }
            }
        }
    }

    private fun toggle() {
        if (Vpn.state != "off") { startService(Intent(this, HubVpnService::class.java).setAction("stop")); return }
        if (!Store.selectionValid()) Store.selected = Store.servers.firstOrNull()?.id
        if (Store.selected == null) {
            Toast.makeText(this, "Сначала добавь подписку или ключ на вкладке «Серверы»", Toast.LENGTH_LONG).show(); return
        }
        val i = VpnService.prepare(this)
        if (i != null) vpnPerm.launch(i) else startVpn()
    }

    private fun startVpn() {
        ContextCompat.startForegroundService(this, Intent(this, HubVpnService::class.java).setAction("start"))
    }
}

class Fetched(val body: String, val title: String?)

fun fetchText(url: String, ua: String): Fetched {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 15000; c.readTimeout = 20000
    c.setRequestProperty("User-Agent", ua)
    c.setRequestProperty("x-hwid", Store.hwid())
    c.setRequestProperty("x-device-os", "Android")
    c.setRequestProperty("x-ver-os", Build.VERSION.RELEASE)
    c.setRequestProperty("x-device-model", Build.MODEL)
    if (c.responseCode >= 400) throw Exception("HTTP ${c.responseCode}")
    val title = c.getHeaderField("profile-title")?.let {
        if (it.startsWith("base64:")) runCatching { Parser.b64(it.removePrefix("base64:")) }.getOrNull() else it
    }
    return Fetched(c.inputStream.bufferedReader().readText(), title)
}

class Loaded(val result: Subscription.Result?, val title: String?, val diag: String)

private fun mask(t: String) = t.replace(Regex("[A-Za-z0-9+/=_.-]{14,}")) { it.value.take(4) + "…" }.replace('\n', ' ')

private fun usable(r: Subscription.Result): Int = r.links.sumOf { l ->
    val name = Parser.nameOf(l) ?: return@sumOf 0
    Parser.outbounds(Server("x", null, name, l), "t").count { it.optString("type") != "urltest" }
}

suspend fun loadSub(url: String, quick: Boolean = false): Loaded = withContext(Dispatchers.IO) {
    var best: Subscription.Result? = null
    var bestScore = -1
    var title: String? = null
    val diag = StringBuilder()
    // Happ первым: он получает от провайдера «серверы из нескольких ключей» (JSON-конфиги); остальные — запасные
    for (ua in listOf("Happ/2.7.0", "sing-box/1.11.4", "v2rayN/6.45")) {
        val tag = ua.substringBefore('/')
        try {
            val f = fetchText(url, ua)
            if (title == null) title = f.title
            val r = Subscription.parse(f.body)
            val score = usable(r)
            diag.append("$tag: ответ ${f.body.length} симв., формат «${r.format}», записей ${r.links.size}, рабочих ключей $score\n")
            if (r.links.isEmpty()) diag.append("  начало: «${mask(f.body.trim().take(90))}»\n")
            if (score > bestScore) { best = r; bestScore = score }
            if (quick && bestScore > 0) break   // для частого автообновления хватает первого ответа — меньше запросов к провайдеру
        } catch (e: Exception) { diag.append("$tag: ошибка ${e.message ?: e}\n") }
    }
    Loaded(best, title, diag.toString().trim())
}

fun extractSubUrl(t: String): String? {
    val s = t.trim()
    val l = s.lowercase()
    if (l.startsWith("http://") || l.startsWith("https://")) return s
    val prefixes = listOf(
        "happ://add/", "hiddify://import/", "sing-box://import-remote-profile?url=",
        "v2rayng://install-sub?url=", "v2box://install-sub?url=", "clash://install-config?url=",
        "clashmeta://install-config?url=", "streisand://import/"
    )
    for (p in prefixes) if (l.startsWith(p)) return Uri.decode(s.substring(p.length)).substringBefore('#')
    return null
}

@Composable
fun PowerIcon(modifier: Modifier = Modifier, color: Color = Color.White) {
    Canvas(modifier) {
        val w = size.minDimension
        val sw = w * 0.1f
        val inset = sw * 1.2f
        drawArc(
            color = color, startAngle = -55f, sweepAngle = 290f, useCenter = false,
            topLeft = Offset(inset, inset + w * 0.06f),
            size = androidx.compose.ui.geometry.Size(w - inset * 2, w - inset * 2 - w * 0.06f),
            style = Stroke(width = sw, cap = StrokeCap.Round)
        )
        drawLine(color, Offset(w / 2, sw), Offset(w / 2, w * 0.52f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

fun decodeSub(body: String): List<String> {
    val t = body.trim()
    val text = if (t.contains("://")) t else runCatching { Parser.b64(t) }.getOrDefault(t)
    return text.lines().map { it.trim() }.filter { it.contains("://") }
}

suspend fun reconnectVpn(ctx: android.content.Context) {
    ctx.startService(Intent(ctx, HubVpnService::class.java).setAction("stop"))
    delay(1800)
    ContextCompat.startForegroundService(ctx, Intent(ctx, HubVpnService::class.java).setAction("start"))
}

@Composable
fun Root(onToggle: () -> Unit) {
    // любое изменение выбора сервера / правил для приложений при включённом VPN применяется автоматически
    val rctx = androidx.compose.ui.platform.LocalContext.current
    var seenVersion by remember { mutableIntStateOf(Store.configVersion) }
    LaunchedEffect(Store.configVersion) {
        if (Store.configVersion != seenVersion) {
            seenVersion = Store.configVersion
            if (Vpn.state == "on") {
                delay(1500)
                if (Vpn.state == "on" && Store.configVersion == seenVersion) {
                    Toast.makeText(rctx, "Применяю изменения…", Toast.LENGTH_SHORT).show()
                    reconnectVpn(rctx)
                }
            }
        }
    }
    LaunchedEffect(Ui.imageVersion) { Ui.loadImage(rctx) }
    LaunchedEffect(Unit) { Updater.autoCheck(rctx) }
    LaunchedEffect(Unit) { while (true) { SubAuto.run(false); kotlinx.coroutines.delay(60_000) } }
    Box(Modifier.fillMaxSize().trackTouch()) {
        BgLayer()
        Scaffold(containerColor = Color.Transparent) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) { HomeScreen(onToggle) }
        }
        if (Egg.cat) CatOverlay()
        UpdateDialog()
    }
}

suspend fun netTest(): String = withContext(Dispatchers.IO) {
    val sb = StringBuilder()
    fun ms(t: Long) = "${System.currentTimeMillis() - t} мс"
    var t = System.currentTimeMillis()
    val ip = runCatching { java.net.InetAddress.getByName("www.gstatic.com").hostAddress }.getOrNull()
    sb.append("1) DNS www.gstatic.com: ").append(if (ip != null) "$ip (${ms(t)})" else "ОШИБКА (${ms(t)})").append("\n")
    t = System.currentTimeMillis()
    try {
        Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 7000) }
        sb.append("2) TCP на 1.1.1.1:443 (без DNS): ок (${ms(t)})\n")
    } catch (e: Exception) { sb.append("2) TCP на 1.1.1.1:443 (без DNS): ОШИБКА ${e.javaClass.simpleName} (${ms(t)})\n") }
    t = System.currentTimeMillis()
    try {
        val c = URL("https://www.gstatic.com/generate_204").openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        sb.append("3) HTTPS generate_204: код ${c.responseCode} (${ms(t)})")
    } catch (e: Exception) { sb.append("3) HTTPS generate_204: ОШИБКА ${e.javaClass.simpleName}: ${e.message?.take(80)} (${ms(t)})") }
    t = System.currentTimeMillis()
    try {
        val c = URL("https://speed.cloudflare.com/__down?bytes=8000000").openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 15000
        var n = 0L
        c.inputStream.use { ins ->
            val buf = ByteArray(65536)
            while (true) { val r = ins.read(buf); if (r < 0) break; n += r }
        }
        val sec = (System.currentTimeMillis() - t) / 1000.0
        sb.append("\n4) Скачивание ${"%.1f".format(n / 1_000_000.0)} МБ за ${"%.1f".format(sec)} с = ${"%.1f".format(n * 8 / 1_000_000.0 / sec)} Мбит/с")
    } catch (e: Exception) { sb.append("\n4) Скорость: ОШИБКА ${e.javaClass.simpleName}") }
    val ps = Perf.summary()
    if (ps.isNotEmpty()) sb.append("\n5) ").append(ps)
    val top = Perf.top(8)
    if (top.isNotEmpty()) sb.append("\n6) Кто ходил в сеть: ").append(top.joinToString(", ") { "${it.first}(${it.second})" })
    sb.toString()
}

class Group(val key: String, val name: String, val items: List<Server>)

fun groupsOf(list: List<Server>): List<Group> {
    val m = LinkedHashMap<String, MutableList<Server>>()
    list.forEach { m.getOrPut(it.gkey) { mutableListOf() }.add(it) }
    return m.map { (k, v) -> Group(k, v.first().clean, v) }
}

@Composable
fun TopIcon(label: String, onClick: () -> Unit) {
    Box(Modifier.size(46.dp).clip(RoundedCornerShape(Rd(14))).background(Card).tvClickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(label, fontSize = 20.sp)
    }
}

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Tx, fontSize = 15.sp)
            Text(sub, color = Dim, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun ConnSettings() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var testText by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
        SwitchRow("Сайты .ru / .рф / .su напрямую", "Российские сайты открываются без VPN", Store.ruDirect) { Store.ruDirect = it; Store.save() }
        SwitchRow("Отключить QUIC", "Ускоряет YouTube и браузер через VLESS; приложения сами перейдут на обычный HTTPS", Store.blockQuic) { Store.blockQuic = it; Store.save() }
        SwitchRow("Авто: сначала обычные серверы (TCP)", "Hysteria2 по UDP часто режется провайдером — видео грузится долго. «Авто» и группы выбирают среди обычных серверов; Hysteria2 можно выбрать вручную", Store.preferTcp) { Store.preferTcp = it; Store.save() }
        SwitchRow("Отключить IPv6", "Убирает зависания, когда сайт пытается открыться по IPv6, которого нет у сервера", Store.blockIpv6) { Store.blockIpv6 = it; Store.save() }
        SwitchRow("Белые списки на мобильном интернете", "Когда нет Wi-Fi, сам переключается на серверы обхода БС и берёт лучший по пингу. На Wi-Fi — твой обычный сервер.", Store.wlAuto) { Store.wlAuto = it; Store.save() }
        if (Store.wlAuto) {
            var showWl by remember { mutableStateOf(false) }
            val chosen = Store.wlGroups.count { k -> Store.servers.any { it.gkey == k } }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd(12))).background(Card).tvClickable { showWl = true }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Серверы для обхода БС", color = Tx, fontSize = 15.sp)
                    Text(if (chosen == 0) "Не выбраны — режим не сработает" else "Выбрано серверов-групп: $chosen", color = if (chosen == 0) Color(0xFFFF9A6B) else Dim, fontSize = 12.sp)
                }
                Text("▸", color = Dim, fontSize = 20.sp)
            }
            if (showWl) WlDialog { showWl = false }
        }
        val eggCtx = androidx.compose.ui.platform.LocalContext.current
        OutlinedTextField(
            value = Store.sniOverride,
            onValueChange = { v ->
                if (Egg.isMagic(v)) { Store.sniOverride = Egg.stripMagic(v).trim(); Store.save(); Egg.toggleFem(eggCtx) }
                else if (Egg.isMk(v)) { Store.sniOverride = Egg.stripMk(v).trim(); Store.save(); Egg.toggleMk(eggCtx) }
                else if (Egg.isMine(v)) { Egg.applyMine(eggCtx) }
                else { Store.sniOverride = v.trim(); Store.save() }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            label = { Text("Подмена SNI (необязательно)") }, singleLine = true,
            supportingText = { Text("Для обхода белых списков: домен из белого списка. Работает на серверах с TLS, кроме Reality.", fontSize = 11.sp) }
        )
        Text("Изменения применяются сами, если VPN включён", color = Dim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        SubAutoSection()
        UpdateSection()
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = { if (!testing) { testing = true; scope.launch { testText = netTest(); testing = false } } }, modifier = Modifier.fillMaxWidth()) {
            Text(if (testing) "Проверяю…" else "Проверить интернет")
        }
        testText?.let { tt ->
            Text(tt, color = Dim, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            TextButton(onClick = {
                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("test", tt))
                Toast.makeText(ctx, "Скопировано", Toast.LENGTH_SHORT).show()
            }) { Text("Скопировать результат") }
        }
        TextButton(onClick = { showLog = !showLog; tick++ }) { Text(if (showLog) "Скрыть журнал ядра" else "Показать журнал ядра") }
        if (showLog) {
            val log = remember(tick) { CoreLog.text(40).ifEmpty { "пока пусто" } }
            Text(log, color = Dim, fontSize = 10.sp)
            Row {
                TextButton(onClick = { tick++ }) { Text("Обновить") }
                TextButton(onClick = {
                    ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("log", log))
                    Toast.makeText(ctx, "Скопировано", Toast.LENGTH_SHORT).show()
                }) { Text("Скопировать") }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onToggle: () -> Unit) {
    var sheet by remember { mutableStateOf<String?>(null) } // servers | apps | settings
    var addNow by remember { mutableStateOf(false) }
    val on = Vpn.state == "on"
    val starting = Vpn.state == "starting"
    val srv = Store.servers.firstOrNull { it.id == Store.selected }
    val hctx = androidx.compose.ui.platform.LocalContext.current
    val fr = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(Unit) { if (Ui.tv) runCatching { fr.requestFocus() } }
    var crash by remember { mutableStateOf(CrashLog.report(hctx)) }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TopIcon("⚙️") { sheet = "settings" }
            Text(
                if (Ui.femboy) "только для фембойчиков UwU" else if (Ui.scorpion) "GET OVER HERE!" else Ui.title,
                Modifier.weight(1f).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { Egg.tap(hctx) },
                color = Tx, fontSize = if (Ui.femboy) 17.sp else if (Ui.scorpion) 20.sp else 22.sp, fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            TopIcon("📱") { sheet = "apps" }
        }

        Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            val brush = if (on) Brush.linearGradient(listOf(Green, Ui.pal.on2)) else Brush.linearGradient(listOf(Accent, Accent2))
            val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
            val click: () -> Unit = {
                if (Ui.haptic) haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                onToggle()
            }
            if (Ui.control == "switch") BigSwitch(on, starting, click)
            else if (Ui.femboy) Box(Modifier.size(190.dp).clip(CircleShape).tvClickable { click() }, contentAlignment = Alignment.Center) {
                if (starting) CircularProgressIndicator(color = Accent, modifier = Modifier.size(64.dp))
                else PawIcon(Modifier.size(190.dp), if (on) Green else Accent)
            }
            else Box(
                Modifier.size(190.dp).clip(CircleShape).background(brush).focusRequester(fr).tvClickable { click() },
                contentAlignment = Alignment.Center
            ) {
                if (starting) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(64.dp))
                else PowerIcon(Modifier.size(88.dp))
            }
            Spacer(Modifier.height(24.dp))
            Text(
                if (Ui.scorpion && !Ui.femboy && on) "FLAWLESS VICTORY 🔥" else (when (Vpn.state) { "on" -> "Подключено"; "starting" -> "Подключение…"; else -> "Отключено" }) + (if (Ui.femboy && on) " UwU" else ""),
                fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = if (on) Green else Tx
            )
            if (on && Vpn.wlActive) Text("📶 Мобильная сеть: включён режим белых списков", color = Accent, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            if (srv != null && srv.kind.contains("⚠"))
                Text("⚠ Ядро не поддерживает транспорт этого сервера — выбери сервер без значка ⚠", color = Color(0xFFFF9A6B), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            Vpn.error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp)) }
        }

        Row(Modifier.fillMaxWidth().padding(bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(Rd(16))).background(Card)
                    .tvClickable { addNow = false; sheet = "servers" }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Сервер", color = Dim, fontSize = 12.sp)
                    Text(Store.describe(Store.selected), color = Tx, fontSize = 16.sp, maxLines = 2)
                    if (srv != null) Text(srv.kind, color = Dim, fontSize = 12.sp)
                }
                Text("▾", color = Dim, fontSize = 20.sp)
            }
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.size(64.dp).clip(RoundedCornerShape(Rd(16))).background(Brush.linearGradient(listOf(Accent, Accent2)))
                    .tvClickable { addNow = true; sheet = "servers" },
                contentAlignment = Alignment.Center
            ) { Text("+", fontSize = 30.sp, color = Color.White) }
        }
    }

    if (sheet != null) {
        val h = androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp.dp * 0.88f
        ModalBottomSheet(
            onDismissRequest = { sheet = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Ui.pal.sheet
        ) {
            Column(Modifier.fillMaxWidth().height(h).navigationBarsPadding()) {
                Text(
                    when (sheet) { "servers" -> "Серверы"; "apps" -> "Серверы для приложений"; else -> "Настройки" },
                    color = Tx, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                )
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (sheet) {
                        "servers" -> ServersScreen(startWithAdd = addNow, onPick = { sheet = null })
                        "apps" -> AppsScreen()
                        else -> SettingsContent()
                    }
                }
            }
        }
    }

    crash?.let { c ->
        AlertDialog(
            onDismissRequest = { CrashLog.clear(hctx); crash = null },
            title = { Text("Приложение закрывалось с ошибкой") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(c.lines().take(30).joinToString("\n"), fontSize = 11.sp) } },
            confirmButton = {
                TextButton(onClick = {
                    hctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("crash", c))
                    Toast.makeText(hctx, "Скопировано", Toast.LENGTH_SHORT).show()
                }) { Text("Скопировать") }
            },
            dismissButton = { TextButton(onClick = { CrashLog.clear(hctx); crash = null }) { Text("Закрыть") } }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GroupRow(g: Group, onPick: () -> Unit = {}) {
    val sel0 = Store.selected
    val groupSel = sel0 == "g:" + g.key
    val kinds = g.items.groupBy { it.kind }
    val selHere = groupSel || (sel0 != null && (sel0.startsWith("gk:" + g.key + "|") || g.items.any { it.id == sel0 }))
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd(14)))
            .background(if (selHere) Ui.pal.sel else Card).padding(start = 14.dp, top = 6.dp, bottom = 12.dp, end = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                g.name, color = Tx, maxLines = 2,
                modifier = Modifier.weight(1f).tvClickable {
                    Store.selected = if (g.items.size > 1) "g:" + g.key else g.items.first().id
                    Store.save(); onPick()
                }.padding(vertical = 8.dp)
            )
            TextButton(onClick = { g.items.forEach { Store.removeServer(it.id) } }) { Text("✕", color = Dim) }
        }
        if (groupSel) Text("авто: само выберет рабочий из ${g.items.size}", color = Accent, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
        FlowRow(Modifier.padding(end = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            kinds.forEach { (kind, list) ->
                val target = if (list.size == 1) list[0].id else "gk:" + g.key + "|" + kind
                val sel = sel0 == target
                val ping = list.filter { !it.isUdp }.mapNotNull { Store.pings[it.id]?.takeIf { p -> p >= 0 } }.minOrNull()
                Row(
                    Modifier.clip(RoundedCornerShape(Rd(8))).background(if (sel) Accent else Ui.pal.chip)
                        .tvClickable { Store.selected = target; Store.save(); onPick() }.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (list.size > 1) "$kind ×${list.size}" else kind, color = if (sel) Color.White else Tx, fontSize = 12.sp)
                    if (ping != null) Text("  $ping мс", color = if (sel) Color.White else Green, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun ServersScreen(startWithAdd: Boolean = false, onPick: () -> Unit = {}) {
    val scope = rememberCoroutineScope()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var showAdd by remember { mutableStateOf(startWithAdd) }
    var busy by remember { mutableStateOf(false) }
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    fun refresh(sub: Sub) {
        scope.launch {
            busy = true
            val l = loadSub(sub.url)
            val r = l.result
            if (r == null || r.links.isEmpty()) {
                Store.subInfo[sub.id] = l.diag
                toast("Серверы не найдены — подробности под названием подписки")
            } else {
                Store.subInfo.remove(sub.id)
                Store.replaceSub(sub.id, r.links)
                val title = l.title
                if (!title.isNullOrBlank()) {
                    val i = Store.subs.indexOfFirst { it.id == sub.id }
                    if (i >= 0) { Store.subs[i] = Store.subs[i].copy(name = title); Store.save() }
                }
                toast("Загружено подключений: ${r.links.size} (${r.format})")
            }
            busy = false
        }
    }

    fun pingAll() {
        Store.servers.toList().filter { !it.isUdp }.forEach { s ->
            scope.launch(Dispatchers.IO) {
                val hp = Parser.hostPort(s.link) ?: return@launch
                val t = System.currentTimeMillis()
                val ms = runCatching { Socket().use { it.connect(InetSocketAddress(hp.first, hp.second), 3000) }; (System.currentTimeMillis() - t).toInt() }.getOrDefault(-1)
                Store.pings[s.id] = ms
            }
        }
    }

    fun handleAdd(text: String) {
        if (text.startsWith("happ://crypt", true)) {
            toast("Это зашифрованная ссылка Happ — такие не поддерживаются. Нужна обычная ссылка подписки (https://…)"); return
        }
        val url = extractSubUrl(text)
        if (url != null) {
            val sub = Sub(Store.idOf(url), runCatching { URL(url).host }.getOrDefault("Подписка"), url)
            if (Store.subs.none { it.id == sub.id }) Store.subs.add(sub)
            Store.save(); refresh(sub)
        } else {
            val r = Subscription.parse(text)
            val n = Store.addLinks(r.links, null)
            toast(if (n > 0) "Добавлено ключей: $n" else "Не удалось распознать. Вставь ключ (vless://…) или ссылку подписки (https://…)")
        }
    }

    LaunchedEffect(Remote.inbox) { Remote.inbox?.let { Remote.inbox = null; Remote.stop(); showAdd = false; handleAdd(it) } }

    val servers = Store.servers.toList()
    val subs = Store.subs.toList()
    val bySub = remember(servers) { servers.groupBy { it.subId }.mapValues { groupsOf(it.value) } }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { showAdd = true }) { Text("+ Добавить") }
            OutlinedButton(onClick = { pingAll() }) { Text("Пинг") }
            OutlinedButton(onClick = {
                val txt = servers.mapIndexed { i, sv -> "${i + 1}. ${sv.name} | ${sv.kind}" }.joinToString("\n")
                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("servers", txt))
                toast("Список серверов скопирован (${servers.size})")
            }) { Text("Список") }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        if (subs.isEmpty() && servers.isEmpty()) {
            Text("Нажми «+ Добавить» и вставь ключ или ссылку подписки — приложение само разберётся, что это.", color = Dim, modifier = Modifier.padding(top = 20.dp))
        }
        LazyColumn(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (servers.isNotEmpty()) item(key = "auto", contentType = "auto") {
                val sel = Store.selected == "auto"
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd(14)))
                        .background(if (sel) Ui.pal.sel else Card)
                        .tvClickable { Store.selected = "auto"; Store.save(); onPick() }.padding(14.dp)
                ) {
                    Text("⚡ Авто", color = Tx)
                    Text("Сам выбирает рабочий сервер из всех (удобно, если часть серверов блокируется)" + if (sel) " • по умолчанию" else "", color = if (sel) Accent else Dim, fontSize = 12.sp)
                }
            }
            subs.forEach { sub ->
                val groups = bySub[sub.id].orEmpty()
                val total = groups.sumOf { it.items.size }
                item(key = "sub" + sub.id, contentType = "sub") {
                    Column {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd(12))).background(Ui.pal.hdr).padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("📡 ${sub.name}", color = Tx, maxLines = 1)
                            Text("Серверов: ${groups.size} · подключений: $total", color = Dim, fontSize = 12.sp)
                        }
                        TextButton(onClick = { refresh(sub) }) { Text("Обновить") }
                        TextButton(onClick = { Store.removeSub(sub.id) }) { Text("✕") }
                    }
                    if (groups.isEmpty()) Store.subInfo[sub.id]?.let {
                        Text(it, color = Color(0xFFFF9A6B), fontSize = 11.sp, modifier = Modifier.padding(start = 12.dp, top = 6.dp, end = 8.dp))
                    }
                    }
                }
                items(groups, key = { "g" + sub.id + it.key }, contentType = { "group" }) { GroupRow(it, onPick) }
            }
            val loose = bySub[null].orEmpty()
            if (loose.isNotEmpty()) {
                item(key = "loose", contentType = "sub") { Text("🔑 Отдельные ключи", color = Dim, modifier = Modifier.padding(top = 8.dp)) }
                items(loose, key = { "l" + it.key }, contentType = { "group" }) { GroupRow(it, onPick) }
            }
        }
    }

    if (showAdd) {
        var a by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { Remote.stop(); showAdd = false },
            title = { Text("Добавить") },
            text = {
                Column {
                    Text("Вставь ключ (vless://…) или ссылку подписки (https://… или happ://add/…). Ключ — это один сервер, подписка — целый список.", fontSize = 13.sp)
                    OutlinedTextField(a, { a = it }, Modifier.padding(top = 8.dp), label = { Text("Ключ или подписка") }, minLines = 3)
                    if (Ui.tv) {
                        TextButton(onClick = { Remote.start(ctx) }) { Text("📱 Добавить с телефона") }
                        if (Remote.url.isNotEmpty()) Text("Открой на телефоне в браузере:\n${Remote.url}\nПИН: ${Remote.pin}\n(на это время лучше выключить VPN)", fontSize = 13.sp)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { val t = a.trim(); Remote.stop(); showAdd = false; if (t.isNotEmpty()) handleAdd(t) }) { Text("Добавить") } },
            dismissButton = { TextButton(onClick = { Remote.stop(); showAdd = false }) { Text("Отмена") } }
        )
    }
}

class AppInfo(val pkg: String, val label: String, val icon: ImageBitmap?, val n: Int = 0)

@Composable
fun AppsScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var q by remember { mutableStateOf("") }
    val apps by produceState(emptyList<AppInfo>()) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val counts = Perf.pkgCounts.mapValues { it.value.get() }
            val tvIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            val launch = (pm.queryIntentActivities(i, 0) + pm.queryIntentActivities(tvIntent, 0)).map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .filter { it.first != ctx.packageName }.distinctBy { it.first }
            // приложения, которые ходили в сеть, но не имеют значка (например, Сервисы Google Play)
            val extra = counts.keys.filter { k -> !k.startsWith("uid:") && k != ctx.packageName && launch.none { it.first == k } }
                .map { k -> k to (runCatching { pm.getApplicationLabel(pm.getApplicationInfo(k, 0)).toString() }.getOrNull() ?: k) }
            (launch + extra)
                .map { (pkg, label) ->
                    AppInfo(pkg, label, runCatching { pm.getApplicationIcon(pkg).toBitmap(72, 72).asImageBitmap() }.getOrNull(), counts[pkg] ?: 0)
                }
                .sortedWith(compareByDescending<AppInfo> { Store.appRules.containsKey(it.pkg) }.thenByDescending { it.n }.thenBy { it.label.lowercase() })
        }
    }
    val all = Store.servers.toList()
    val counts = remember(all) { all.groupingBy { it.gkey }.eachCount() }
    fun labelOf(s: Server) = if ((counts[s.gkey] ?: 1) > 1) "${s.clean} · ${s.kind}" else s.clean
    val allGroups = remember(all) { groupsOf(all) }
    val list = apps.filter { it.label.contains(q, true) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Какой сервер для какого приложения", color = Tx, fontWeight = FontWeight.SemiBold)
        Text("Остальные приложения идут через сервер по умолчанию. Изменения применяются сами, если VPN включён. Приложения, которые только что ходили в сеть, показаны выше с числом соединений — так видно, какое из них реально отправляет трафик (например, голосовой Gemini часто идёт через приложение «Google» и «Сервисы Google Play»).", color = Dim, fontSize = 12.sp)
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp), label = { Text("Поиск") }, singleLine = true)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.pkg }, contentType = { "app" }) { app ->
                var menu by remember { mutableStateOf(false) }
                val rule = Store.appRules[app.pkg]
                val ruleText = when {
                    rule == null -> "По умолчанию"
                    rule == "direct" -> "Напрямую"
                    else -> Store.describe(rule)
                }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd(12))).background(Card).tvClickable { menu = true }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (app.icon != null) Image(app.icon, null, Modifier.size(36.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(app.label, color = Tx, maxLines = 1)
                        Text(ruleText + (if (app.n > 0) " · соединений: ${app.n}" else ""), color = if (rule == null) Dim else Accent, fontSize = 12.sp, maxLines = 1)
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("По умолчанию") }, onClick = { Store.appRules.remove(app.pkg); Store.save(); menu = false })
                        DropdownMenuItem(text = { Text("Напрямую (без VPN)") }, onClick = { Store.appRules[app.pkg] = "direct"; Store.save(); menu = false })
                        allGroups.forEach { g ->
                            val target = if (g.items.size > 1) "g:" + g.key else g.items.first().id
                            DropdownMenuItem(
                                text = { Text(if (g.items.size > 1) "${g.name} (авто)" else g.name) },
                                onClick = { Store.appRules[app.pkg] = target; Store.save(); menu = false }
                            )
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun HubTheme(content: @Composable () -> Unit) {
    val sys = isSystemInDarkTheme()
    SideEffect { Ui.systemDark = sys }
    val p = Ui.pal
    val scheme = if (p.isLight)
        lightColorScheme(primary = p.accent, onPrimary = Color.White, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text, surfaceVariant = p.chip, onSurfaceVariant = p.dim, outline = p.dim)
    else
        darkColorScheme(primary = p.accent, onPrimary = Color.White, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text, surfaceVariant = p.chip, onSurfaceVariant = p.dim, outline = p.dim)
    val view = androidx.compose.ui.platform.LocalView.current
    SideEffect {
        val w = (view.context as? android.app.Activity)?.window
        if (w != null) {
            w.statusBarColor = android.graphics.Color.TRANSPARENT
            w.navigationBarColor = android.graphics.Color.TRANSPARENT
            WindowCompat.getInsetsController(w, view).apply { isAppearanceLightStatusBars = p.isLight; isAppearanceLightNavigationBars = p.isLight }
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun BgLayer() {
    val p = Ui.pal
    val kind = Ui.bgKind
    Box(Modifier.fillMaxSize().background(p.bg)) {
        val img = Ui.bgImage
        val femBg = Ui.femboy && !(kind == "image" && img != null)
        val mkBg = Ui.scorpion && !Ui.femboy && !(kind == "image" && img != null)
        if (femBg) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFFFE3F1), Color(0xFFFFC4E3)))))
            Image(painterResource(R.drawable.boy), null, Modifier.fillMaxWidth(0.88f).align(Alignment.Center).offset(y = 60.dp), contentScale = ContentScale.Fit)
        } else if (mkBg) {
            Image(painterResource(R.drawable.scorpion), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)))
        } else if (kind == "image" && img != null) {
            val bm = if (Ui.blur > 0f && Build.VERSION.SDK_INT >= 31) Modifier.blur(Ui.blur.dp) else Modifier
            Image(img, null, Modifier.fillMaxSize().then(bm), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background((if (p.isLight) Color.White else Color.Black).copy(alpha = Ui.dim)))
        } else if (kind.startsWith("grad")) {
            val g = Ui.grads.getOrNull(kind.removePrefix("grad").toIntOrNull() ?: -1)
            if (g != null) Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(lerp(p.bg, g.second, 0.55f), lerp(p.bg, g.third, 0.55f)))))
        }
    }
}

@Composable
fun BigSwitch(on: Boolean, starting: Boolean, onClick: () -> Unit) {
    val w = 230.dp; val h = 116.dp; val pad = 10.dp; val knob = h - pad * 2
    val target = when { on -> w - knob - pad; starting -> (w - knob) / 2; else -> pad }
    val x by animateDpAsState(target, tween(280), label = "knob")
    val track = if (on) Brush.horizontalGradient(listOf(Green, Ui.pal.on2)) else Brush.horizontalGradient(listOf(Ui.pal.chip, Ui.pal.chip))
    Box(Modifier.size(w, h).clip(CircleShape).background(track).tvClickable { onClick() }) {
        Box(Modifier.align(Alignment.CenterStart).offset(x = x).size(knob).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
            if (starting) CircularProgressIndicator(color = Accent, strokeWidth = 4.dp, modifier = Modifier.size(knob * 0.5f))
            else if (Ui.femboy) PawIcon(Modifier.size(knob * 0.6f), if (on) Green else Accent)
            else PowerIcon(Modifier.size(knob * 0.5f), color = if (on) Green else Dim)
        }
    }
}

@Composable
fun OptChip(text: String, sel: Boolean, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(Rd(10))).background(if (sel) Accent else Ui.pal.chip).tvClickable { onClick() }.padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(text, color = if (sel) Color.White else Tx, fontSize = 13.sp)
    }
}

@Composable
fun SliderRow(title: String, value: Float, range: ClosedFloatingPointRange<Float>, label: String, onChange: (Float) -> Unit) {
    Column(Modifier.padding(top = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Tx, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(label, color = Dim, fontSize = 12.sp)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun BgTile(selected: Boolean, brush: Brush?, label: String, onClick: () -> Unit, inner: @Composable BoxScope.() -> Unit = {}) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.tvClickable { onClick() }) {
        val shape = RoundedCornerShape(Rd(12))
        Box(
            Modifier.size(58.dp).clip(shape).then(if (brush != null) Modifier.background(brush) else Modifier.background(Ui.pal.chip))
                .border(if (selected) 2.dp else 1.dp, if (selected) Accent else Dim.copy(alpha = 0.3f), shape),
            contentAlignment = Alignment.Center, content = inner
        )
        Text(label, color = if (selected) Accent else Dim, fontSize = 11.sp, maxLines = 1, modifier = Modifier.padding(top = 3.dp))
    }
}

@Composable
fun SettingsContent() {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OptChip("Подключение", tab == 0) { tab = 0 }
            OptChip("Оформление", tab == 1) { tab = 1 }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) { if (tab == 0) ConnSettings() else AppearanceContent() }
    }
}

@Composable
fun AppearanceContent() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { Ui.importBg(ctx, uri) }
            if (ok) { Ui.bgKind = "image"; Ui.save(); Ui.imageVersion++ }
            else Toast.makeText(ctx, "Не удалось открыть картинку", Toast.LENGTH_LONG).show()
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text("Тема", color = Tx, fontWeight = FontWeight.SemiBold)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("system" to "Системная", "dark" to "Тёмная", "light" to "Светлая", "custom" to "Своя").forEach { (k, n) ->
                OptChip(n, Ui.mode == k) { Ui.mode = k; Ui.save() }
            }
        }
        if (Ui.mode == "custom") {
            OutlinedTextField(
                value = Ui.customBg, onValueChange = { Ui.customBg = it.filter { c -> c.isLetterOrDigit() || c == '#' }.take(9); Ui.save() },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
                label = { Text("Цвет фона (HEX, например 0B0F1A)") }, isError = Ui.parseHex(Ui.customBg) == null
            )
            OutlinedTextField(
                value = Ui.customCard, onValueChange = { Ui.customCard = it.filter { c -> c.isLetterOrDigit() || c == '#' }.take(9); Ui.save() },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp), singleLine = true,
                label = { Text("Цвет карточек (HEX)") }, isError = Ui.parseHex(Ui.customCard) == null
            )
        }

        Spacer(Modifier.height(14.dp))
        Text("Цвет акцента", color = Tx, fontWeight = FontWeight.SemiBold)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(Ui.pal.chip)
                    .border(if (Ui.accentHex.isEmpty()) 2.dp else 0.dp, Accent, CircleShape).tvClickable { Ui.accentHex = ""; Ui.save() },
                contentAlignment = Alignment.Center
            ) { Text("авто", color = Dim, fontSize = 10.sp) }
            Ui.accents.forEach { hex ->
                val c = Ui.parseHex(hex)!!
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(c)
                        .border(if (Ui.accentHex.equals(hex, true)) 3.dp else 0.dp, Tx, CircleShape).tvClickable { Ui.accentHex = hex; Ui.save() }
                )
            }
        }

        Spacer(Modifier.height(14.dp))
        Text("Фон", color = Tx, fontWeight = FontWeight.SemiBold)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BgTile(Ui.bgKind == "none", null, "Нет", { Ui.bgKind = "none"; Ui.save() })
            Ui.grads.forEachIndexed { i, g ->
                BgTile(Ui.bgKind == "grad$i", Brush.verticalGradient(listOf(g.second, g.third)), g.first, { Ui.bgKind = "grad$i"; Ui.save() })
            }
            if (Ui.hasImage) BgTile(Ui.bgKind == "image", null, "Моё фото", { Ui.bgKind = "image"; Ui.save() }) {
                Ui.bgImage?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
            }
            BgTile(false, null, "Из галереи", { picker.launch("image/*") }) { Text("🖼", fontSize = 24.sp) }
        }
        Text("«Из галереи» открывает выбор: Галерея, Фото или любая папка в «Файлах».", color = Dim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        if (Ui.bgKind != "none") {
            SliderRow("Затемнение фона", Ui.dim, 0f..0.85f, "${(Ui.dim * 100).toInt()}%") { Ui.dim = it; Ui.save() }
        }
        if (Ui.bgKind == "image") {
            SliderRow("Размытие фона (Android 12+)", Ui.blur, 0f..25f, "${Ui.blur.toInt()}") { Ui.blur = it; Ui.save() }
        }

        Spacer(Modifier.height(14.dp))
        Text("Кнопка подключения", color = Tx, fontWeight = FontWeight.SemiBold)
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OptChip("Кнопка", Ui.control == "button") { Ui.control = "button"; Ui.save() }
            OptChip("Тумблер", Ui.control == "switch") { Ui.control = "switch"; Ui.save() }
        }

        Spacer(Modifier.height(14.dp))
        Text("Карточки", color = Tx, fontWeight = FontWeight.SemiBold)
        SliderRow("Прозрачность", Ui.cardAlpha, 0.25f..1f, "${(Ui.cardAlpha * 100).toInt()}%") { Ui.cardAlpha = it; Ui.save() }
        SliderRow("Скругление углов", Ui.corner, 0.2f..1.8f, "${(Ui.corner * 100).toInt()}%") { Ui.corner = it; Ui.save() }

        OutlinedTextField(
            value = Ui.title, onValueChange = { Ui.title = it.take(24); Ui.save() },
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp), singleLine = true, label = { Text("Название вверху экрана") }
        )
        SwitchRow("Вибрация при нажатии", "Короткий отклик при включении и выключении", Ui.haptic) { Ui.haptic = it; Ui.save() }

        IconSection()

        TextButton(onClick = { Ui.reset(ctx) }) { Text("Сбросить оформление") }
        Text("Оформление не переподключает VPN.", color = Dim, fontSize = 11.sp)
        Spacer(Modifier.height(24.dp))
    }
}


@Composable
fun WlDialog(onClose: () -> Unit) {
    val groups = remember(Store.servers.size) { groupsOf(Store.servers.toList()) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Серверы для обхода белых списков") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Отметь серверы, которые работают при белых списках. На мобильном интернете приложение возьмёт из них лучший по пингу.", fontSize = 12.sp)
                Row {
                    TextButton(onClick = {
                        val rx = Regex("(?i)(бс|бел[ыо]|white|wl|bypass|обход|мобил|lte|cell)")
                        Store.wlGroups = groups.filter { rx.containsMatchIn(it.name) }.map { it.key }.toSet(); Store.save()
                    }) { Text("Найти по названию") }
                    TextButton(onClick = { Store.wlGroups = emptySet(); Store.save() }) { Text("Очистить") }
                }
                groups.forEach { g ->
                    val on = g.key in Store.wlGroups
                    Row(
                        Modifier.fillMaxWidth().tvClickable { Store.wlGroups = if (on) Store.wlGroups - g.key else Store.wlGroups + g.key; Store.save() }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = on, onCheckedChange = { Store.wlGroups = if (it) Store.wlGroups + g.key else Store.wlGroups - g.key; Store.save() })
                        Column(Modifier.weight(1f)) {
                            Text(g.name, maxLines = 2)
                            Text(g.items.map { it.kind }.distinct().joinToString(" · "), fontSize = 11.sp, maxLines = 1)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Готово") } }
    )
}


@Composable
fun UpdateSection() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
        SwitchRow("Автообновление", "При запуске приложение проверяет новую сборку на GitHub и предлагает её установить (раз в 6 часов)", Ui.autoUpdate) {
            Ui.autoUpdate = it; Ui.save(); if (it) Updater.check(ctx, false)
        }
        OutlinedButton(onClick = { Updater.check(ctx, true) }, modifier = Modifier.fillMaxWidth()) {
            Text(if (Updater.busy) "Подождите…" else "Проверить обновление")
        }
        if (Updater.status.isNotEmpty()) Text(Updater.status, color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        if (Updater.available != null) Button(onClick = { Updater.downloadAndInstall(ctx) }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) { Text("Обновить сейчас") }
        Text("Номер сборки: " + Updater.current(ctx), color = Dim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun UpdateDialog() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val id = Updater.available
    if (id != null && !Updater.dismissed) {
        AlertDialog(
            onDismissRequest = { Updater.dismissed = true },
            title = { Text("Доступно обновление") },
            text = { Text("Новая сборка $id (у тебя ${Updater.current(ctx)}). Скачать и установить?") },
            confirmButton = { TextButton(onClick = { Updater.dismissed = true; Updater.downloadAndInstall(ctx) }) { Text("Установить") } },
            dismissButton = { TextButton(onClick = { Updater.dismissed = true }) { Text("Позже") } }
        )
    }
}

@Composable
fun IconSection() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Spacer(Modifier.height(14.dp))
    Text("Иконка приложения", color = Tx, fontWeight = FontWeight.SemiBold)
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("auto" to "Авто (по теме)", "default" to "Стандартная", "fem" to "Бойкиссер", "mk" to "Скорпион").forEach { (k, n) ->
            OptChip(n, Ui.iconMode == k) { Ui.iconMode = k; Ui.save(); AppIcon.apply(ctx) }
        }
    }
    Text("«Авто»: в режиме UwU иконка с бойкиссером, в режиме Скорпиона — со Скорпионом. Иконка на рабочем столе меняется через несколько секунд; если пропала, найди приложение в общем списке программ.", color = Dim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
}


@Composable
fun SubAutoSection() {
    Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
        SwitchRow("Автообновление подписки", "Приложение само обновляет список серверов из подписки: пока приложение открыто или работает VPN. VPN переподключается, только если серверы действительно изменились", Ui.subAuto) {
            Ui.subAuto = it; Ui.save(); if (it) SubAuto.run(false)
        }
        if (Ui.subAuto) {
            Text("Как часто проверять:", color = Dim, fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15 to "15 мин", 30 to "30 мин", 60 to "1 час", 360 to "6 часов", 1440 to "24 часа").forEach { (m, n) ->
                    OptChip(n, Ui.subMinutes == m) { Ui.subMinutes = m; Ui.save() }
                }
            }
        }
        OutlinedButton(onClick = { SubAuto.run(true) }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) {
            Text(if (SubAuto.running) "Обновляю…" else "Обновить подписки сейчас")
        }
        val last = Ui.subLast
        val info = if (SubAuto.status.isNotEmpty()) SubAuto.status
            else if (last > 0) "Последняя проверка: " + java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(last))
            else "Ещё не проверялось"
        Text(info, color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}
