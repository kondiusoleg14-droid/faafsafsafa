package app.vpnhub

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

private val Bg = Color(0xFF0B0F1A)
private val Card = Color(0xFF151B2B)
private val Accent = Color(0xFF6C7BFF)
private val Accent2 = Color(0xFF9B5CFF)
private val Green = Color(0xFF2ED3A0)
private val Dim = Color(0xFF8A93A8)

class MainActivity : ComponentActivity() {
    private val vpnPerm = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) startVpn()
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(applicationContext)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card)) {
                Root { toggle() }
            }
        }
    }

    private fun toggle() {
        if (Vpn.state != "off") { startService(Intent(this, HubVpnService::class.java).setAction("stop")); return }
        if (Store.servers.none { it.id == Store.selected }) Store.selected = Store.servers.firstOrNull()?.id
        if (Store.selected == null) {
            Toast.makeText(this, "Сначала добавь подписку или ключ на вкладке «Серверы»", Toast.LENGTH_LONG).show(); return
        }
        val i = VpnService.prepare(this)
        if (i != null) vpnPerm.launch(i) else startVpn()
    }

    private fun startVpn() {
        ContextCompat.startForegroundService(this, Intent(this, HubVpnService::class.java).setAction("start"))
    }
}

class Fetched(val body: String, val title: String?)

fun fetchText(url: String, ua: String): Fetched {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 15000; c.readTimeout = 20000
    c.setRequestProperty("User-Agent", ua)
    c.setRequestProperty("x-hwid", Store.hwid())
    c.setRequestProperty("x-device-os", "Android")
    c.setRequestProperty("x-ver-os", Build.VERSION.RELEASE)
    c.setRequestProperty("x-device-model", Build.MODEL)
    if (c.responseCode >= 400) throw Exception("HTTP ${c.responseCode}")
    val title = c.getHeaderField("profile-title")?.let {
        if (it.startsWith("base64:")) runCatching { Parser.b64(it.removePrefix("base64:")) }.getOrNull() else it
    }
    return Fetched(c.inputStream.bufferedReader().readText(), title)
}

class Loaded(val result: Subscription.Result?, val title: String?, val preview: String, val err: String?)

suspend fun loadSub(url: String): Loaded = withContext(Dispatchers.IO) {
    var best: Subscription.Result? = null
    var title: String? = null
    var preview = ""
    var err: String? = null
    for (ua in listOf("v2rayN/6.45", "Happ/2.7.0", "sing-box/1.11.4")) {
        try {
            val f = fetchText(url, ua)
            if (title == null) title = f.title
            val r = Subscription.parse(f.body)
            if (best == null || r.links.size > best.links.size) { best = r; preview = f.body.trim().take(60).replace('\n', ' ') }
            if (r.links.size >= 2) break
        } catch (e: Exception) { err = e.message ?: e.toString() }
    }
    Loaded(best, title, preview, err)
}

fun extractSubUrl(t: String): String? {
    val s = t.trim()
    val l = s.lowercase()
    if (l.startsWith("http://") || l.startsWith("https://")) return s
    val prefixes = listOf(
        "happ://add/", "hiddify://import/", "sing-box://import-remote-profile?url=",
        "v2rayng://install-sub?url=", "v2box://install-sub?url=", "clash://install-config?url=",
        "clashmeta://install-config?url=", "streisand://import/"
    )
    for (p in prefixes) if (l.startsWith(p)) return Uri.decode(s.substring(p.length)).substringBefore('#')
    return null
}

@Composable
fun PowerIcon(modifier: Modifier = Modifier, color: Color = Color.White) {
    Canvas(modifier) {
        val w = size.minDimension
        val sw = w * 0.1f
        val inset = sw * 1.2f
        drawArc(
            color = color, startAngle = -55f, sweepAngle = 290f, useCenter = false,
            topLeft = Offset(inset, inset + w * 0.06f),
            size = androidx.compose.ui.geometry.Size(w - inset * 2, w - inset * 2 - w * 0.06f),
            style = Stroke(width = sw, cap = StrokeCap.Round)
        )
        drawLine(color, Offset(w / 2, sw), Offset(w / 2, w * 0.52f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

fun decodeSub(body: String): List<String> {
    val t = body.trim()
    val text = if (t.contains("://")) t else runCatching { Parser.b64(t) }.getOrDefault(t)
    return text.lines().map { it.trim() }.filter { it.contains("://") }
}

@Composable
fun Root(onToggle: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Card) {
                listOf("🏠 Главная", "🌐 Серверы", "📱 Приложения").forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(t, fontSize = 12.sp) }, alwaysShowLabel = true)
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(onToggle)
                1 -> ServersScreen()
                else -> AppsScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(onToggle: () -> Unit) {
    val on = Vpn.state == "on"
    val starting = Vpn.state == "starting"
    val srv = Store.servers.firstOrNull { it.id == Store.selected }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("VPN Hub", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(40.dp))
        val brush = if (on) Brush.linearGradient(listOf(Green, Color(0xFF1AA37A))) else Brush.linearGradient(listOf(Accent, Accent2))
        Box(
            Modifier.size(190.dp).clip(CircleShape).background(brush).clickable { onToggle() },
            contentAlignment = Alignment.Center
        ) {
            if (starting) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(64.dp))
            else PowerIcon(Modifier.size(88.dp))
        }
        Spacer(Modifier.height(28.dp))
        Text(
            when (Vpn.state) { "on" -> "Подключено"; "starting" -> "Подключение…"; else -> "Отключено" },
            fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = if (on) Green else Color.White
        )
        Spacer(Modifier.height(20.dp))
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Сервер по умолчанию", color = Dim, fontSize = 12.sp)
                Text(srv?.name ?: "не выбран — открой «Серверы»", color = Color.White, fontSize = 16.sp)
                if (srv != null) Text(srv.proto, color = Dim, fontSize = 12.sp)
            }
        }
        Vpn.error?.let { Spacer(Modifier.height(12.dp)); Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp) }
    }
}

@Composable
fun ServerRow(s: Server) {
    val sel = Store.selected == s.id
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(if (sel) Color(0xFF222C55) else Card)
            .clickable { Store.selected = s.id; Store.save() }.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(s.name, color = Color.White, maxLines = 1)
            Text(s.proto + (if (sel) " • по умолчанию" else ""), color = if (sel) Accent else Dim, fontSize = 12.sp)
        }
        Store.pings[s.id]?.let { Text(if (it < 0) "—" else "$it мс", color = if (it < 0) Dim else Green, fontSize = 13.sp) }
        TextButton(onClick = { Store.removeServer(s.id) }) { Text("✕", color = Dim) }
    }
}

@Composable
fun ServersScreen() {
    val scope = rememberCoroutineScope()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var showAdd by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    fun refresh(sub: Sub) {
        scope.launch {
            busy = true
            val l = loadSub(sub.url)
            val r = l.result
            if (r == null || r.links.isEmpty()) {
                toast("Серверы не найдены. " + (if (r != null) "Формат: ${r.format}. Начало ответа: ${l.preview}" else "Ошибка: ${l.err}"))
            } else {
                Store.replaceSub(sub.id, r.links)
                val title = l.title
                if (!title.isNullOrBlank()) {
                    val i = Store.subs.indexOfFirst { it.id == sub.id }
                    if (i >= 0) { Store.subs[i] = Store.subs[i].copy(name = title); Store.save() }
                }
                toast("Загружено серверов: ${r.links.size} (${r.format})")
            }
            busy = false
        }
    }

    fun pingAll() {
        Store.servers.toList().forEach { s ->
            scope.launch(Dispatchers.IO) {
                val hp = Parser.hostPort(s.link) ?: return@launch
                val t = System.currentTimeMillis()
                val ms = runCatching { Socket().use { it.connect(InetSocketAddress(hp.first, hp.second), 3000) }; (System.currentTimeMillis() - t).toInt() }.getOrDefault(-1)
                Store.pings[s.id] = ms
            }
        }
    }

    fun handleAdd(text: String) {
        if (text.startsWith("happ://crypt", true)) {
            toast("Это зашифрованная ссылка Happ — такие не поддерживаются. Нужна обычная ссылка подписки (https://…)"); return
        }
        val url = extractSubUrl(text)
        if (url != null) {
            val sub = Sub(Store.idOf(url), runCatching { URL(url).host }.getOrDefault("Подписка"), url)
            if (Store.subs.none { it.id == sub.id }) Store.subs.add(sub)
            Store.save(); refresh(sub)
        } else {
            val r = Subscription.parse(text)
            val n = Store.addLinks(r.links, null)
            toast(if (n > 0) "Добавлено ключей: $n" else "Не удалось распознать. Вставь ключ (vless://…) или ссылку подписки (https://…)")
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { showAdd = true }) { Text("+ Добавить") }
            OutlinedButton(onClick = { pingAll() }) { Text("Пинг") }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        if (Store.subs.isEmpty() && Store.servers.isEmpty()) {
            Text("Нажми «+ Добавить» и вставь ключ или ссылку подписки — приложение само разберётся, что это.", color = Dim, modifier = Modifier.padding(top = 20.dp))
        }
        LazyColumn(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Store.subs.toList().forEach { sub ->
                val list = Store.servers.filter { it.subId == sub.id }
                item(key = "sub" + sub.id) {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF1B2340)).padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("📡 ${sub.name}", color = Color.White, maxLines = 1)
                            Text("Серверов: ${list.size}", color = Dim, fontSize = 12.sp)
                        }
                        TextButton(onClick = { refresh(sub) }) { Text("Обновить") }
                        TextButton(onClick = { Store.removeSub(sub.id) }) { Text("✕") }
                    }
                }
                items(list, key = { it.id }) { ServerRow(it) }
            }
            val loose = Store.servers.filter { it.subId == null }
            if (loose.isNotEmpty()) {
                item(key = "loose") { Text("🔑 Отдельные ключи", color = Dim, modifier = Modifier.padding(top = 8.dp)) }
                items(loose, key = { it.id }) { ServerRow(it) }
            }
        }
    }

    if (showAdd) {
        var a by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Добавить") },
            text = {
                Column {
                    Text("Вставь ключ (vless://…) или ссылку подписки (https://… или happ://add/…). Ключ — это один сервер, подписка — целый список.", fontSize = 13.sp)
                    OutlinedTextField(a, { a = it }, Modifier.padding(top = 8.dp), label = { Text("Ключ или подписка") }, minLines = 3)
                }
            },
            confirmButton = { TextButton(onClick = { val t = a.trim(); showAdd = false; if (t.isNotEmpty()) handleAdd(t) }) { Text("Добавить") } },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Отмена") } }
        )
    }
}

data class AppInfo(val pkg: String, val label: String)

@Composable
fun AppsScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var q by remember { mutableStateOf("") }
    val apps by produceState(emptyList<AppInfo>()) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0).map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
                .filter { it.pkg != ctx.packageName }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
        }
    }
    val list = apps.filter { it.label.contains(q, true) }
        .sortedByDescending { Store.appRules.containsKey(it.pkg) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Какой сервер для какого приложения", color = Color.White, fontWeight = FontWeight.SemiBold)
        Text("Остальные приложения идут через сервер по умолчанию", color = Dim, fontSize = 12.sp)
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp), label = { Text("Поиск") }, singleLine = true)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.pkg }) { app ->
                var menu by remember { mutableStateOf(false) }
                val icon = remember(app.pkg) { runCatching { ctx.packageManager.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull() }
                val rule = Store.appRules[app.pkg]
                val ruleText = when {
                    rule == null -> "По умолчанию"
                    rule == "direct" -> "Напрямую"
                    else -> Store.servers.firstOrNull { it.id == rule }?.name ?: "По умолчанию"
                }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Card).clickable { menu = true }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (icon != null) Image(icon, null, Modifier.size(36.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(app.label, color = Color.White, maxLines = 1)
                        Text(ruleText, color = if (rule == null) Dim else Accent, fontSize = 12.sp, maxLines = 1)
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("По умолчанию") }, onClick = { Store.appRules.remove(app.pkg); Store.save(); menu = false })
                        DropdownMenuItem(text = { Text("Напрямую (без VPN)") }, onClick = { Store.appRules[app.pkg] = "direct"; Store.save(); menu = false })
                        Store.servers.forEach { s ->
                            DropdownMenuItem(text = { Text(s.name) }, onClick = { Store.appRules[app.pkg] = s.id; Store.save(); menu = false })
                        }
                    }
                }
            }
        }
    }
}
