package app.vpnhub

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

private val Bg = Color(0xFF0B0F1A)
private val Card = Color(0xFF151B2B)
private val Accent = Color(0xFF6C7BFF)
private val Accent2 = Color(0xFF9B5CFF)
private val Green = Color(0xFF2ED3A0)
private val Dim = Color(0xFF8A93A8)

class MainActivity : ComponentActivity() {
    private val vpnPerm = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) startVpn()
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(applicationContext)
        CrashLog.install(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card)) {
                Root { toggle() }
            }
        }
    }

    private fun toggle() {
        if (Vpn.state != "off") { startService(Intent(this, HubVpnService::class.java).setAction("stop")); return }
        if (!Store.selectionValid()) Store.selected = Store.servers.firstOrNull()?.id
        if (Store.selected == null) {
            Toast.makeText(this, "Сначала добавь подписку или ключ на вкладке «Серверы»", Toast.LENGTH_LONG).show(); return
        }
        val i = VpnService.prepare(this)
        if (i != null) vpnPerm.launch(i) else startVpn()
    }

    private fun startVpn() {
        ContextCompat.startForegroundService(this, Intent(this, HubVpnService::class.java).setAction("start"))
    }
}

class Fetched(val body: String, val title: String?)

fun fetchText(url: String, ua: String): Fetched {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 15000; c.readTimeout = 20000
    c.setRequestProperty("User-Agent", ua)
    c.setRequestProperty("x-hwid", Store.hwid())
    c.setRequestProperty("x-device-os", "Android")
    c.setRequestProperty("x-ver-os", Build.VERSION.RELEASE)
    c.setRequestProperty("x-device-model", Build.MODEL)
    if (c.responseCode >= 400) throw Exception("HTTP ${c.responseCode}")
    val title = c.getHeaderField("profile-title")?.let {
        if (it.startsWith("base64:")) runCatching { Parser.b64(it.removePrefix("base64:")) }.getOrNull() else it
    }
    return Fetched(c.inputStream.bufferedReader().readText(), title)
}

class Loaded(val result: Subscription.Result?, val title: String?, val diag: String)

private fun mask(t: String) = t.replace(Regex("[A-Za-z0-9+/=_.-]{14,}")) { it.value.take(4) + "…" }.replace('\n', ' ')

private fun usable(r: Subscription.Result): Int = r.links.sumOf { l ->
    val name = Parser.nameOf(l) ?: return@sumOf 0
    Parser.outbounds(Server("x", null, name, l), "t").count { it.optString("type") != "urltest" }
}

suspend fun loadSub(url: String): Loaded = withContext(Dispatchers.IO) {
    var best: Subscription.Result? = null
    var bestScore = -1
    var title: String? = null
    val diag = StringBuilder()
    // Happ первым: он получает от провайдера «серверы из нескольких ключей» (JSON-конфиги); остальные — запасные
    for (ua in listOf("Happ/2.7.0", "sing-box/1.11.4", "v2rayN/6.45")) {
        val tag = ua.substringBefore('/')
        try {
            val f = fetchText(url, ua)
            if (title == null) title = f.title
            val r = Subscription.parse(f.body)
            val score = usable(r)
            diag.append("$tag: ответ ${f.body.length} симв., формат «${r.format}», записей ${r.links.size}, рабочих ключей $score\n")
            if (r.links.isEmpty()) diag.append("  начало: «${mask(f.body.trim().take(90))}»\n")
            if (score > bestScore) { best = r; bestScore = score }
        } catch (e: Exception) { diag.append("$tag: ошибка ${e.message ?: e}\n") }
    }
    Loaded(best, title, diag.toString().trim())
}

fun extractSubUrl(t: String): String? {
    val s = t.trim()
    val l = s.lowercase()
    if (l.startsWith("http://") || l.startsWith("https://")) return s
    val prefixes = listOf(
        "happ://add/", "hiddify://import/", "sing-box://import-remote-profile?url=",
        "v2rayng://install-sub?url=", "v2box://install-sub?url=", "clash://install-config?url=",
        "clashmeta://install-config?url=", "streisand://import/"
    )
    for (p in prefixes) if (l.startsWith(p)) return Uri.decode(s.substring(p.length)).substringBefore('#')
    return null
}

@Composable
fun PowerIcon(modifier: Modifier = Modifier, color: Color = Color.White) {
    Canvas(modifier) {
        val w = size.minDimension
        val sw = w * 0.1f
        val inset = sw * 1.2f
        drawArc(
            color = color, startAngle = -55f, sweepAngle = 290f, useCenter = false,
            topLeft = Offset(inset, inset + w * 0.06f),
            size = androidx.compose.ui.geometry.Size(w - inset * 2, w - inset * 2 - w * 0.06f),
            style = Stroke(width = sw, cap = StrokeCap.Round)
        )
        drawLine(color, Offset(w / 2, sw), Offset(w / 2, w * 0.52f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

fun decodeSub(body: String): List<String> {
    val t = body.trim()
    val text = if (t.contains("://")) t else runCatching { Parser.b64(t) }.getOrDefault(t)
    return text.lines().map { it.trim() }.filter { it.contains("://") }
}

suspend fun reconnectVpn(ctx: android.content.Context) {
    ctx.startService(Intent(ctx, HubVpnService::class.java).setAction("stop"))
    delay(1800)
    ContextCompat.startForegroundService(ctx, Intent(ctx, HubVpnService::class.java).setAction("start"))
}

@Composable
fun Root(onToggle: () -> Unit) {
    // любое изменение выбора сервера / правил для приложений при включённом VPN применяется автоматически
    val rctx = androidx.compose.ui.platform.LocalContext.current
    var seenVersion by remember { mutableIntStateOf(Store.configVersion) }
    LaunchedEffect(Store.configVersion) {
        if (Store.configVersion != seenVersion) {
            seenVersion = Store.configVersion
            if (Vpn.state == "on") {
                delay(1500)
                if (Vpn.state == "on" && Store.configVersion == seenVersion) {
                    Toast.makeText(rctx, "Применяю изменения…", Toast.LENGTH_SHORT).show()
                    reconnectVpn(rctx)
                }
            }
        }
    }
    Scaffold(containerColor = Bg) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) { HomeScreen(onToggle) }
    }
}

suspend fun netTest(): String = withContext(Dispatchers.IO) {
    val sb = StringBuilder()
    fun ms(t: Long) = "${System.currentTimeMillis() - t} мс"
    var t = System.currentTimeMillis()
    val ip = runCatching { java.net.InetAddress.getByName("www.gstatic.com").hostAddress }.getOrNull()
    sb.append("1) DNS www.gstatic.com: ").append(if (ip != null) "$ip (${ms(t)})" else "ОШИБКА (${ms(t)})").append("\n")
    t = System.currentTimeMillis()
    try {
        Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 7000) }
        sb.append("2) TCP на 1.1.1.1:443 (без DNS): ок (${ms(t)})\n")
    } catch (e: Exception) { sb.append("2) TCP на 1.1.1.1:443 (без DNS): ОШИБКА ${e.javaClass.simpleName} (${ms(t)})\n") }
    t = System.currentTimeMillis()
    try {
        val c = URL("https://www.gstatic.com/generate_204").openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        sb.append("3) HTTPS generate_204: код ${c.responseCode} (${ms(t)})")
    } catch (e: Exception) { sb.append("3) HTTPS generate_204: ОШИБКА ${e.javaClass.simpleName}: ${e.message?.take(80)} (${ms(t)})") }
    t = System.currentTimeMillis()
    try {
        val c = URL("https://speed.cloudflare.com/__down?bytes=8000000").openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 15000
        var n = 0L
        c.inputStream.use { ins ->
            val buf = ByteArray(65536)
            while (true) { val r = ins.read(buf); if (r < 0) break; n += r }
        }
        val sec = (System.currentTimeMillis() - t) / 1000.0
        sb.append("\n4) Скачивание ${"%.1f".format(n / 1_000_000.0)} МБ за ${"%.1f".format(sec)} с = ${"%.1f".format(n * 8 / 1_000_000.0 / sec)} Мбит/с")
    } catch (e: Exception) { sb.append("\n4) Скорость: ОШИБКА ${e.javaClass.simpleName}") }
    sb.toString()
}

class Group(val key: String, val name: String, val items: List<Server>)

fun groupsOf(list: List<Server>): List<Group> {
    val m = LinkedHashMap<String, MutableList<Server>>()
    list.forEach { m.getOrPut(it.gkey) { mutableListOf() }.add(it) }
    return m.map { (k, v) -> Group(k, v.first().clean, v) }
}

@Composable
fun TopIcon(label: String, onClick: () -> Unit) {
    Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Card).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(label, fontSize = 20.sp)
    }
}

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            Text(sub, color = Dim, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsContent() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var testText by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
        SwitchRow("Сайты .ru / .рф / .su напрямую", "Российские сайты открываются без VPN", Store.ruDirect) { Store.ruDirect = it; Store.save() }
        SwitchRow("Отключить QUIC", "Ускоряет YouTube и браузер через VLESS; приложения сами перейдут на обычный HTTPS", Store.blockQuic) { Store.blockQuic = it; Store.save() }
        OutlinedTextField(
            value = Store.sniOverride, onValueChange = { Store.sniOverride = it.trim(); Store.save() },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            label = { Text("Подмена SNI (необязательно)") }, singleLine = true,
            supportingText = { Text("Для обхода белых списков: домен из белого списка. Работает на серверах с TLS, кроме Reality.", fontSize = 11.sp) }
        )
        Text("Изменения применяются сами, если VPN включён", color = Dim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = { if (!testing) { testing = true; scope.launch { testText = netTest(); testing = false } } }, modifier = Modifier.fillMaxWidth()) {
            Text(if (testing) "Проверяю…" else "Проверить интернет")
        }
        testText?.let { tt ->
            Text(tt, color = Dim, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            TextButton(onClick = {
                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("test", tt))
                Toast.makeText(ctx, "Скопировано", Toast.LENGTH_SHORT).show()
            }) { Text("Скопировать результат") }
        }
        TextButton(onClick = { showLog = !showLog; tick++ }) { Text(if (showLog) "Скрыть журнал ядра" else "Показать журнал ядра") }
        if (showLog) {
            val log = remember(tick) { CoreLog.text(40).ifEmpty { "пока пусто" } }
            Text(log, color = Dim, fontSize = 10.sp)
            Row {
                TextButton(onClick = { tick++ }) { Text("Обновить") }
                TextButton(onClick = {
                    ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("log", log))
                    Toast.makeText(ctx, "Скопировано", Toast.LENGTH_SHORT).show()
                }) { Text("Скопировать") }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onToggle: () -> Unit) {
    var sheet by remember { mutableStateOf<String?>(null) } // servers | apps | settings
    var addNow by remember { mutableStateOf(false) }
    val on = Vpn.state == "on"
    val starting = Vpn.state == "starting"
    val srv = Store.servers.firstOrNull { it.id == Store.selected }
    val hctx = androidx.compose.ui.platform.LocalContext.current
    var crash by remember { mutableStateOf(CrashLog.report(hctx)) }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TopIcon("⚙️") { sheet = "settings" }
            Text(
                "VPN Hub", Modifier.weight(1f), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            TopIcon("📱") { sheet = "apps" }
        }

        Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            val brush = if (on) Brush.linearGradient(listOf(Green, Color(0xFF1AA37A))) else Brush.linearGradient(listOf(Accent, Accent2))
            Box(
                Modifier.size(190.dp).clip(CircleShape).background(brush).clickable { onToggle() },
                contentAlignment = Alignment.Center
            ) {
                if (starting) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(64.dp))
                else PowerIcon(Modifier.size(88.dp))
            }
            Spacer(Modifier.height(24.dp))
            Text(
                when (Vpn.state) { "on" -> "Подключено"; "starting" -> "Подключение…"; else -> "Отключено" },
                fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = if (on) Green else Color.White
            )
            if (srv != null && srv.kind.contains("⚠"))
                Text("⚠ Ядро не поддерживает транспорт этого сервера — выбери сервер без значка ⚠", color = Color(0xFFFF9A6B), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            Vpn.error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp)) }
        }

        Row(Modifier.fillMaxWidth().padding(bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(Card)
                    .clickable { addNow = false; sheet = "servers" }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Сервер", color = Dim, fontSize = 12.sp)
                    Text(Store.describe(Store.selected), color = Color.White, fontSize = 16.sp, maxLines = 2)
                    if (srv != null) Text(srv.kind, color = Dim, fontSize = 12.sp)
                }
                Text("▾", color = Dim, fontSize = 20.sp)
            }
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Accent, Accent2)))
                    .clickable { addNow = true; sheet = "servers" },
                contentAlignment = Alignment.Center
            ) { Text("+", fontSize = 30.sp, color = Color.White) }
        }
    }

    if (sheet != null) {
        val h = androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp.dp * 0.88f
        ModalBottomSheet(
            onDismissRequest = { sheet = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Color(0xFF0F1424)
        ) {
            Column(Modifier.fillMaxWidth().height(h)) {
                Text(
                    when (sheet) { "servers" -> "Серверы"; "apps" -> "Серверы для приложений"; else -> "Настройки" },
                    color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                )
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (sheet) {
                        "servers" -> ServersScreen(startWithAdd = addNow, onPick = { sheet = null })
                        "apps" -> AppsScreen()
                        else -> SettingsContent()
                    }
                }
            }
        }
    }

    crash?.let { c ->
        AlertDialog(
            onDismissRequest = { CrashLog.clear(hctx); crash = null },
            title = { Text("Приложение закрывалось с ошибкой") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(c.lines().take(30).joinToString("\n"), fontSize = 11.sp) } },
            confirmButton = {
                TextButton(onClick = {
                    hctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("crash", c))
                    Toast.makeText(hctx, "Скопировано", Toast.LENGTH_SHORT).show()
                }) { Text("Скопировать") }
            },
            dismissButton = { TextButton(onClick = { CrashLog.clear(hctx); crash = null }) { Text("Закрыть") } }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GroupRow(g: Group, onPick: () -> Unit = {}) {
    val sel0 = Store.selected
    val groupSel = sel0 == "g:" + g.key
    val kinds = g.items.groupBy { it.kind }
    val selHere = groupSel || (sel0 != null && (sel0.startsWith("gk:" + g.key + "|") || g.items.any { it.id == sel0 }))
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(if (selHere) Color(0xFF222C55) else Card).padding(start = 14.dp, top = 6.dp, bottom = 12.dp, end = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                g.name, color = Color.White, maxLines = 2,
                modifier = Modifier.weight(1f).clickable {
                    Store.selected = if (g.items.size > 1) "g:" + g.key else g.items.first().id
                    Store.save(); onPick()
                }.padding(vertical = 8.dp)
            )
            TextButton(onClick = { g.items.forEach { Store.removeServer(it.id) } }) { Text("✕", color = Dim) }
        }
        if (groupSel) Text("авто: само выберет рабочий из ${g.items.size}", color = Accent, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
        FlowRow(Modifier.padding(end = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            kinds.forEach { (kind, list) ->
                val target = if (list.size == 1) list[0].id else "gk:" + g.key + "|" + kind
                val sel = sel0 == target
                val ping = list.filter { !it.isUdp }.mapNotNull { Store.pings[it.id]?.takeIf { p -> p >= 0 } }.minOrNull()
                Row(
                    Modifier.clip(RoundedCornerShape(8.dp)).background(if (sel) Accent else Color(0xFF252E4D))
                        .clickable { Store.selected = target; Store.save(); onPick() }.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (list.size > 1) "$kind ×${list.size}" else kind, color = Color.White, fontSize = 12.sp)
                    if (ping != null) Text("  $ping мс", color = if (sel) Color.White else Green, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun ServersScreen(startWithAdd: Boolean = false, onPick: () -> Unit = {}) {
    val scope = rememberCoroutineScope()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var showAdd by remember { mutableStateOf(startWithAdd) }
    var busy by remember { mutableStateOf(false) }
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    fun refresh(sub: Sub) {
        scope.launch {
            busy = true
            val l = loadSub(sub.url)
            val r = l.result
            if (r == null || r.links.isEmpty()) {
                Store.subInfo[sub.id] = l.diag
                toast("Серверы не найдены — подробности под названием подписки")
            } else {
                Store.subInfo.remove(sub.id)
                Store.replaceSub(sub.id, r.links)
                val title = l.title
                if (!title.isNullOrBlank()) {
                    val i = Store.subs.indexOfFirst { it.id == sub.id }
                    if (i >= 0) { Store.subs[i] = Store.subs[i].copy(name = title); Store.save() }
                }
                toast("Загружено подключений: ${r.links.size} (${r.format})")
            }
            busy = false
        }
    }

    fun pingAll() {
        Store.servers.toList().filter { !it.isUdp }.forEach { s ->
            scope.launch(Dispatchers.IO) {
                val hp = Parser.hostPort(s.link) ?: return@launch
                val t = System.currentTimeMillis()
                val ms = runCatching { Socket().use { it.connect(InetSocketAddress(hp.first, hp.second), 3000) }; (System.currentTimeMillis() - t).toInt() }.getOrDefault(-1)
                Store.pings[s.id] = ms
            }
        }
    }

    fun handleAdd(text: String) {
        if (text.startsWith("happ://crypt", true)) {
            toast("Это зашифрованная ссылка Happ — такие не поддерживаются. Нужна обычная ссылка подписки (https://…)"); return
        }
        val url = extractSubUrl(text)
        if (url != null) {
            val sub = Sub(Store.idOf(url), runCatching { URL(url).host }.getOrDefault("Подписка"), url)
            if (Store.subs.none { it.id == sub.id }) Store.subs.add(sub)
            Store.save(); refresh(sub)
        } else {
            val r = Subscription.parse(text)
            val n = Store.addLinks(r.links, null)
            toast(if (n > 0) "Добавлено ключей: $n" else "Не удалось распознать. Вставь ключ (vless://…) или ссылку подписки (https://…)")
        }
    }

    val servers = Store.servers.toList()
    val subs = Store.subs.toList()
    val bySub = remember(servers) { servers.groupBy { it.subId }.mapValues { groupsOf(it.value) } }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { showAdd = true }) { Text("+ Добавить") }
            OutlinedButton(onClick = { pingAll() }) { Text("Пинг") }
            OutlinedButton(onClick = {
                val txt = servers.mapIndexed { i, sv -> "${i + 1}. ${sv.name} | ${sv.kind}" }.joinToString("\n")
                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("servers", txt))
                toast("Список серверов скопирован (${servers.size})")
            }) { Text("Список") }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        if (subs.isEmpty() && servers.isEmpty()) {
            Text("Нажми «+ Добавить» и вставь ключ или ссылку подписки — приложение само разберётся, что это.", color = Dim, modifier = Modifier.padding(top = 20.dp))
        }
        LazyColumn(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (servers.isNotEmpty()) item(key = "auto", contentType = "auto") {
                val sel = Store.selected == "auto"
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(if (sel) Color(0xFF222C55) else Card)
                        .clickable { Store.selected = "auto"; Store.save(); onPick() }.padding(14.dp)
                ) {
                    Text("⚡ Авто", color = Color.White)
                    Text("Сам выбирает рабочий сервер из всех (удобно, если часть серверов блокируется)" + if (sel) " • по умолчанию" else "", color = if (sel) Accent else Dim, fontSize = 12.sp)
                }
            }
            subs.forEach { sub ->
                val groups = bySub[sub.id].orEmpty()
                val total = groups.sumOf { it.items.size }
                item(key = "sub" + sub.id, contentType = "sub") {
                    Column {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF1B2340)).padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("📡 ${sub.name}", color = Color.White, maxLines = 1)
                            Text("Серверов: ${groups.size} · подключений: $total", color = Dim, fontSize = 12.sp)
                        }
                        TextButton(onClick = { refresh(sub) }) { Text("Обновить") }
                        TextButton(onClick = { Store.removeSub(sub.id) }) { Text("✕") }
                    }
                    if (groups.isEmpty()) Store.subInfo[sub.id]?.let {
                        Text(it, color = Color(0xFFFF9A6B), fontSize = 11.sp, modifier = Modifier.padding(start = 12.dp, top = 6.dp, end = 8.dp))
                    }
                    }
                }
                items(groups, key = { "g" + sub.id + it.key }, contentType = { "group" }) { GroupRow(it, onPick) }
            }
            val loose = bySub[null].orEmpty()
            if (loose.isNotEmpty()) {
                item(key = "loose", contentType = "sub") { Text("🔑 Отдельные ключи", color = Dim, modifier = Modifier.padding(top = 8.dp)) }
                items(loose, key = { "l" + it.key }, contentType = { "group" }) { GroupRow(it, onPick) }
            }
        }
    }

    if (showAdd) {
        var a by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Добавить") },
            text = {
                Column {
                    Text("Вставь ключ (vless://…) или ссылку подписки (https://… или happ://add/…). Ключ — это один сервер, подписка — целый список.", fontSize = 13.sp)
                    OutlinedTextField(a, { a = it }, Modifier.padding(top = 8.dp), label = { Text("Ключ или подписка") }, minLines = 3)
                }
            },
            confirmButton = { TextButton(onClick = { val t = a.trim(); showAdd = false; if (t.isNotEmpty()) handleAdd(t) }) { Text("Добавить") } },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Отмена") } }
        )
    }
}

class AppInfo(val pkg: String, val label: String, val icon: ImageBitmap?)

@Composable
fun AppsScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var q by remember { mutableStateOf("") }
    val apps by produceState(emptyList<AppInfo>()) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0).map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .filter { it.first != ctx.packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
                .map { (pkg, label) ->
                    AppInfo(pkg, label, runCatching { pm.getApplicationIcon(pkg).toBitmap(72, 72).asImageBitmap() }.getOrNull())
                }
        }
    }
    val all = Store.servers.toList()
    val counts = remember(all) { all.groupingBy { it.gkey }.eachCount() }
    fun labelOf(s: Server) = if ((counts[s.gkey] ?: 1) > 1) "${s.clean} · ${s.kind}" else s.clean
    val allGroups = remember(all) { groupsOf(all) }
    val list = apps.filter { it.label.contains(q, true) }.sortedByDescending { Store.appRules.containsKey(it.pkg) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Какой сервер для какого приложения", color = Color.White, fontWeight = FontWeight.SemiBold)
        Text("Остальные приложения идут через сервер по умолчанию. Изменения применяются сами, если VPN включён.", color = Dim, fontSize = 12.sp)
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp), label = { Text("Поиск") }, singleLine = true)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.pkg }, contentType = { "app" }) { app ->
                var menu by remember { mutableStateOf(false) }
                val rule = Store.appRules[app.pkg]
                val ruleText = when {
                    rule == null -> "По умолчанию"
                    rule == "direct" -> "Напрямую"
                    else -> Store.describe(rule)
                }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Card).clickable { menu = true }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (app.icon != null) Image(app.icon, null, Modifier.size(36.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(app.label, color = Color.White, maxLines = 1)
                        Text(ruleText, color = if (rule == null) Dim else Accent, fontSize = 12.sp, maxLines = 1)
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("По умолчанию") }, onClick = { Store.appRules.remove(app.pkg); Store.save(); menu = false })
                        DropdownMenuItem(text = { Text("Напрямую (без VPN)") }, onClick = { Store.appRules[app.pkg] = "direct"; Store.save(); menu = false })
                        allGroups.forEach { g ->
                            val target = if (g.items.size > 1) "g:" + g.key else g.items.first().id
                            DropdownMenuItem(
                                text = { Text(if (g.items.size > 1) "${g.name} (авто)" else g.name) },
                                onClick = { Store.appRules[app.pkg] = target; Store.save(); menu = false }
                            )
                        }
                    }
                }
            }
        }
    }
}
