package app.vpnhub

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

private val Bg = Color(0xFF0B0F1A)
private val Card = Color(0xFF151B2B)
private val Accent = Color(0xFF6C7BFF)
private val Accent2 = Color(0xFF9B5CFF)
private val Green = Color(0xFF2ED3A0)
private val Dim = Color(0xFF8A93A8)

class MainActivity : ComponentActivity() {
    private val vpnPerm = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) startVpn()
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(applicationContext)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card)) {
                Root { toggle() }
            }
        }
    }

    private fun toggle() {
        if (Vpn.state != "off") { startService(Intent(this, HubVpnService::class.java).setAction("stop")); return }
        if (Store.servers.none { it.id == Store.selected }) {
            Toast.makeText(this, "Сначала добавь сервер", Toast.LENGTH_SHORT).show(); return
        }
        val i = VpnService.prepare(this)
        if (i != null) vpnPerm.launch(i) else startVpn()
    }

    private fun startVpn() {
        ContextCompat.startForegroundService(this, Intent(this, HubVpnService::class.java).setAction("start"))
    }
}

fun fetchText(url: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 15000; c.readTimeout = 20000
    c.setRequestProperty("User-Agent", "Happ/2.7.0")
    c.setRequestProperty("x-hwid", Store.hwid())
    c.setRequestProperty("x-device-os", "Android")
    c.setRequestProperty("x-ver-os", Build.VERSION.RELEASE)
    c.setRequestProperty("x-device-model", Build.MODEL)
    return c.inputStream.bufferedReader().readText()
}

fun extractSubUrl(t: String): String? {
    val s = t.trim()
    val l = s.lowercase()
    if (l.startsWith("http://") || l.startsWith("https://")) return s
    val prefixes = listOf(
        "happ://add/", "hiddify://import/", "sing-box://import-remote-profile?url=",
        "v2rayng://install-sub?url=", "v2box://install-sub?url=", "clash://install-config?url=",
        "clashmeta://install-config?url=", "streisand://import/"
    )
    for (p in prefixes) if (l.startsWith(p)) return Uri.decode(s.substring(p.length)).substringBefore('#')
    return null
}

@Composable
fun PowerIcon(modifier: Modifier = Modifier, color: Color = Color.White) {
    Canvas(modifier) {
        val w = size.minDimension
        val sw = w * 0.1f
        val inset = sw * 1.2f
        drawArc(
            color = color, startAngle = -55f, sweepAngle = 290f, useCenter = false,
            topLeft = Offset(inset, inset + w * 0.06f),
            size = androidx.compose.ui.geometry.Size(w - inset * 2, w - inset * 2 - w * 0.06f),
            style = Stroke(width = sw, cap = StrokeCap.Round)
        )
        drawLine(color, Offset(w / 2, sw), Offset(w / 2, w * 0.52f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

fun decodeSub(body: String): List<String> {
    val t = body.trim()
    val text = if (t.contains("://")) t else runCatching { Parser.b64(t) }.getOrDefault(t)
    return text.lines().map { it.trim() }.filter { it.contains("://") }
}

@Composable
fun Root(onToggle: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Card) {
                listOf("🏠 Главная", "🌐 Серверы", "📱 Приложения").forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(t, fontSize = 12.sp) }, alwaysShowLabel = true)
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(onToggle)
                1 -> ServersScreen()
                else -> AppsScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(onToggle: () -> Unit) {
    val on = Vpn.state == "on"
    val starting = Vpn.state == "starting"
    val srv = Store.servers.firstOrNull { it.id == Store.selected }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("VPN Hub", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(40.dp))
        val brush = if (on) Brush.linearGradient(listOf(Green, Color(0xFF1AA37A))) else Brush.linearGradient(listOf(Accent, Accent2))
        Box(
            Modifier.size(190.dp).clip(CircleShape).background(brush).clickable { onToggle() },
            contentAlignment = Alignment.Center
        ) {
            if (starting) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(64.dp))
            else PowerIcon(Modifier.size(88.dp))
        }
        Spacer(Modifier.height(28.dp))
        Text(
            when (Vpn.state) { "on" -> "Подключено"; "starting" -> "Подключение…"; else -> "Отключено" },
            fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = if (on) Green else Color.White
        )
        Spacer(Modifier.height(20.dp))
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Сервер по умолчанию", color = Dim, fontSize = 12.sp)
                Text(srv?.name ?: "не выбран — открой «Серверы»", color = Color.White, fontSize = 16.sp)
                if (srv != null) Text(srv.proto, color = Dim, fontSize = 12.sp)
            }
        }
        Vpn.error?.let { Spacer(Modifier.height(12.dp)); Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp) }
    }
}

@Composable
fun ServersScreen() {
    val scope = rememberCoroutineScope()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var dlg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    fun refresh(sub: Sub) = scope.launch {
        busy = true
        try {
            val links = withContext(Dispatchers.IO) { decodeSub(fetchText(sub.url)) }
            Store.replaceSub(sub.id, links); toast("${sub.name}: ${links.size} серверов")
        } catch (e: Exception) { toast("Ошибка: ${e.message}") }
        busy = false
    }

    fun pingAll() = scope.launch {
        Store.servers.toList().forEach { s ->
            launch(Dispatchers.IO) {
                val u = Parser.parseUrl(s.link)
                val host: String; val port: Int
                if (u != null) { host = u.host; port = u.port } else return@launch
                val t = System.currentTimeMillis()
                val ms = runCatching { Socket().use { it.connect(InetSocketAddress(host, port), 3000) }; (System.currentTimeMillis() - t).toInt() }.getOrDefault(-1)
                Store.pings[s.id] = ms
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { dlg = "key" }) { Text("+ Ключ") }
            Button(onClick = { dlg = "sub" }) { Text("+ Подписка") }
            OutlinedButton(onClick = { pingAll() }) { Text("Пинг") }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        LazyColumn(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(Store.subs.toList(), key = { "sub" + it.id }) { sub ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF1B2340)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("📡 ${sub.name}", color = Color.White, modifier = Modifier.weight(1f))
                    TextButton(onClick = { refresh(sub) }) { Text("Обновить") }
                    TextButton(onClick = { Store.removeSub(sub.id) }) { Text("✕") }
                }
            }
            items(Store.servers.toList(), key = { it.id }) { s ->
                val sel = Store.selected == s.id
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(if (sel) Color(0xFF222C55) else Card)
                        .clickable { Store.selected = s.id; Store.save() }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(s.name, color = Color.White, maxLines = 1)
                        Text(s.proto + (if (sel) " • по умолчанию" else ""), color = Dim, fontSize = 12.sp)
                    }
                    Store.pings[s.id]?.let { Text(if (it < 0) "—" else "$it мс", color = if (it < 0) Dim else Green, fontSize = 13.sp) }
                    TextButton(onClick = { Store.removeServer(s.id) }) { Text("✕", color = Dim) }
                }
            }
        }
    }

    if (dlg != null) {
        var a by remember { mutableStateOf("") }
        var b by remember { mutableStateOf("") }
        val isKey = dlg == "key"
        AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text(if (isKey) "Добавить ключ" else "Добавить подписку") },
            text = {
                Column {
                    if (!isKey) OutlinedTextField(b, { b = it }, label = { Text("Название") }, singleLine = true)
                    OutlinedTextField(a, { a = it }, label = { Text(if (isKey) "Ключ или ссылка из Happ" else "Ссылка подписки (https:// или happ://add/)") }, minLines = 2)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val text = a.trim(); val d = dlg; dlg = null
                    val subUrl = extractSubUrl(text)
                    if (text.startsWith("happ://crypt", true)) {
                        toast("Это зашифрованная ссылка Happ — такие не поддерживаются. Попроси у провайдера обычную ссылку подписки (https://…)")
                    } else if (d == "sub" || subUrl != null) {
                        val url = subUrl ?: text
                        if (url.isNotEmpty()) {
                            val sub = Sub(Store.idOf(url), b.ifBlank { "Подписка" }, url)
                            if (Store.subs.none { it.id == sub.id }) Store.subs.add(sub)
                            Store.save(); refresh(sub)
                        }
                    } else {
                        val n = Store.addLinks(decodeSub(text), null)
                        toast(if (n > 0) "Добавлено: $n" else "Ключ не распознан")
                    }
                }) { Text("Добавить") }
            },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Отмена") } }
        )
    }
}

data class AppInfo(val pkg: String, val label: String)

@Composable
fun AppsScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var q by remember { mutableStateOf("") }
    val apps by produceState(emptyList<AppInfo>()) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0).map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
                .filter { it.pkg != ctx.packageName }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
        }
    }
    val list = apps.filter { it.label.contains(q, true) }
        .sortedByDescending { Store.appRules.containsKey(it.pkg) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Какой сервер для какого приложения", color = Color.White, fontWeight = FontWeight.SemiBold)
        Text("Остальные приложения идут через сервер по умолчанию", color = Dim, fontSize = 12.sp)
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp), label = { Text("Поиск") }, singleLine = true)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.pkg }) { app ->
                var menu by remember { mutableStateOf(false) }
                val icon = remember(app.pkg) { runCatching { ctx.packageManager.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull() }
                val rule = Store.appRules[app.pkg]
                val ruleText = when {
                    rule == null -> "По умолчанию"
                    rule == "direct" -> "Напрямую"
                    else -> Store.servers.firstOrNull { it.id == rule }?.name ?: "По умолчанию"
                }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Card).clickable { menu = true }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (icon != null) Image(icon, null, Modifier.size(36.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(app.label, color = Color.White, maxLines = 1)
                        Text(ruleText, color = if (rule == null) Dim else Accent, fontSize = 12.sp, maxLines = 1)
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("По умолчанию") }, onClick = { Store.appRules.remove(app.pkg); Store.save(); menu = false })
                        DropdownMenuItem(text = { Text("Напрямую (без VPN)") }, onClick = { Store.appRules[app.pkg] = "direct"; Store.save(); menu = false })
                        Store.servers.forEach { s ->
                            DropdownMenuItem(text = { Text(s.name) }, onClick = { Store.appRules[app.pkg] = s.id; Store.save(); menu = false })
                        }
                    }
                }
            }
        }
    }
}
