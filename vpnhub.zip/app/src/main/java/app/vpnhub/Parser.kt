package app.vpnhub

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

object Parser {
    class U(val scheme: String, val user: String?, val host: String, val port: Int, val q: Map<String, String>, val frag: String)

    fun b64(s: String): String =
        String(Base64.decode(s.trim().replace('-', '+').replace('_', '/'), Base64.DEFAULT), Charsets.UTF_8)

    fun parseUrl(link: String): U? = runCatching {
        val scheme = link.substringBefore("://").lowercase()
        var rest = link.substringAfter("://")
        val frag = Uri.decode(rest.substringAfter('#', ""))
        rest = rest.substringBefore('#')
        val query = rest.substringAfter('?', "")
        rest = rest.substringBefore('?')
        var auth = rest.substringBefore('/')
        var user: String? = null
        if (scheme == "ss" && !auth.contains('@')) auth = b64(auth) // legacy ss://base64(method:pass@host:port)
        if (auth.contains('@')) user = auth.substringBeforeLast('@')
        val hp = auth.substringAfterLast('@')
        val host: String
        val port: Int
        if (hp.startsWith("[")) {
            host = hp.substring(1, hp.indexOf(']'))
            port = hp.substringAfter("]:", "443").toInt()
        } else {
            host = hp.substringBeforeLast(':')
            port = hp.substringAfterLast(':', "443").toInt()
        }
        val q = query.split('&').filter { it.isNotEmpty() }
            .associate { it.substringBefore('=') to Uri.decode(it.substringAfter('=', "")) }
        U(scheme, user?.let { if (scheme == "ss") it else Uri.decode(it) }, host, port, q, frag)
    }.getOrNull()

    private val noise = Regex("(?i)\\b(vless|vmess|trojan|hysteria2|hysteria|hy2|reality|xtls|tcp|udp|ws|grpc|xhttp|httpupgrade|tls|quic|ss)\\b")

    fun cleanName(name: String): String {
        val c = name.replace(noise, " ").replace(Regex("[\\[\\]()|·•_+]+"), " ").replace(Regex("\\s*[-–—]\\s*$"), "")
            .replace(Regex("\\s+"), " ").trim().trim('-', '–', '—', ' ')
        return c.ifEmpty { name }
    }

    fun groupKey(s: Server): String {
        val k = cleanName(s.name).lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), "")
        return k.ifEmpty { hostPort(s.link)?.first ?: s.id }
    }

    fun kind(link: String): String = runCatching {
        if (link.startsWith("json:")) {
            val o = JSONObject(link.removePrefix("json:"))
            val t = o.optString("type").uppercase()
            val tr = o.optJSONObject("transport")?.optString("type").orEmpty()
            val re = o.optJSONObject("tls")?.optJSONObject("reality") != null
            return@runCatching when { re -> "$t Reality"; tr.isNotEmpty() -> "$t ${tr.uppercase()}"; else -> t }
        }
        val scheme = link.substringBefore("://").lowercase()
        if (scheme == "vmess") {
            val net = JSONObject(b64(link.substringAfter("://"))).optString("net", "tcp")
            return@runCatching "VMESS" + if (net != "tcp" && net.isNotEmpty()) " " + net.uppercase() else ""
        }
        val u = parseUrl(link)!!
        val t = when (scheme) { "hy2", "hysteria2" -> "HYSTERIA2"; else -> scheme.uppercase() }
        val net = u.q["type"].orEmpty()
        when {
            u.q["security"] == "reality" -> "$t Reality"
            net in setOf("ws", "grpc", "xhttp", "httpupgrade", "h2", "http") -> "$t ${net.uppercase()}"
            else -> t
        }
    }.getOrDefault("?")

    fun hostPort(link: String): Pair<String, Int>? = runCatching {
        if (link.startsWith("json:")) {
            val o = JSONObject(link.removePrefix("json:")); o.getString("server") to o.getInt("server_port")
        } else if (link.startsWith("vmess://")) {
            val j = JSONObject(b64(link.substringAfter("://"))); j.getString("add") to j.get("port").toString().toInt()
        } else parseUrl(link)?.let { it.host to it.port }
    }.getOrNull()

    fun nameOf(link: String): String? {
        if (link.startsWith("json:")) return runCatching {
            val o = JSONObject(link.removePrefix("json:"))
            o.optString("tag").ifEmpty { o.optString("type") }
        }.getOrNull()
        val scheme = link.substringBefore("://", "").lowercase()
        if (scheme !in setOf("vless", "vmess", "trojan", "ss", "hysteria2", "hy2")) return null
        if (scheme == "vmess") return runCatching {
            JSONObject(b64(link.substringAfter("://"))).optString("ps").ifEmpty { "vmess" }
        }.getOrNull()
        val u = parseUrl(link) ?: return null
        return u.frag.ifEmpty { u.host }
    }

    private fun tls(q: Map<String, String>, host: String, force: Boolean = false): JSONObject? {
        val sec = q["security"] ?: if (force) "tls" else "none"
        if (sec == "none") return null
        val t = JSONObject().put("enabled", true).put("server_name", q["sni"] ?: q["host"] ?: host)
        if (q["allowInsecure"] == "1" || q["insecure"] == "1") t.put("insecure", true)
        q["alpn"]?.takeIf { it.isNotEmpty() }?.let { t.put("alpn", JSONArray(it.split(','))) }
        val fp = q["fp"]?.takeIf { it.isNotEmpty() }
        if (fp != null) t.put("utls", JSONObject().put("enabled", true).put("fingerprint", fp))
        if (sec == "reality") {
            t.put("reality", JSONObject().put("enabled", true).put("public_key", q["pbk"] ?: "").put("short_id", q["sid"] ?: ""))
            if (fp == null) t.put("utls", JSONObject().put("enabled", true).put("fingerprint", "chrome"))
        }
        return t
    }

    private fun transport(q: Map<String, String>): JSONObject? {
        val host = q["host"]?.takeIf { it.isNotEmpty() }
        return when (q["type"]) {
            "ws" -> JSONObject().put("type", "ws").put("path", q["path"] ?: "/").also { if (host != null) it.put("headers", JSONObject().put("Host", host)) }
            "grpc" -> JSONObject().put("type", "grpc").put("service_name", q["serviceName"] ?: "")
            "httpupgrade" -> JSONObject().put("type", "httpupgrade").put("path", q["path"] ?: "/").also { if (host != null) it.put("host", host) }
            "http", "h2" -> JSONObject().put("type", "http").put("path", q["path"] ?: "/").also { if (host != null) it.put("host", JSONArray(listOf(host))) }
            else -> null
        }
    }

    fun outbound(s: Server, tag: String): JSONObject? = runCatching {
        val link = s.link
        if (link.startsWith("json:")) return@runCatching JSONObject(link.removePrefix("json:")).put("tag", tag)
        val scheme = link.substringBefore("://").lowercase()
        if (scheme == "vmess") {
            val j = JSONObject(b64(link.substringAfter("://")))
            val net = j.optString("net", "tcp")
            val q = mutableMapOf(
                "type" to net, "host" to j.optString("host"), "path" to j.optString("path"),
                "security" to (if (j.optString("tls") == "tls") "tls" else "none"),
                "sni" to j.optString("sni"), "alpn" to j.optString("alpn"), "fp" to j.optString("fp"),
                "serviceName" to j.optString("path")
            )
            val o = JSONObject().put("type", "vmess").put("tag", tag).put("server", j.getString("add"))
                .put("server_port", j.get("port").toString().toInt()).put("uuid", j.getString("id"))
                .put("security", j.optString("scy", "auto").ifEmpty { "auto" })
                .put("alter_id", j.optString("aid", "0").toIntOrNull() ?: 0)
            tls(q, j.getString("add"))?.let { o.put("tls", it) }
            transport(q)?.let { o.put("transport", it) }
            return@runCatching o
        }
        val u = parseUrl(link) ?: return@runCatching null
        val o = JSONObject().put("tag", tag).put("server", u.host).put("server_port", u.port)
        when (scheme) {
            "vless" -> {
                o.put("type", "vless").put("uuid", u.user ?: "").put("packet_encoding", "xudp")
                u.q["flow"]?.takeIf { it.isNotEmpty() }?.let { o.put("flow", it) }
                tls(u.q, u.host)?.let { o.put("tls", it) }
                transport(u.q)?.let { o.put("transport", it) }
            }
            "trojan" -> {
                o.put("type", "trojan").put("password", u.user ?: "")
                tls(u.q, u.host, force = true)?.let { o.put("tls", it) }
                transport(u.q)?.let { o.put("transport", it) }
            }
            "ss" -> {
                val ui = u.user ?: ""
                val mp = if (ui.contains(':')) Uri.decode(ui) else b64(Uri.decode(ui))
                o.put("type", "shadowsocks").put("method", mp.substringBefore(':')).put("password", mp.substringAfter(':'))
            }
            "hysteria2", "hy2" -> {
                o.put("type", "hysteria2").put("password", u.user ?: "")
                tls(u.q, u.host, force = true)?.let { o.put("tls", it) }
                u.q["obfs"]?.takeIf { it.isNotEmpty() }?.let {
                    o.put("obfs", JSONObject().put("type", it).put("password", u.q["obfs-password"] ?: ""))
                }
            }
            else -> return@runCatching null
        }
        o
    }.getOrNull()
}
