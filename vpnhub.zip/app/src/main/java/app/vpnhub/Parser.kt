package app.vpnhub

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

object Parser {
    private val unsupportedNet = setOf("xhttp", "splithttp", "kcp", "mkcp", "quic")
    /** Протоколы, которые ядро sing-box 1.11 не умеет (AnyTLS появился в 1.12, Naive — в 1.13): показываем с ⚠, в конфиг не кладём. */
    private val unsupportedSchemes = setOf("anytls", "naive+https", "naive+quic")
    /** Типы outbound, которые есть в sing-box 1.11 (для sing-box JSON-подписок). */
    private val coreTypes = setOf("vless", "vmess", "trojan", "shadowsocks", "hysteria2", "hysteria", "tuic", "wireguard", "socks", "http", "ssh", "shadowtls")
    /** Все схемы ссылок, которые мы разбираем. */
    val linkSchemes = setOf("vless", "vmess", "trojan", "ss", "hysteria2", "hy2", "hysteria", "hy", "tuic", "wireguard", "wg",
        "socks", "socks4", "socks5", "socks5h", "ssh", "anytls", "naive+https", "naive+quic")

    class U(val scheme: String, val user: String?, val host: String, val port: Int, val q: Map<String, String>, val frag: String)

    fun b64(s: String): String =
        String(Base64.decode(s.trim().replace('-', '+').replace('_', '/'), Base64.DEFAULT), Charsets.UTF_8)

    fun parseUrl(link: String): U? = runCatching {
        val scheme = link.substringBefore("://").lowercase()
        var rest = link.substringAfter("://")
        val frag = Uri.decode(rest.substringAfter('#', ""))
        rest = rest.substringBefore('#')
        val query = rest.substringAfter('?', "")
        rest = rest.substringBefore('?')
        var auth = rest.substringBefore('/')
        if (scheme == "wireguard" || scheme == "wg") {   // приватный ключ WireGuard — base64 и может содержать «/» без кодирования
            val at = rest.lastIndexOf('@')
            if (at >= 0) auth = rest.substring(0, at) + "@" + rest.substring(at + 1).substringBefore('/')
        }
        var user: String? = null
        if (scheme == "ss" && !auth.contains('@')) auth = b64(auth) // legacy ss://base64(method:pass@host:port)
        if (auth.contains('@')) user = auth.substringBeforeLast('@')
        val hp = auth.substringAfterLast('@')
        val host: String
        val port: Int
        if (hp.startsWith("[")) {
            host = hp.substring(1, hp.indexOf(']'))
            port = hp.substringAfter("]:", "443").toInt()
        } else {
            host = hp.substringBeforeLast(':')
            port = hp.substringAfterLast(':', "443").toInt()
        }
        val q = query.split('&').filter { it.isNotEmpty() }
            .associate { it.substringBefore('=') to Uri.decode(it.substringAfter('=', "")) }
        U(scheme, user?.let { if (scheme == "ss") it else Uri.decode(it) }, host, port, q, frag)
    }.getOrNull()

    private val noise = Regex("(?i)\\b(vless|vmess|trojan|hysteria2|hysteria|hy2|tuic|wireguard|anytls|reality|xtls|tcp|udp|ws|grpc|xhttp|httpupgrade|tls|quic|ss)\\b")

    // хвост вида " 🛡1", " 🚀2", " 🌐3" — номер ключа внутри одного сервера
    private val keyMarker = Regex("\\s*[^\\p{L}\\p{N}\\s]+\\d+\\s*$")

    fun cleanName(name: String): String {
        val c = name.replace(keyMarker, "").replace(noise, " ").replace(Regex("[\\[\\]()|·•_+]+"), " ").replace(Regex("\\s*[-–—]\\s*$"), "")
            .replace(Regex("\\s+"), " ").trim().trim('-', '–', '—', ' ')
        return c.ifEmpty { name }
    }

    fun groupKey(s: Server): String {
        val k = cleanName(s.name).lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), "")
        return k.ifEmpty { hostPort(s.link)?.first ?: s.id }
    }

    private fun obKind(o: JSONObject): String {
        val t = o.optString("type").uppercase()
        val tr = o.optJSONObject("transport")?.optString("type").orEmpty()
        val re = o.optJSONObject("tls")?.optJSONObject("reality") != null
        val bad = o.optString("_net").ifEmpty { if (o.optString("type") !in coreTypes) "не поддерживается" else "" }
        return when { bad.isNotEmpty() -> "$t ${bad.uppercase()} ⚠"; re -> "$t Reality"; tr.isNotEmpty() -> "$t ${tr.uppercase()}"; else -> t }
    }

    fun kind(link: String): String = runCatching {
        if (link.startsWith("json:")) {
            val o = JSONObject(link.removePrefix("json:"))
            if (o.optBoolean("multi")) {
                val a = o.getJSONArray("outbounds")
                return@runCatching (0 until a.length()).map { obKind(a.getJSONObject(it)) }.distinct().joinToString(" + ")
            }
            return@runCatching obKind(o)
        }
        val scheme = link.substringBefore("://").lowercase()
        if (scheme == "vmess") {
            val net = JSONObject(b64(link.substringAfter("://"))).optString("net", "tcp")
            return@runCatching "VMESS" + if (net != "tcp" && net.isNotEmpty()) " " + net.uppercase() + (if (net in unsupportedNet) " ⚠" else "") else ""
        }
        val u = parseUrl(link)!!
        val t = when (scheme) {
            "hy2", "hysteria2" -> "HYSTERIA2"; "hy", "hysteria" -> "HYSTERIA"; "wg", "wireguard" -> "WIREGUARD"
            "socks", "socks4", "socks5", "socks5h" -> "SOCKS"; "naive+https", "naive+quic" -> "NAIVE"; else -> scheme.uppercase()
        }
        val net = u.q["type"].orEmpty()
        when {
            scheme in unsupportedSchemes -> "$t ⚠"
            scheme in setOf("hy", "hysteria") && (u.q["protocol"] ?: "udp") != "udp" -> "$t ${u.q["protocol"]!!.uppercase()} ⚠"
            net in unsupportedNet -> "$t ${net.uppercase()} ⚠"
            u.q["security"] == "reality" -> "$t Reality"
            net in setOf("ws", "grpc", "xhttp", "httpupgrade", "h2", "http") -> "$t ${net.uppercase()}"
            else -> t
        }
    }.getOrDefault("?")

    /** Все outbound'ы сервера: у сервера из нескольких ключей — каждый ключ + urltest под общим тегом. */
    fun outbounds(s: Server, tag: String): List<JSONObject> = runCatching {
        if (s.link.startsWith("json:")) {
            val o = JSONObject(s.link.removePrefix("json:"))
            if (o.optBoolean("multi")) {
                val arr = o.getJSONArray("outbounds")
                val good = (0 until arr.length()).map { arr.getJSONObject(it) }.filter { !it.has("_net") && it.optString("type") in coreTypes }
                    .map { JSONObject(it.toString()) }
                if (good.isEmpty()) return@runCatching emptyList<JSONObject>()
                if (good.size == 1) return@runCatching listOf(good[0].put("tag", tag))
                val kids = good.mapIndexed { i, k -> k.put("tag", "$tag-$i") }
                val ut = JSONObject().put("type", "urltest").put("tag", tag)
                    .put("outbounds", JSONArray(kids.map { it.getString("tag") }))
                    .put("url", "https://www.gstatic.com/generate_204").put("interval", "3m").put("tolerance", 50)
                return@runCatching kids + ut
            }
        }
        listOfNotNull(outbound(s, tag))
    }.getOrDefault(emptyList())

    /** Ключ «это один и тот же сервер с теми же параметрами» — имя не учитывается. */
    fun endpointKey(link: String): String = runCatching {
        when {
            link.startsWith("json:") -> {
                val o = JSONObject(link.removePrefix("json:"))
                fun clean(x: JSONObject) = JSONObject(x.toString()).also { it.remove("tag") }.toString()
                if (o.optBoolean("multi")) {
                    val a = o.getJSONArray("outbounds")
                    (0 until a.length()).joinToString("|") { clean(a.getJSONObject(it)) }
                } else clean(o)
            }
            link.startsWith("vmess://") -> JSONObject(b64(link.substringAfter("://"))).also { it.remove("ps") }.toString()
            else -> link.substringBefore('#')
        }
    }.getOrDefault(link)

    /** Служебная запись подписки («осталось N дней», «подписка истекла»): адрес 127.0.0.1/0.0.0.0 и порт 0–1. Это не сервер, трафик через неё не пойдёт. */
    fun placeholder(link: String): Boolean {
        val hp = hostPort(link) ?: return false
        val h = hp.first.trim().lowercase()
        return h.isEmpty() || h == "localhost" || h == "0.0.0.0" || h == "::" || h == "::1" || h.startsWith("127.") || hp.second <= 1
    }

    fun hostPort(link: String): Pair<String, Int>? = runCatching {
        if (link.startsWith("json:")) {
            val o = JSONObject(link.removePrefix("json:"))
            val ob = if (o.optBoolean("multi")) {
                val a = o.getJSONArray("outbounds")
                val l = (0 until a.length()).map { a.getJSONObject(it) }
                l.firstOrNull { it.optString("type") !in setOf("hysteria2", "hysteria", "tuic", "wireguard") } ?: l.first()
            } else o
            ob.getString("server") to ob.getInt("server_port")
        } else if (link.startsWith("vmess://")) {
            val j = JSONObject(b64(link.substringAfter("://"))); j.getString("add") to j.get("port").toString().toInt()
        } else parseUrl(link)?.let { it.host to it.port }
    }.getOrNull()

    fun nameOf(link: String): String? {
        if (link.startsWith("json:")) return runCatching {
            val o = JSONObject(link.removePrefix("json:"))
            o.optString("tag").ifEmpty { o.optString("type") }
        }.getOrNull()
        val scheme = link.substringBefore("://", "").lowercase()
        if (scheme !in linkSchemes) return null
        if (scheme == "vmess") return runCatching {
            JSONObject(b64(link.substringAfter("://"))).optString("ps").ifEmpty { "vmess" }
        }.getOrNull()
        val u = parseUrl(link) ?: return null
        return u.frag.ifEmpty { u.host }
    }

    private fun tls(q: Map<String, String>, host: String, force: Boolean = false): JSONObject? {
        val sec = q["security"] ?: if (force) "tls" else "none"
        if (sec == "none") return null
        val t = JSONObject().put("enabled", true).put("server_name", q["sni"] ?: q["host"] ?: host)
        if (q["allowInsecure"] == "1" || q["insecure"] == "1") t.put("insecure", true)
        q["alpn"]?.takeIf { it.isNotEmpty() }?.let { t.put("alpn", JSONArray(it.split(','))) }
        val fp = q["fp"]?.takeIf { it.isNotEmpty() }
        if (fp != null) t.put("utls", JSONObject().put("enabled", true).put("fingerprint", fp))
        if (sec == "reality") {
            t.put("reality", JSONObject().put("enabled", true).put("public_key", q["pbk"] ?: "").put("short_id", q["sid"] ?: ""))
            if (fp == null) t.put("utls", JSONObject().put("enabled", true).put("fingerprint", "chrome"))
        }
        return t
    }

    private fun transport(q: Map<String, String>): JSONObject? {
        val host = q["host"]?.takeIf { it.isNotEmpty() }
        return when (q["type"]) {
            "ws" -> JSONObject().put("type", "ws").put("path", q["path"] ?: "/").also { if (host != null) it.put("headers", JSONObject().put("Host", host)) }
            "grpc" -> JSONObject().put("type", "grpc").put("service_name", q["serviceName"] ?: "")
            "httpupgrade" -> JSONObject().put("type", "httpupgrade").put("path", q["path"] ?: "/").also { if (host != null) it.put("host", host) }
            "http", "h2" -> JSONObject().put("type", "http").put("path", q["path"] ?: "/").also { if (host != null) it.put("host", JSONArray(listOf(host))) }
            else -> null
        }
    }

    fun outbound(s: Server, tag: String): JSONObject? = runCatching {
        val link = s.link
        if (link.startsWith("json:")) {
            val j = JSONObject(link.removePrefix("json:"))
            return@runCatching if (j.has("_net") || j.optString("type") !in coreTypes) null else j.put("tag", tag)
        }
        val scheme = link.substringBefore("://").lowercase()
        if (scheme == "vmess") {
            val j = JSONObject(b64(link.substringAfter("://")))
            val net = j.optString("net", "tcp")
            if (net in unsupportedNet) return@runCatching null
            val q = mutableMapOf(
                "type" to net, "host" to j.optString("host"), "path" to j.optString("path"),
                "security" to (if (j.optString("tls") == "tls") "tls" else "none"),
                "sni" to j.optString("sni"), "alpn" to j.optString("alpn"), "fp" to j.optString("fp"),
                "serviceName" to j.optString("path")
            )
            val o = JSONObject().put("type", "vmess").put("tag", tag).put("server", j.getString("add"))
                .put("server_port", j.get("port").toString().toInt()).put("uuid", j.getString("id"))
                .put("security", j.optString("scy", "auto").ifEmpty { "auto" })
                .put("alter_id", j.optString("aid", "0").toIntOrNull() ?: 0)
            tls(q, j.getString("add"))?.let { o.put("tls", it) }
            transport(q)?.let { o.put("transport", it) }
            return@runCatching o
        }
        val u = parseUrl(link) ?: return@runCatching null
        if (u.q["type"] in unsupportedNet || scheme in unsupportedSchemes) return@runCatching null
        val o = JSONObject().put("tag", tag).put("server", u.host).put("server_port", u.port)
        when (scheme) {
            "vless" -> {
                o.put("type", "vless").put("uuid", u.user ?: "").put("packet_encoding", "xudp")
                u.q["flow"]?.takeIf { it.isNotEmpty() }?.let { o.put("flow", it) }
                tls(u.q, u.host)?.let { o.put("tls", it) }
                transport(u.q)?.let { o.put("transport", it) }
            }
            "trojan" -> {
                o.put("type", "trojan").put("password", u.user ?: "")
                tls(u.q, u.host, force = true)?.let { o.put("tls", it) }
                transport(u.q)?.let { o.put("transport", it) }
            }
            "ss" -> {
                val ui = u.user ?: ""
                val mp = if (ui.contains(':')) Uri.decode(ui) else b64(Uri.decode(ui))
                o.put("type", "shadowsocks").put("method", mp.substringBefore(':')).put("password", mp.substringAfter(':'))
                // плагины SIP003: obfs-local и v2ray-plugin ядро умеет; запись «имя;опция;опция»
                u.q["plugin"]?.takeIf { it.isNotEmpty() }?.let { pl ->
                    val name = pl.substringBefore(';')
                    val name2 = when (name) { "simple-obfs" -> "obfs-local"; else -> name }
                    if (name2 != "obfs-local" && name2 != "v2ray-plugin") return@runCatching null
                    o.put("plugin", name2)
                    pl.substringAfter(';', "").takeIf { it.isNotEmpty() }?.let { o.put("plugin_opts", it) }
                }
            }
            "hysteria2", "hy2" -> {
                o.put("type", "hysteria2").put("password", u.user ?: "")
                tls(u.q, u.host, force = true)?.let { o.put("tls", it) }
                u.q["obfs"]?.takeIf { it.isNotEmpty() }?.let {
                    o.put("obfs", JSONObject().put("type", it).put("password", u.q["obfs-password"] ?: ""))
                }
                // скачущие порты (mport=20000-30000 или несколько через запятую) и ограничения скорости
                (u.q["mport"] ?: u.q["ports"])?.takeIf { it.isNotEmpty() }?.let { p ->
                    o.put("server_ports", JSONArray(p.split(',').map { it.trim().replace('-', ':') }.filter { it.isNotEmpty() }))
                }
                u.q["upmbps"]?.toIntOrNull()?.let { o.put("up_mbps", it) }
                u.q["downmbps"]?.toIntOrNull()?.let { o.put("down_mbps", it) }
            }
            "hysteria", "hy" -> {                                      // Hysteria v1
                if ((u.q["protocol"] ?: "udp") != "udp") return@runCatching null   // faketcp / wechat-video ядро не умеет
                o.put("type", "hysteria")
                o.put("up_mbps", u.q["upmbps"]?.toIntOrNull() ?: 100).put("down_mbps", u.q["downmbps"]?.toIntOrNull() ?: 100)
                (u.q["auth"] ?: u.q["auth_str"])?.takeIf { it.isNotEmpty() }?.let { o.put("auth_str", it) }
                (u.q["obfsParam"] ?: u.q["obfs"]?.takeIf { it != "xplus" && it != "none" })?.takeIf { it.isNotEmpty() }?.let { o.put("obfs", it) }
                tls(u.q + ("sni" to (u.q["sni"] ?: u.q["peer"] ?: u.host)), u.host, force = true)?.let { o.put("tls", it) }
            }
            "tuic" -> {                                                // TUIC v5: tuic://uuid:password@host:port?...
                val ui = u.user ?: ""
                o.put("type", "tuic").put("uuid", ui.substringBefore(':')).put("password", ui.substringAfter(':', ""))
                u.q["congestion_control"]?.takeIf { it.isNotEmpty() }?.let { o.put("congestion_control", it) }
                if (u.q["udp_over_stream"] == "1" || u.q["udp_over_stream"] == "true") o.put("udp_over_stream", true)
                else u.q["udp_relay_mode"]?.takeIf { it == "native" || it == "quic" }?.let { o.put("udp_relay_mode", it) }
                if (u.q["reduce_rtt"] == "1" || u.q["zero_rtt_handshake"] == "1") o.put("zero_rtt_handshake", true)
                val ins = if (u.q["allow_insecure"] == "1" || u.q["allowInsecure"] == "1" || u.q["insecure"] == "1") "1" else "0"
                tls(u.q + ("alpn" to (u.q["alpn"] ?: "h3")) + ("insecure" to ins), u.host, force = true)?.let { o.put("tls", it) }
            }
            "wireguard", "wg" -> {                                     // wireguard://PRIVATE_KEY@host:port?publickey=...&address=10.0.0.2/32&reserved=1,2,3
                val priv = u.user?.takeIf { it.isNotEmpty() } ?: return@runCatching null
                val pub = (u.q["publickey"] ?: u.q["public_key"] ?: u.q["peer_public_key"])?.takeIf { it.isNotEmpty() } ?: return@runCatching null
                val addr = (u.q["address"] ?: u.q["ip"] ?: "10.0.0.2/32").split(',').map { it.trim() }.filter { it.isNotEmpty() }
                    .map { if (it.contains('/')) it else if (it.contains(':')) "$it/128" else "$it/32" }
                o.put("type", "wireguard").put("private_key", priv).put("peer_public_key", pub).put("local_address", JSONArray(addr))
                (u.q["presharedkey"] ?: u.q["psk"] ?: u.q["pre_shared_key"])?.takeIf { it.isNotEmpty() }?.let { o.put("pre_shared_key", it) }
                u.q["reserved"]?.split(',')?.mapNotNull { it.trim().toIntOrNull() }?.takeIf { it.size == 3 }?.let { o.put("reserved", JSONArray(it)) }
                u.q["mtu"]?.toIntOrNull()?.let { o.put("mtu", it) }
            }
            "socks", "socks4", "socks5", "socks5h" -> {
                o.put("type", "socks").put("version", if (scheme == "socks4") "4" else "5")
                val ui = u.user.orEmpty()
                if (ui.isNotEmpty()) {
                    val up = if (ui.contains(':')) ui else runCatching { b64(ui) }.getOrDefault(ui)   // иногда base64(user:pass)
                    o.put("username", up.substringBefore(':')).put("password", up.substringAfter(':', ""))
                }
            }
            "ssh" -> {
                o.put("type", "ssh").put("user", (u.user.orEmpty().substringBefore(':')).ifEmpty { "root" })
                u.user?.substringAfter(':', "")?.takeIf { it.isNotEmpty() }?.let { o.put("password", it) }
                if (u.port == 443) o.put("server_port", 22)           // порт не указан → стандартный SSH
            }
            else -> return@runCatching null
        }
        o
    }.getOrNull()
}
