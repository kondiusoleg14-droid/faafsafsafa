package app.vpnhub

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Sub(val id: String, val name: String, val url: String)
data class Server(val id: String, val subId: String?, val name: String, val link: String) {
    val kind: String by lazy { Parser.kind(link) }
    val proto: String get() = kind.substringBefore(' ')
    val clean: String by lazy { Parser.cleanName(name) }
    val gkey: String by lazy { Parser.groupKey(this) }
    val isUdp: Boolean get() = kind.startsWith("HYSTERIA") || kind.startsWith("TUIC")
}

object Vpn {
    var state by mutableStateOf("off") // off | starting | on
    var error by mutableStateOf<String?>(null)
}

object Store {
    private lateinit var sp: SharedPreferences
    val subs = mutableStateListOf<Sub>()
    val servers = mutableStateListOf<Server>()
    val appRules = mutableStateMapOf<String, String>() // package -> serverId | "direct"
    val pings = mutableStateMapOf<String, Int>()
    var selected by mutableStateOf<String?>(null) // serverId | "auto"
    var ruDirect by mutableStateOf(false)
    var sniOverride by mutableStateOf("")

    fun init(ctx: Context) {
        if (::sp.isInitialized) return
        sp = ctx.getSharedPreferences("hub", Context.MODE_PRIVATE)
        runCatching {
            val j = JSONObject(sp.getString("data", "{}")!!)
            j.optJSONArray("subs")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { subs.add(Sub(it.getString("id"), it.getString("name"), it.getString("url"))) } }
            j.optJSONArray("servers")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { servers.add(Server(it.getString("id"), it.optString("subId").ifEmpty { null }, it.getString("name"), it.getString("link"))) } }
            j.optJSONObject("rules")?.let { r -> r.keys().forEach { k -> appRules[k] = r.getString(k) } }
            selected = j.optString("selected").ifEmpty { null }
            ruDirect = j.optBoolean("ruDirect", false)
            sniOverride = j.optString("sni", "")
        }
    }

    fun save() {
        val j = JSONObject()
        j.put("subs", JSONArray().also { a -> subs.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("url", it.url)) } })
        j.put("servers", JSONArray().also { a -> servers.forEach { a.put(JSONObject().put("id", it.id).put("subId", it.subId ?: "").put("name", it.name).put("link", it.link)) } })
        j.put("rules", JSONObject().also { r -> appRules.forEach { (k, v) -> r.put(k, v) } })
        j.put("selected", selected ?: "")
        j.put("ruDirect", ruDirect)
        j.put("sni", sniOverride)
        sp.edit().putString("data", j.toString()).apply()
    }

    fun hwid(): String {
        var h = sp.getString("hwid", null)
        if (h == null) { h = java.util.UUID.randomUUID().toString().replace("-", "").take(16); sp.edit().putString("hwid", h).apply() }
        return h
    }

    fun idOf(link: String) = link.hashCode().toUInt().toString(16)

    fun addLinks(links: List<String>, subId: String?): Int {
        var n = 0
        for (l in links) {
            val link = l.trim()
            val name = Parser.nameOf(link) ?: continue
            val id = idOf(link)
            if (servers.none { it.id == id }) { servers.add(Server(id, subId, name, link)); n++ }
        }
        if (selected != "auto" && servers.none { it.id == selected }) selected = servers.firstOrNull()?.id
        save()
        return n
    }

    fun replaceSub(subId: String, links: List<String>) {
        servers.removeAll { it.subId == subId }
        addLinks(links, subId)
    }

    fun removeServer(id: String) {
        servers.removeAll { it.id == id }
        appRules.entries.removeAll { it.value == id }
        if (selected == id) selected = servers.firstOrNull()?.id
        save()
    }

    fun removeSub(id: String) {
        subs.removeAll { it.id == id }
        servers.filter { it.subId == id }.map { it.id }.forEach { removeServer(it) }
        save()
    }
}
