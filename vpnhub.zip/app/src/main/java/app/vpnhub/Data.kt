package app.vpnhub

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Sub(val id: String, val name: String, val url: String)
data class Server(val id: String, val subId: String?, val name: String, val link: String) {
    val kind: String by lazy { Parser.kind(link) }
    val proto: String get() = kind.substringBefore(' ')
    val clean: String by lazy { Parser.cleanName(name) }
    val gkey: String by lazy { Parser.groupKey(this) }
    val ekey: String by lazy { Parser.endpointKey(link) }
    val isUdp: Boolean get() = kind.startsWith("HYSTERIA") || kind.startsWith("TUIC")
}

object Vpn {
    var state by mutableStateOf("off") // off | starting | on
    var error by mutableStateOf<String?>(null)
    var wlActive by mutableStateOf(false)   // сейчас применён режим «белые списки»
    var cellular by mutableStateOf(false)   // сейчас только мобильный интернет
}

object Store {
    private lateinit var sp: SharedPreferences
    val subs = mutableStateListOf<Sub>()
    val servers = mutableStateListOf<Server>()
    val appRules = mutableStateMapOf<String, String>() // package -> serverId | "direct"
    val pings = mutableStateMapOf<String, Int>()
    val subInfo = mutableStateMapOf<String, String>() // subId -> почему не загрузилось (не сохраняется)
    var selected by mutableStateOf<String?>(null) // serverId | "auto"
    var configVersion by mutableIntStateOf(0) // растёт при любом изменении настроек, влияющих на подключение
    var ruDirect by mutableStateOf(false)
    var blockQuic by mutableStateOf(true)
    var preferTcp by mutableStateOf(true)    // «Авто» выбирает среди TCP-серверов (без Hysteria2/UDP)
    var blockIpv6 by mutableStateOf(true)    // отклонять IPv6-соединения, чтобы приложения сразу шли по IPv4
    var sniOverride by mutableStateOf("")
    var wlAuto by mutableStateOf(false)                       // на мобильном интернете включать серверы обхода белых списков
    var wlGroups by mutableStateOf<Set<String>>(emptySet())   // ключи групп серверов для обхода БС

    fun init(ctx: Context) {
        if (::sp.isInitialized) return
        sp = ctx.getSharedPreferences("hub", Context.MODE_PRIVATE)
        runCatching {
            val j = JSONObject(sp.getString("data", "{}")!!)
            j.optJSONArray("subs")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { subs.add(Sub(it.getString("id"), it.getString("name"), it.getString("url"))) } }
            j.optJSONArray("servers")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { servers.add(Server(it.getString("id"), it.optString("subId").ifEmpty { null }, it.getString("name"), it.getString("link"))) } }
            j.optJSONObject("rules")?.let { r -> r.keys().forEach { k -> appRules[k] = r.getString(k) } }
            selected = j.optString("selected").ifEmpty { null }
            ruDirect = j.optBoolean("ruDirect", false)
            blockQuic = j.optBoolean("blockQuic", true)
            preferTcp = j.optBoolean("preferTcp", true)
            blockIpv6 = j.optBoolean("blockIpv6", true)
            sniOverride = j.optString("sni", "")
            wlAuto = j.optBoolean("wlAuto", false)
            j.optJSONArray("wlGroups")?.let { a -> wlGroups = (0 until a.length()).map { a.getString(it) }.toSet() }
        }
    }

    fun save() {
        configVersion++
        val j = JSONObject()
        j.put("subs", JSONArray().also { a -> subs.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("url", it.url)) } })
        j.put("servers", JSONArray().also { a -> servers.forEach { a.put(JSONObject().put("id", it.id).put("subId", it.subId ?: "").put("name", it.name).put("link", it.link)) } })
        j.put("rules", JSONObject().also { r -> appRules.forEach { (k, v) -> r.put(k, v) } })
        j.put("selected", selected ?: "")
        j.put("ruDirect", ruDirect)
        j.put("blockQuic", blockQuic)
        j.put("preferTcp", preferTcp)
        j.put("blockIpv6", blockIpv6)
        j.put("sni", sniOverride)
        j.put("wlAuto", wlAuto)
        j.put("wlGroups", JSONArray(wlGroups.toList()))
        sp.edit().putString("data", j.toString()).apply()
    }

    fun hwid(): String {
        var h = sp.getString("hwid", null)
        if (h == null) { h = java.util.UUID.randomUUID().toString().replace("-", "").take(16); sp.edit().putString("hwid", h).apply() }
        return h
    }

    /** Какие серверы означает выбор: auto / g:ключ (вся группа) / gk:ключ|протокол / id сервера. */
    fun resolve(t: String): List<Server> = when {
        t == "auto" -> servers.take(40)
        t.startsWith("gk:") -> {
            val parts = t.removePrefix("gk:").split("|", limit = 2)
            servers.filter { it.gkey == parts[0] && it.kind == parts.getOrElse(1) { "" } }
        }
        t.startsWith("g:") -> servers.filter { it.gkey == t.removePrefix("g:") }
        else -> listOfNotNull(servers.firstOrNull { it.id == t })
    }

    fun selectionValid(): Boolean {
        val s = selected ?: return false
        return resolve(s).isNotEmpty()
    }

    fun describe(t: String?): String = when {
        t == null -> "не выбран — открой «Серверы»"
        t == "auto" -> "⚡ Авто — лучший из всех"
        t.startsWith("gk:") -> resolve(t).firstOrNull()?.let { it.clean + " · " + it.kind + " (авто)" } ?: "?"
        t.startsWith("g:") -> (resolve(t).firstOrNull()?.clean ?: "?") + " · авто по протоколам"
        else -> servers.firstOrNull { it.id == t }?.clean ?: "не выбран — открой «Серверы»"
    }

    fun idOf(link: String) = link.hashCode().toUInt().toString(16)

    fun addLinks(links: List<String>, subId: String?): Int {
        var n = 0
        for (l in links) {
            val link = l.trim()
            val name = Parser.nameOf(link) ?: continue
            val id = idOf(link)
            val ek = Parser.endpointKey(link)
            // пропускаем точные дубликаты (тот же сервер с теми же параметрами под другим именем)
            if (servers.none { it.id == id || it.ekey == ek }) { servers.add(Server(id, subId, name, link)); n++ }
        }
        if (!selectionValid()) selected = servers.firstOrNull()?.id
        save()
        return n
    }

    fun replaceSub(subId: String, links: List<String>) {
        servers.removeAll { it.subId == subId }
        addLinks(links, subId)
    }

    fun removeServer(id: String) {
        servers.removeAll { it.id == id }
        appRules.entries.removeAll { it.value == id }
        if (selected == id) selected = servers.firstOrNull()?.id
        save()
    }

    fun removeSub(id: String) {
        subs.removeAll { it.id == id }
        servers.filter { it.subId == id }.map { it.id }.forEach { removeServer(it) }
        save()
    }
}
