package app.vpnhub

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Sub(val id: String, val name: String, val url: String)
/** Категория приложений: сервер подбирается по совпадению названия (pattern) с именем сервера/профиля. fallback: default | auto | direct. */
data class Cat(val id: String, val label: String, val pattern: String, val pkgs: List<String>, val fallback: String)
/** «Отпечаток» выбранного сервера: по нему привязка находит его снова, когда id поменялся (обновили подписку, переименовали). */
data class Hint(val name: String, val gkey: String, val kind: String, val ek: String)
data class Server(val id: String, val subId: String?, val name: String, val link: String) {
    val kind: String by lazy { if (Parser.placeholder(link)) "служебная ⚠" else Parser.kind(link) }
    val dummy: Boolean get() = kind.startsWith("служебная")
    val proto: String get() = kind.substringBefore(' ')
    val clean: String by lazy { Parser.cleanName(name) }
    val gkey: String by lazy { Parser.groupKey(this) }
    val ekey: String by lazy { Parser.endpointKey(link) }
    val isUdp: Boolean get() = kind.startsWith("HYSTERIA") || kind.startsWith("TUIC") || kind.startsWith("WIREGUARD")
}

object Vpn {
    var state by mutableStateOf("off") // off | starting | on
    var error by mutableStateOf<String?>(null)
    var wlActive by mutableStateOf(false)   // сейчас применён режим «белые списки»
    var cellular by mutableStateOf(false)   // сейчас только мобильный интернет
}

object Store {
    private lateinit var sp: SharedPreferences
    val subs = mutableStateListOf<Sub>()
    val servers = mutableStateListOf<Server>()
    val appRules = mutableStateMapOf<String, String>() // package -> serverId | "direct"
    val pings = mutableStateMapOf<String, Int>()
    val subInfo = mutableStateMapOf<String, String>() // subId -> почему не загрузилось (не сохраняется)
    var selected by mutableStateOf<String?>(null) // serverId | "auto"
    var configVersion by mutableIntStateOf(0) // растёт при любом изменении настроек, влияющих на подключение
    var ruDirect by mutableStateOf(false)
    var blockQuic by mutableStateOf(true)
    var preferTcp by mutableStateOf(true)    // «Авто» выбирает среди TCP-серверов (без Hysteria2/UDP)
    var blockIpv6 by mutableStateOf(true)    // отклонять IPv6-соединения, чтобы приложения сразу шли по IPv4
    var sniOverride by mutableStateOf("")
    var wlAuto by mutableStateOf(false)                       // на мобильном интернете включать серверы обхода белых списков
    var wlGroups by mutableStateOf<Set<String>>(emptySet())   // ключи групп серверов для обхода БС (порядок = приоритет)
    var smartAuto by mutableStateOf(true)                     // умный автовыбор (оценка по истории проверок) для обхода БС и категорий
    val cats = mutableStateListOf<Cat>()
    private var catsSeeded = false
    private val ruleHints = HashMap<String, Hint>()           // package -> отпечаток назначенного сервера
    private val wlNames = HashMap<String, String>()           // ключ группы БС -> имя (чтобы найти группу после переименования)
    private var selHint: Hint? = null
    private var lostSel: Hint? = null                         // выбранный сервер пропал: ждём, когда вернётся
    private var lostSelFallback: String? = null
    private var rebindNote = ""

    fun init(ctx: Context) {
        if (::sp.isInitialized) return
        sp = ctx.getSharedPreferences("hub", Context.MODE_PRIVATE)
        runCatching {
            val j = JSONObject(sp.getString("data", "{}")!!)
            j.optJSONArray("subs")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { subs.add(Sub(it.getString("id"), it.getString("name"), it.getString("url"))) } }
            j.optJSONArray("servers")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { servers.add(Server(it.getString("id"), it.optString("subId").ifEmpty { null }, it.getString("name"), it.getString("link"))) } }
            j.optJSONObject("rules")?.let { r -> r.keys().forEach { k -> appRules[k] = r.getString(k) } }
            selected = j.optString("selected").ifEmpty { null }
            ruDirect = j.optBoolean("ruDirect", false)
            blockQuic = j.optBoolean("blockQuic", true)
            preferTcp = j.optBoolean("preferTcp", true)
            blockIpv6 = j.optBoolean("blockIpv6", true)
            sniOverride = j.optString("sni", "")
            wlAuto = j.optBoolean("wlAuto", false)
            j.optJSONArray("wlGroups")?.let { a -> wlGroups = (0 until a.length()).map { a.getString(it) }.toCollection(LinkedHashSet()) }
            smartAuto = j.optBoolean("smartAuto", true)
            catsSeeded = j.optBoolean("catsSeeded", false)
            j.optJSONArray("cats")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { o ->
                val pk = o.optJSONArray("pkgs")?.let { x -> (0 until x.length()).map { x.getString(it) } } ?: emptyList()
                cats.add(Cat(o.getString("id"), o.getString("label"), o.getString("pattern"), pk, o.optString("fallback", "default")))
            } }
            j.optJSONObject("hints")?.let { h -> h.keys().forEach { k -> hintOf(h.getJSONObject(k))?.let { ruleHints[k] = it } } }
            j.optJSONObject("wlNames")?.let { h -> h.keys().forEach { k -> wlNames[k] = h.getString(k) } }
            selHint = j.optJSONObject("selHint")?.let { hintOf(it) }
            lostSel = j.optJSONObject("lostSel")?.let { hintOf(it) }
            lostSelFallback = j.optString("lostSelFb").ifEmpty { null }
        }
        if (!catsSeeded && cats.isEmpty()) { cats.addAll(presets()); catsSeeded = true }
    }

    private fun hintOf(o: JSONObject): Hint? = runCatching { Hint(o.getString("n"), o.getString("g"), o.optString("k"), o.optString("e")) }.getOrNull()
    private fun hintJson(h: Hint) = JSONObject().put("n", h.name).put("g", h.gkey).put("k", h.kind).put("e", h.ek)

    private fun presets() = listOf(
        Cat("ai", "ИИ", """(?iu)(?<![\p{L}\p{N}])(ai|ии)(?![\p{L}\p{N}])|gpt|openai|claude|gemini|нейро|llm|perplexity|deepseek|copilot""",
            listOf("com.openai.chatgpt", "com.anthropic.claude", "com.google.android.apps.bard", "ai.perplexity.app.android", "com.deepseek.chat", "com.microsoft.copilot"), "default"),
        Cat("yt", "YouTube", """(?iu)youtube|(?<![\p{L}\p{N}])yt(?![\p{L}\p{N}])|ютуб|видео|video""",
            listOf("com.google.android.youtube", "com.google.android.apps.youtube.music", "com.google.android.youtube.tv"), "default")
    )

    fun save() {
        configVersion++
        refreshHints()
        val j = JSONObject()
        j.put("subs", JSONArray().also { a -> subs.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("url", it.url)) } })
        j.put("servers", JSONArray().also { a -> servers.forEach { a.put(JSONObject().put("id", it.id).put("subId", it.subId ?: "").put("name", it.name).put("link", it.link)) } })
        j.put("rules", JSONObject().also { r -> appRules.forEach { (k, v) -> r.put(k, v) } })
        j.put("selected", selected ?: "")
        j.put("ruDirect", ruDirect)
        j.put("blockQuic", blockQuic)
        j.put("preferTcp", preferTcp)
        j.put("blockIpv6", blockIpv6)
        j.put("sni", sniOverride)
        j.put("wlAuto", wlAuto)
        j.put("wlGroups", JSONArray(wlGroups.toList()))
        j.put("smartAuto", smartAuto)
        j.put("catsSeeded", catsSeeded)
        j.put("cats", JSONArray().also { a -> cats.forEach { c -> a.put(JSONObject().put("id", c.id).put("label", c.label).put("pattern", c.pattern).put("pkgs", JSONArray(c.pkgs)).put("fallback", c.fallback)) } })
        j.put("hints", JSONObject().also { h -> ruleHints.forEach { (k, v) -> h.put(k, hintJson(v)) } })
        j.put("wlNames", JSONObject().also { h -> wlNames.forEach { (k, v) -> h.put(k, v) } })
        selHint?.let { j.put("selHint", hintJson(it)) }
        lostSel?.let { j.put("lostSel", hintJson(it)) }
        lostSelFallback?.let { j.put("lostSelFb", it) }
        sp.edit().putString("data", j.toString()).apply()
    }

    fun hwid(): String {
        var h = sp.getString("hwid", null)
        if (h == null) { h = java.util.UUID.randomUUID().toString().replace("-", "").take(16); sp.edit().putString("hwid", h).apply() }
        return h
    }

    /** Какие серверы означает выбор: auto / g:ключ (вся группа) / gk:ключ|протокол / id сервера. */
    fun resolve(t: String): List<Server> = when {
        t == "auto" -> servers.filter { !it.kind.contains("⚠") }.take(40)   // служебные записи и неподдерживаемые транспорты в авто не берём
        t.startsWith("gk:") -> {
            val parts = t.removePrefix("gk:").split("|", limit = 2)
            servers.filter { it.gkey == parts[0] && it.kind == parts.getOrElse(1) { "" } }
        }
        t.startsWith("g:") -> servers.filter { it.gkey == t.removePrefix("g:") && !it.dummy }
        t.startsWith("cat:") -> catServers(t.removePrefix("cat:"))
        else -> listOfNotNull(servers.firstOrNull { it.id == t })
    }

    fun catById(id: String): Cat? = cats.firstOrNull { it.id == id }
    private val rxCache = HashMap<String, Regex?>()
    private fun rxOf(p: String): Regex? = rxCache.getOrPut(p) { runCatching { Regex(p) }.getOrNull() }

    /** Серверы категории: по совпадению шаблона с названием сервера/профиля (серверы с неподдерживаемым транспортом ⚠ пропускаем). */
    fun catServers(id: String): List<Server> {
        val c = catById(id) ?: return emptyList()
        val rx = rxOf(c.pattern) ?: return emptyList()
        return servers.filter { !it.kind.contains("⚠") && rx.containsMatchIn(it.name) }
    }

    fun fallbackName(f: String) = when (f) { "direct" -> "напрямую"; "auto" -> "авто по всем"; else -> "основной сервер" }

    /** Подпись правила приложения для экрана «Приложения». */
    fun ruleText(rule: String?): String = when {
        rule == null -> "По умолчанию"
        rule.startsWith("cat:") || resolve(rule).isNotEmpty() -> describe(rule)
        else -> "⚠ сервер пропал из списка — идёт через основной; привязка сохранена"
    }

    fun selectionValid(): Boolean {
        val s = selected ?: return false
        return resolve(s).isNotEmpty()
    }

    fun describe(t: String?): String = when {
        t == null -> "не выбран — открой «Серверы»"
        t == "auto" -> "⚡ Авто — лучший из всех"
        t.startsWith("cat:") -> {
            val c = catById(t.removePrefix("cat:"))
            if (c == null) "категория удалена — идёт через основной"
            else { val n = catServers(c.id).size; "Авто · " + c.label + (if (n > 0) " ($n серв.)" else " (нет совпадений → " + fallbackName(c.fallback) + ")") }
        }
        t.startsWith("gk:") -> resolve(t).firstOrNull()?.let { it.clean + " · " + it.kind + " (авто)" } ?: "?"
        t.startsWith("g:") -> (resolve(t).firstOrNull()?.clean ?: "?") + " · авто по протоколам"
        else -> servers.firstOrNull { it.id == t }?.clean ?: "не выбран — открой «Серверы»"
    }

    fun idOf(link: String) = link.hashCode().toUInt().toString(16)

    fun addLinks(links: List<String>, subId: String?): Int {
        var n = 0
        for (l in links) {
            val link = l.trim()
            val name = Parser.nameOf(link) ?: continue
            val id = idOf(link)
            val ek = Parser.endpointKey(link)
            // пропускаем точные дубликаты (тот же сервер с теми же параметрами под другим именем)
            if (servers.none { it.id == id || it.ekey == ek }) { servers.add(Server(id, subId, name, link)); n++ }
        }
        rebindAll()
        if (!selectionValid()) {
            val fb = firstUsableId()
            if (selHint != null && selected != null && selected != "auto") {
                lostSel = selHint; lostSelFallback = fb
                rebindNote += " Выбранный сервер «${selHint!!.name}» пропал — временно выбран другой, привязка вернётся, если он появится."
            }
            selected = fb
        }
        save()
        return n
    }

    /** Какие id серверов получились бы у подписки после replaceSub (с теми же правилами исключения дублей, что в addLinks). */
    fun previewIds(subId: String, links: List<String>): Set<String> {
        val others = servers.filter { it.subId != subId }
        val ids = LinkedHashSet<String>()
        val eks = HashSet<String>()
        for (l in links) {
            val link = l.trim()
            if (Parser.nameOf(link) == null) continue
            val id = idOf(link)
            val ek = Parser.endpointKey(link)
            if (others.none { it.id == id || it.ekey == ek } && id !in ids && ek !in eks) { ids.add(id); eks.add(ek) }
        }
        return ids
    }

    fun replaceSub(subId: String, links: List<String>) {
        servers.removeAll { it.subId == subId }
        addLinks(links, subId)
    }

    fun removeServer(id: String) {
        servers.removeAll { it.id == id }
        appRules.entries.removeAll { it.value == id }
        if (selected == id) selected = firstUsableId()
        save()
    }

    fun removeSub(id: String) {
        subs.removeAll { it.id == id }
        // привязки приложений не стираем: если подписку добавят снова, они сами найдут свои серверы
        servers.removeAll { it.subId == id }
        if (!selectionValid()) selected = firstUsableId()
        save()
    }

    /** Первый рабочий сервер: пропускаем служебные записи подписки (они обычно стоят первыми) и неподдерживаемые транспорты. */
    fun firstUsableId(): String? = servers.firstOrNull { !it.kind.contains("⚠") }?.id ?: servers.firstOrNull()?.id

    // ---- устойчивые привязки: выбор не сбрасывается при обновлении подписки ----

    private fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), "")
    private fun ekHash(s: Server) = s.ekey.hashCode().toUInt().toString(16)

    fun hintFor(t: String): Hint? {
        val s = resolve(t).firstOrNull() ?: return null
        val kind = if (t.startsWith("g:")) "" else s.kind
        val ek = if (t.startsWith("g:") || t.startsWith("gk:")) "" else ekHash(s)
        return Hint(s.clean, s.gkey, kind, ek)
    }

    /** Запоминаем отпечатки только для тех целей, что сейчас находятся; пропавшие не трогаем — по ним потом ищем замену. */
    private fun refreshHints() {
        appRules.forEach { (pkg, t) -> if (!t.startsWith("cat:") && resolve(t).isNotEmpty()) hintFor(t)?.let { ruleHints[pkg] = it } }
        ruleHints.keys.retainAll(appRules.keys.toSet())
        val s = selected
        if (s != null && s != "auto" && resolve(s).isNotEmpty()) selHint = hintFor(s)
        if (lostSel != null && selected != lostSelFallback) { lostSel = null; lostSelFallback = null }   // пользователь выбрал сам
        val byKey = servers.groupBy { it.gkey }
        wlGroups.forEach { k -> byKey[k]?.firstOrNull()?.let { wlNames[k] = it.clean } }
        wlNames.keys.retainAll(wlGroups)
    }

    /** Ищем, чем стал сервер: тот же endpoint (поменялось только имя) → та же группа/протокол → группа с похожим названием. */
    private fun relink(t: String, h: Hint?): String? {
        if (t == "auto" || t == "direct" || t.startsWith("cat:")) return t
        if (t.isNotEmpty() && resolve(t).isNotEmpty()) return t
        if (h == null) return null
        val keepGroup = t.startsWith("g:")
        if (h.ek.isNotEmpty()) servers.firstOrNull { ekHash(it) == h.ek }?.let { return if (keepGroup) "g:" + it.gkey else it.id }
        var g = servers.filter { it.gkey == h.gkey }
        if (g.isEmpty()) {
            val nk = norm(h.name)
            if (nk.length >= 3) {
                val keys = servers.map { it.gkey }.distinct()
                val key = keys.firstOrNull { it == nk } ?: keys.firstOrNull { k -> k.length >= 4 && (k.contains(nk) || nk.contains(k)) }
                if (key != null) g = servers.filter { it.gkey == key }
            }
        }
        if (g.isEmpty()) return null
        val gk = g.first().gkey
        if (keepGroup || h.kind.isEmpty()) return if (g.size > 1) "g:$gk" else g[0].id
        val same = g.filter { it.kind == h.kind }
        return when {
            same.size == 1 -> same[0].id
            same.size > 1 -> "gk:$gk|${h.kind}"
            g.size > 1 -> "g:$gk"
            else -> g[0].id
        }
    }

    /** После любого изменения списка серверов: перепривязываем назначения приложений, основной выбор и группы обхода БС. */
    fun rebindAll() {
        var moved = 0
        var lost = 0
        for ((pkg, t) in appRules.toMap()) {
            if (t == "direct" || t == "auto" || t.startsWith("cat:") || resolve(t).isNotEmpty()) continue
            val n = relink(t, ruleHints[pkg])
            if (n != null && n != t) { appRules[pkg] = n; moved++ } else lost++
        }
        val s = selected
        if (s != null && s != "auto" && resolve(s).isEmpty()) {
            val n = relink(s, selHint)
            if (n != null) { selected = n; moved++ }
        }
        lostSel?.let { h ->
            val n = relink("", h)
            if (n != null) { selected = n; lostSel = null; lostSelFallback = null; moved++ }
        }
        val keys = servers.map { it.gkey }.toSet()
        if (wlGroups.any { it !in keys }) {
            val out = LinkedHashSet<String>()
            for (k in wlGroups) {
                if (k in keys) { out.add(k); continue }
                val nk = norm(wlNames[k] ?: k)
                val m = keys.firstOrNull { it == nk } ?: keys.firstOrNull { it.length >= 4 && nk.length >= 3 && (it.contains(nk) || nk.contains(it)) }
                if (m != null && m !in wlGroups && m !in out) { out.add(m); wlNames[m] = wlNames[k] ?: m; moved++ } else out.add(k)
            }
            wlGroups = out
        }
        if (moved > 0 || lost > 0) {
            rebindNote = (if (moved > 0) " Перепривязано: $moved." else "") + (if (lost > 0) " Не найдено замены: $lost (привязка сохранена)." else "")
        }
    }

    fun takeRebindNote(): String { val n = rebindNote; rebindNote = ""; return n }

    /** Двигает группу в списке приоритетов обхода БС. */
    fun wlMove(key: String, delta: Int) {
        val l = wlGroups.toMutableList()
        val i = l.indexOf(key)
        val j = i + delta
        if (i < 0 || j < 0 || j >= l.size) return
        l.removeAt(i); l.add(j, key)
        wlGroups = LinkedHashSet(l)
        save()
    }

    /** Назначает приложениям категории по списку пакетов; уже выбранные вручную не трогает. */
    fun autoAssign(installed: Collection<String>): Int {
        var n = 0
        for (c in cats) for (p in c.pkgs) if (p in installed && !appRules.containsKey(p)) { appRules[p] = "cat:" + c.id; n++ }
        if (n > 0) save()
        return n
    }
}
