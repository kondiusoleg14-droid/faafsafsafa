package app.vpnhub

import android.content.Context
import java.io.File

object CrashLog {
    private var installed = false

    fun install(ctx: Context) {
        if (installed) return
        installed = true
        val dir = ctx.applicationContext.filesDir
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { File(dir, "crash.txt").writeText(java.util.Date().toString() + "\n" + android.util.Log.getStackTraceString(e)) }
            old?.uncaughtException(t, e)
        }
    }

    fun read(ctx: Context): String? = runCatching { File(ctx.filesDir, "crash.txt").takeIf { it.exists() }?.readText() }.getOrNull()
    fun clear(ctx: Context) { runCatching { File(ctx.filesDir, "crash.txt").delete() } }
}
