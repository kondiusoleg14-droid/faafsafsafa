package app.vpnhub

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import java.io.File

object CrashLog {
    private var installed = false

    fun install(ctx: Context) {
        if (installed) return
        installed = true
        val dir = ctx.applicationContext.filesDir
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { File(dir, "crash.txt").writeText(java.util.Date().toString() + "\n" + android.util.Log.getStackTraceString(e)) }
            old?.uncaughtException(t, e)
        }
    }

    fun step(ctx: Context, msg: String, reset: Boolean = false) {
        runCatching {
            val f = File(ctx.filesDir, "steps.txt")
            if (reset) f.writeText("")
            f.appendText(java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date()) + " " + msg + "\n")
        }
    }

    private fun steps(ctx: Context): String =
        runCatching { File(ctx.filesDir, "steps.txt").readText().trim() }.getOrDefault("")

    private fun exitReport(ctx: Context): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        return runCatching {
            val am = ctx.getSystemService(ActivityManager::class.java)
            val seen = ctx.getSharedPreferences("hub", Context.MODE_PRIVATE).getLong("exitSeen", 0)
            val bad = setOf(
                ApplicationExitInfo.REASON_CRASH, ApplicationExitInfo.REASON_CRASH_NATIVE, ApplicationExitInfo.REASON_SIGNALED,
                ApplicationExitInfo.REASON_ANR, ApplicationExitInfo.REASON_LOW_MEMORY, ApplicationExitInfo.REASON_INITIALIZATION_FAILURE,
                ApplicationExitInfo.REASON_DEPENDENCY_DIED, ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE
            )
            val e = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 5)
                .firstOrNull { it.timestamp > seen && it.reason in bad } ?: return null
            val name = when (e.reason) {
                ApplicationExitInfo.REASON_CRASH -> "CRASH (Java)"
                ApplicationExitInfo.REASON_CRASH_NATIVE -> "NATIVE CRASH (ядро)"
                ApplicationExitInfo.REASON_SIGNALED -> "SIGNALED (процесс убит сигналом)"
                ApplicationExitInfo.REASON_ANR -> "ANR (завис)"
                ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW MEMORY"
                else -> "reason=${e.reason}"
            }
            val sb = StringBuilder("Причина: $name, status=${e.status}\n${e.description.orEmpty()}")
            if (e.reason == ApplicationExitInfo.REASON_CRASH_NATIVE) {
                val bytes = e.traceInputStream?.use { it.readBytes() } ?: ByteArray(0)
                val lines = mutableListOf<String>()
                var cur = StringBuilder()
                for (b in bytes.take(300_000)) {
                    val c = b.toInt() and 0xff
                    if (c in 32..126) cur.append(c.toChar()) else { if (cur.length >= 8) lines.add(cur.toString()); cur = StringBuilder() }
                }
                val keys = listOf("abort", "fdsan", "panic", "fatal", "signal", "libbox", "gojni", "runtime", "sigsegv", "sigabrt", "cause")
                lines.filter { l -> keys.any { l.contains(it, true) } }.distinct().take(20)
                    .forEach { sb.append("\n").append(it.take(160)) }
            }
            sb.toString()
        }.getOrNull()
    }

    /** Текст последнего падения (Java-исключение или завершение процесса системой) + шаги подключения. */
    fun report(ctx: Context): String? {
        val java = runCatching { File(ctx.filesDir, "crash.txt").takeIf { it.exists() }?.readText() }.getOrNull()
        val main = java ?: exitReport(ctx) ?: return null
        val st = steps(ctx)
        return if (st.isEmpty()) main else main + "\n\nШаги подключения:\n" + st
    }

    fun clear(ctx: Context) {
        runCatching { File(ctx.filesDir, "crash.txt").delete() }
        ctx.getSharedPreferences("hub", Context.MODE_PRIVATE).edit().putLong("exitSeen", System.currentTimeMillis()).apply()
    }
}
