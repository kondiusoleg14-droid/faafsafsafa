package app.vpnhub

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import java.io.File

object CrashLog {
    private var installed = false

    fun install(ctx: Context) {
        if (installed) return
        installed = true
        val dir = ctx.applicationContext.filesDir
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { File(dir, "crash.txt").writeText(java.util.Date().toString() + "\n" + android.util.Log.getStackTraceString(e)) }
            old?.uncaughtException(t, e)
        }
    }

    fun step(ctx: Context, msg: String, reset: Boolean = false) {
        runCatching {
            val f = File(ctx.filesDir, "steps.txt")
            if (reset) f.writeText("")
            f.appendText(java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date()) + " " + msg + "\n")
        }
    }

    private fun steps(ctx: Context): String =
        runCatching { File(ctx.filesDir, "steps.txt").readText().trim() }.getOrDefault("")

    private fun exitReport(ctx: Context): Pair<String, String>? {
        if (Build.VERSION.SDK_INT < 30) return null
        return runCatching {
            val am = ctx.getSystemService(ActivityManager::class.java)
            val seen = ctx.getSharedPreferences("hub", Context.MODE_PRIVATE).getLong("exitSeen", 0)
            val bad = setOf(
                ApplicationExitInfo.REASON_CRASH, ApplicationExitInfo.REASON_CRASH_NATIVE, ApplicationExitInfo.REASON_SIGNALED,
                ApplicationExitInfo.REASON_ANR, ApplicationExitInfo.REASON_LOW_MEMORY, ApplicationExitInfo.REASON_INITIALIZATION_FAILURE,
                ApplicationExitInfo.REASON_DEPENDENCY_DIED, ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE
            )
            val e = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 5)
                .firstOrNull { it.timestamp > seen && it.reason in bad } ?: return null
            val name = when (e.reason) {
                ApplicationExitInfo.REASON_CRASH -> "CRASH (Java)"
                ApplicationExitInfo.REASON_CRASH_NATIVE -> "NATIVE CRASH (ядро)"
                ApplicationExitInfo.REASON_SIGNALED -> "SIGNALED (процесс убит сигналом)"
                ApplicationExitInfo.REASON_ANR -> "ANR (завис)"
                ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW MEMORY"
                else -> "reason=${e.reason}"
            }
            val head = "Причина: $name, status=${e.status} ${e.description.orEmpty()}".trim()
            var trace = ""
            if (e.reason == ApplicationExitInfo.REASON_CRASH_NATIVE) {
                val bytes = e.traceInputStream?.use { it.readBytes() } ?: ByteArray(0)
                val lines = mutableListOf<String>()
                var cur = StringBuilder()
                for (b in bytes.take(300_000)) {
                    val c = b.toInt() and 0xff
                    if (c in 32..126) cur.append(c.toChar()) else { if (cur.length >= 8) lines.add(cur.toString()); cur = StringBuilder() }
                }
                val keys = listOf("abort", "fdsan", "panic", "fatal", "signal", "libbox", "gojni", "runtime", "sigsegv", "sigabrt", "cause")
                trace = lines.filter { l -> keys.any { l.contains(it, true) } }.distinct().take(8).joinToString("\n") { it.take(160) }
            }
            head to trace
        }.getOrNull()
    }

    /** Текст последнего падения (Java-исключение или завершение процесса системой) + шаги подключения + лог ядра. */
    fun report(ctx: Context): String? {
        val java = runCatching { File(ctx.filesDir, "crash.txt").takeIf { it.exists() }?.readText() }.getOrNull()
        val ex = if (java == null) exitReport(ctx) else null
        val head = java ?: ex?.first ?: return null
        val parts = mutableListOf(head)
        val st = steps(ctx)
        if (st.isNotEmpty()) parts.add("Шаги подключения:\n$st")
        val err = runCatching { File(ctx.filesDir, "work/stderr.log").takeIf { it.exists() }?.readText()?.trim()?.takeLast(2500) }.getOrNull()
        if (!err.isNullOrEmpty()) parts.add("Лог ядра:\n$err")
        ex?.second?.takeIf { it.isNotEmpty() }?.let { parts.add("Трассировка:\n$it") }
        return parts.joinToString("\n\n")
    }

    fun clear(ctx: Context) {
        runCatching { File(ctx.filesDir, "crash.txt").delete() }
        ctx.getSharedPreferences("hub", Context.MODE_PRIVATE).edit().putLong("exitSeen", System.currentTimeMillis()).apply()
    }
}

/** Последние строки журнала ядра (предупреждения и ошибки) — чтобы видеть, почему нет интернета. */
object CoreLog {
    private val buf = ArrayDeque<String>()
    fun add(line: String) = synchronized(buf) { if (buf.size >= 200) buf.removeFirst(); buf.addLast(line.trim()) }
    fun text(n: Int): String = synchronized(buf) { buf.toList().takeLast(n).joinToString("\n") }
}

/** Сколько раз и как долго ядро спрашивало Android «какое приложение владеет соединением» (нужно для правил по приложениям). */
object Perf {
    val lookups = java.util.concurrent.atomic.AtomicLong()
    val nanos = java.util.concurrent.atomic.AtomicLong()
    val pkgCounts = java.util.concurrent.ConcurrentHashMap<String, java.util.concurrent.atomic.AtomicInteger>()
    fun count(pkg: String) { pkgCounts.getOrPut(pkg) { java.util.concurrent.atomic.AtomicInteger() }.incrementAndGet() }
    fun top(n: Int): List<Pair<String, Int>> = pkgCounts.entries.map { it.key to it.value.get() }.sortedByDescending { it.second }.take(n)
    fun reset() { lookups.set(0); nanos.set(0); pkgCounts.clear() }
    fun summary(): String {
        val n = lookups.get()
        if (n == 0L) return ""
        val avg = nanos.get() / n / 1_000_000.0
        return "Определение приложения для соединений: $n раз, в среднем ${"%.1f".format(avg)} мс, всего ${"%.1f".format(nanos.get() / 1e9)} с"
    }
}
