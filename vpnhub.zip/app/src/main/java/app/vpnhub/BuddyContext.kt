package app.vpnhub

/**
 * Какая «ситуация» у Бойкиссера по запущенному приложению (аналог заголовков окон на ПК).
 * Возвращает ключ набора фраз из BuddyPhrases: tea, music, cs, game, read, social, shop, ai, dev, doc, art, dl, learn,
 * browser, maps, bank, photo, settings, call, mail, clock, store — или "" (рабочий стол/неизвестное приложение).
 * Название приложения обрабатывается только на телефоне и никуда не отправляется.
 */
object BuddyContext {
    private val EXACT = HashMap<String, String>().apply {
        fun put(mode: String, vararg pk: String) { for (p in pk) this[p] = mode }
        put("tea", "com.google.android.youtube", "app.revanced.android.youtube", "com.vanced.android.youtube", "org.schabi.newpipe",
            "tv.twitch.android.app", "com.netflix.mediaclient", "ru.kinopoisk", "ru.rutube.app", "com.ivi.client", "ru.more.play",
            "ru.okko.android", "com.amediateka.app", "com.google.android.apps.youtube.kids", "com.disney.disneyplus", "com.hbo.hbonow", "ru.wink.android")
        put("music", "com.spotify.music", "com.google.android.apps.youtube.music", "ru.yandex.music", "com.zvuk.music", "com.soundcloud.android",
            "deezer.android.app", "com.apple.android.music", "com.aspiro.tidal", "ru.mts.music.android", "com.google.android.music", "com.maxmpz.audioplayer")
        put("read", "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram", "com.whatsapp", "com.whatsapp.w4b",
            "com.vkontakte.android", "com.viber.voip", "com.discord", "com.google.android.apps.messaging", "com.facebook.orca",
            "com.snapchat.android", "org.thoughtcrime.securesms", "im.vector.app", "ru.ok.messenger", "com.samsung.android.messaging")
        put("social", "com.instagram.android", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.twitter.android", "com.reddit.frontpage",
            "com.pinterest", "com.facebook.katana", "ru.ok.android", "com.tumblr", "com.bluesky.app", "org.joinmastodon.android", "com.pikabu.android")
        put("shop", "ru.ozon.app.android", "com.wildberries.ru", "com.aliexpress.android", "ru.avito.android", "com.amazon.mShop.android.shopping",
            "ru.yandex.market", "ru.beru.android", "ru.megamarket", "com.lamoda.lite", "ru.sbermegamarket", "ru.citilink.android")
        put("ai", "com.openai.chatgpt", "com.anthropic.claude", "com.google.android.apps.bard", "ai.perplexity.app.android", "com.deepseek.chat",
            "com.microsoft.copilot", "com.google.android.apps.gemini")
        put("dev", "com.termux", "com.github.android", "com.termux.api", "io.spck", "com.aide.ui", "com.jetbrains.kotlin.playground")
        put("doc", "com.microsoft.office.word", "com.microsoft.office.excel", "com.microsoft.office.powerpoint", "com.microsoft.office.officehubrow",
            "com.google.android.apps.docs.editors.docs", "com.google.android.apps.docs.editors.sheets", "com.google.android.apps.docs.editors.slides",
            "cn.wps.moffice_eng", "com.adobe.reader", "com.google.android.keep", "md.obsidian", "com.samsung.android.app.notes")
        put("art", "jp.ne.ibis.ibispaintx.app", "com.medibang.android.paint.tablet", "com.adobe.psmobile", "com.canva.editor", "com.picsart.studio",
            "com.adobe.lrmobile", "com.kinemaster.app", "com.lemon.lvoverseas")
        put("dl", "com.utorrent.client", "org.proninyaroslav.libretorrent", "com.bittorrent.client", "com.android.providers.downloads.ui", "idm.internet.download.manager")
        put("learn", "org.wikipedia", "com.duolingo", "com.khanacademy.android", "ru.habr", "org.coursera.android", "com.quizlet.quizletandroid")
        put("browser", "com.android.chrome", "org.mozilla.firefox", "org.mozilla.fenix", "com.yandex.browser", "com.opera.browser", "com.opera.mini.native",
            "com.microsoft.emmx", "com.brave.browser", "com.sec.android.app.sbrowser", "com.duckduckgo.mobile.android", "org.chromium.chrome", "com.kiwibrowser.browser",
            "com.vivaldi.browser", "com.android.browser")
        put("maps", "com.google.android.apps.maps", "ru.yandex.yandexmaps", "ru.dublgis.dgismobile", "ru.yandex.taxi", "com.ubercab", "ru.yandex.yandexnavi",
            "ru.rzd.pass", "ru.tutu.tutu_android", "com.waze", "app.organicmaps")
        put("bank", "ru.sberbankmobile", "ru.sberbank.sberbankid", "com.idamob.tinkoff.android", "ru.vtb24.mobilebanking.android", "ru.alfabank.mobile.android",
            "ru.raiffeisen.rmobile", "ru.gazprombank.android.mobilebank.app", "ru.rosbank.android", "ru.mts.money", "ru.nspk.sbpay", "com.paypal.android.p2pmobile")
        put("photo", "com.google.android.GoogleCamera", "com.android.camera", "com.android.camera2", "com.sec.android.app.camera", "com.miui.camera",
            "com.oppo.camera", "com.google.android.apps.photos", "com.sec.android.gallery3d", "com.miui.gallery", "com.android.gallery3d")
        put("settings", "com.android.settings", "com.miui.securitycenter", "com.samsung.android.lool", "com.google.android.gms")
        put("call", "com.android.dialer", "com.google.android.dialer", "com.samsung.android.dialer", "com.android.contacts", "com.google.android.contacts",
            "com.samsung.android.contacts", "com.android.phone")
        put("mail", "com.google.android.gm", "ru.mail.mailapp", "com.yandex.mail", "com.microsoft.office.outlook", "com.fsck.k9", "com.samsung.android.email.provider")
        put("clock", "com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage", "com.miui.clock", "com.google.android.calendar", "com.android.calendar")
        put("store", "com.android.vending", "com.sec.android.app.samsungapps", "com.huawei.appmarket", "com.xiaomi.mipicks", "ru.vk.store", "com.rustore.app", "ru.rustore.app")
        put("cs", "com.axlebolt.standoff2", "com.tencent.ig", "com.pubg.imobile", "com.pubg.krmobile", "com.activision.callofduty.shooter", "com.dts.freefireth",
            "com.dts.freefiremax", "com.gameloft.android.ANMP.GloftA9HM", "com.innersloth.spacemafia", "com.criticalforceentertainment.criticalops",
            "com.madfingergames.deadtrigger2", "com.fps.tpsgames")
    }

    // игры по началу имени пакета
    private val GAME_PREFIX = listOf(
        "com.supercell.", "com.mojang.", "com.miHoYo.", "com.HoYoverse.", "com.roblox.", "com.king.", "com.playrix.", "com.garena.", "com.mobile.legends",
        "com.riotgames.", "com.epicgames.", "com.gaijin.", "com.netease.", "com.ea.game.", "com.gameloft.", "com.ubisoft.", "com.nianticlabs.", "com.rovio.",
        "com.zeptolab.", "com.kiloo.", "com.imangi.", "com.outfit7.", "com.nexon.", "com.pearlabyss.", "com.blizzard.", "com.mihoyo.", "com.hypergryph.",
        "com.kurogame.", "com.proximabeta.", "com.lilithgame.", "com.squareenix.", "com.bandainamcoent.", "com.sega.", "com.konami.", "com.nintendo.", "com.valvesoftware."
    )

    fun classify(pkg: String?): String {
        if (pkg.isNullOrEmpty()) return ""
        EXACT[pkg]?.let { return it }
        for (p in GAME_PREFIX) if (pkg.startsWith(p)) return "game"
        val l = pkg.lowercase()
        return when {
            l.contains("browser") -> "browser"
            l.contains("camera") -> "photo"
            l.contains("gallery") || l.contains("photos") -> "photo"
            l.contains("dialer") || l.contains("contacts") -> "call"
            l.contains("music") || l.contains("player") && l.contains("audio") -> "music"
            l.contains("torrent") -> "dl"
            l.contains("bank") -> "bank"
            l.contains("game") || l.contains("games") -> "game"
            l.contains("mail") -> "mail"
            l.contains("messenger") || l.contains("chat") -> "read"
            l.contains("map") || l.contains("navi") || l.contains("taxi") -> "maps"
            else -> ""
        }
    }
}
