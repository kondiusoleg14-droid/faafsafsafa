package app.vpnhub

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

/** Пасхалки: котик (10 нажатий на название) и UwU-оформление (слово в поле «Подмена SNI»). */
object Egg {
    var cat by mutableStateOf(false)
    var touch by mutableStateOf(Offset(-1f, -1f))
    private var taps = 0
    private var last = 0L
    private val magic = Regex("фембой(чек|чик)|femboy", RegexOption.IGNORE_CASE)

    fun tap(ctx: Context) {
        val now = System.currentTimeMillis()
        if (now - last > 2000) taps = 0
        last = now
        taps++
        if (taps >= 10) {
            taps = 0
            cat = !cat
            Toast.makeText(ctx, if (cat) "Котик пришёл! Погладь его пальцем 🐱" else "Котик ушёл спать 😴", Toast.LENGTH_SHORT).show()
            if (cat) Sound.meow(false)
        }
    }

    fun isMagic(s: String) = magic.containsMatchIn(s)
    fun stripMagic(s: String) = magic.replace(s, "")
    fun toggleFem(ctx: Context) {
        Ui.femboy = !Ui.femboy
        Ui.save()
        Toast.makeText(ctx, if (Ui.femboy) "UwU-режим включён 💖 Добро пожаловать, фембойчек!" else "UwU-режим выключен", Toast.LENGTH_LONG).show()
    }
}

/** Следит за пальцем в любом месте экрана (не перехватывая касания) — котик смотрит туда. */
fun Modifier.trackTouch(): Modifier = pointerInput(Unit) {
    awaitPointerEventScope {
        while (true) {
            val e = awaitPointerEvent(PointerEventPass.Initial)
            e.changes.firstOrNull()?.let { Egg.touch = it.position }
        }
    }
}

/** Звуки котика: синтезируются на лету, файлов нет. */
object Sound {
    private const val SR = 22050
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var purrOn = false
    @Volatile private var purrTrack: AudioTrack? = null
    @Volatile private var purrPcm: ShortArray? = null

    private fun track(pcm: ShortArray, loop: Boolean): AudioTrack? = runCatching {
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
        t.write(pcm, 0, pcm.size)
        if (loop) t.setLoopPoints(0, pcm.size, -1)
        t
    }.getOrNull()

    private fun contour(t: Double, p: Array<DoubleArray>): Double {
        for (i in 0 until p.size - 1) {
            if (t <= p[i + 1][0]) { val k = (t - p[i][0]) / (p[i + 1][0] - p[i][0]); return p[i][1] + (p[i + 1][1] - p[i][1]) * k }
        }
        return p[p.size - 1][1]
    }

    fun meow(short: Boolean) {
        Thread {
            runCatching {
                val pitch = 0.9 + Math.random() * 0.35
                val dur = if (short) 0.2 else 0.55 + Math.random() * 0.25
                val n = (SR * dur).toInt()
                val out = ShortArray(n)
                val pitchPts = if (short) arrayOf(doubleArrayOf(0.0, 330.0), doubleArrayOf(0.6, 520.0), doubleArrayOf(1.0, 420.0))
                else arrayOf(doubleArrayOf(0.0, 420.0), doubleArrayOf(0.3, 820.0), doubleArrayOf(0.75, 560.0), doubleArrayOf(1.0, 380.0))
                val formPts = if (short) arrayOf(doubleArrayOf(0.0, 1300.0), doubleArrayOf(1.0, 1300.0))
                else arrayOf(doubleArrayOf(0.0, 900.0), doubleArrayOf(0.35, 2100.0), doubleArrayOf(1.0, 1000.0))
                var ph = 0.0
                for (i in 0 until n) {
                    val t = i.toDouble() / n
                    val f0 = contour(t, pitchPts) * pitch * (1.0 + 0.02 * sin(2.0 * PI * 6.0 * i / SR))
                    ph += 2.0 * PI * f0 / SR
                    val fc = contour(t, formPts)
                    var s = 0.0
                    var k = 1
                    while (k <= 20 && k * f0 < 7000.0) {
                        val d = (k * f0 - fc) / 700.0
                        s += (exp(-d * d) + 0.15) / k * sin(k * ph)
                        k++
                    }
                    val env = min(1.0, i / (SR * 0.05)) * (1.0 - t).pow(1.5)
                    out[i] = (s * env * 7000.0).toInt().coerceIn(-32000, 32000).toShort()
                }
                val tr = track(out, false)
                if (tr != null) {
                    tr.play()
                    main.postDelayed({ runCatching { tr.release() } }, (dur * 1000).toLong() + 400)
                }
            }
        }.start()
    }

    fun purrStart() {
        if (purrOn) return
        purrOn = true
        Thread {
            runCatching {
                val pcm = purrPcm ?: run {
                    val n = SR * 2
                    val out = ShortArray(n)
                    var lp = 0.0
                    for (i in 0 until n) {
                        lp += 0.06 * ((Math.random() * 2 - 1) - lp)
                        val am = 0.5 + 0.5 * sin(2.0 * PI * 25.0 * i / SR)
                        out[i] = (lp * am * 26000.0).toInt().coerceIn(-32000, 32000).toShort()
                    }
                    purrPcm = out
                    out
                }
                val t = track(pcm, true)
                synchronized(this) {
                    if (!purrOn || t == null) runCatching { t?.release() } else { purrTrack = t; t.play() }
                }
            }
        }.start()
    }

    fun purrStop() {
        purrOn = false
        synchronized(this) {
            purrTrack?.let { t -> runCatching { t.stop(); t.release() } }
            purrTrack = null
        }
    }
}

@Composable
fun PawIcon(modifier: Modifier = Modifier, color: Color = Color.White) {
    androidx.compose.foundation.Canvas(modifier) {
        val s = size.minDimension / 100f
        val pad = Path().apply {
            moveTo(50 * s, 52 * s)
            cubicTo(36 * s, 52 * s, 24 * s, 64 * s, 24 * s, 76 * s)
            cubicTo(24 * s, 85 * s, 31 * s, 90 * s, 39 * s, 90 * s)
            cubicTo(44 * s, 90 * s, 47 * s, 88 * s, 50 * s, 88 * s)
            cubicTo(53 * s, 88 * s, 56 * s, 90 * s, 61 * s, 90 * s)
            cubicTo(69 * s, 90 * s, 76 * s, 85 * s, 76 * s, 76 * s)
            cubicTo(76 * s, 64 * s, 64 * s, 52 * s, 50 * s, 52 * s)
            close()
        }
        drawPath(pad, color)
        fun toe(cx: Float, cy: Float, rx: Float, ry: Float, deg: Float) {
            rotate(deg, Offset(cx * s, cy * s)) { drawOval(color, Offset((cx - rx) * s, (cy - ry) * s), Size(rx * 2 * s, ry * 2 * s)) }
        }
        toe(21f, 47f, 9f, 12f, -22f); toe(40f, 30f, 9f, 13f, 0f); toe(60f, 30f, 9f, 13f, 0f); toe(79f, 47f, 9f, 12f, 22f)
    }
}

private fun DrawScope.drawCat(tail: Float, headTilt: Float, petting: Boolean, blink: Boolean, eye: Offset) {
    val s = size.width / 140f
    fun o(x: Float, y: Float) = Offset(x * s, y * s)
    fun poly(vararg p: Float): Path = Path().apply {
        moveTo(p[0] * s, p[1] * s)
        var i = 2
        while (i < p.size) { lineTo(p[i] * s, p[i + 1] * s); i += 2 }
        close()
    }
    val orange = Color(0xFFF2A65A); val dark = Color(0xFFE8964A); val cream = Color(0xFFFBE3C4); val line = Color(0xFF5A3A1A)
    rotate(tail, o(102f, 130f)) {
        val tp = Path().apply { moveTo(102 * s, 130 * s); cubicTo(136 * s, 130 * s, 142 * s, 92 * s, 122 * s, 84 * s) }
        drawPath(tp, dark, style = Stroke(12 * s, cap = StrokeCap.Round))
    }
    drawOval(orange, o(32f, 78f), Size(76 * s, 68 * s))
    drawOval(cream, o(48f, 100f), Size(44 * s, 44 * s))
    drawOval(cream, o(43f, 135f), Size(22 * s, 14 * s))
    drawOval(cream, o(75f, 135f), Size(22 * s, 14 * s))
    rotate(headTilt, o(70f, 80f)) {
        drawPath(poly(44f, 42f, 47f, 12f, 68f, 32f), orange)
        drawPath(poly(96f, 42f, 93f, 12f, 72f, 32f), orange)
        drawPath(poly(49f, 35f, 51f, 20f, 62f, 31f), Color(0xFFF7B7B0))
        drawPath(poly(91f, 35f, 89f, 20f, 78f, 31f), Color(0xFFF7B7B0))
        drawCircle(orange, 32 * s, o(70f, 62f))
        val st = Color(0xFFD98339)
        drawLine(st, o(70f, 32f), o(70f, 42f), strokeWidth = 3 * s, cap = StrokeCap.Round)
        drawLine(st, o(60f, 34f), o(62f, 42f), strokeWidth = 3 * s, cap = StrokeCap.Round)
        drawLine(st, o(80f, 34f), o(78f, 42f), strokeWidth = 3 * s, cap = StrokeCap.Round)
        if (petting) {
            drawCircle(Color(0xFFF28B9B).copy(alpha = 0.55f), 6 * s, o(48f, 72f))
            drawCircle(Color(0xFFF28B9B).copy(alpha = 0.55f), 6 * s, o(92f, 72f))
        }
        if (petting || blink) {
            val e = Path().apply {
                moveTo(49 * s, 61 * s); quadraticBezierTo(57 * s, 69 * s, 65 * s, 61 * s)
                moveTo(75 * s, 61 * s); quadraticBezierTo(83 * s, 69 * s, 91 * s, 61 * s)
            }
            drawPath(e, line, style = Stroke(2.6f * s, cap = StrokeCap.Round))
        } else {
            for (cx in floatArrayOf(57f, 83f)) {
                drawOval(Color.White, o(cx - 8f, 51f), Size(16 * s, 18 * s))
                drawCircle(Color(0xFF222222), 4.6f * s, o(cx + eye.x, 60f + eye.y))
                drawCircle(Color.White, 1.5f * s, o(cx + eye.x - 1.6f, 60f + eye.y - 1.8f))
            }
        }
        drawPath(poly(66f, 71f, 74f, 71f, 70f, 76f), Color(0xFFE7777F))
        val m = Path().apply {
            moveTo(70 * s, 76 * s); quadraticBezierTo(65 * s, 82 * s, 60 * s, 78 * s)
            moveTo(70 * s, 76 * s); quadraticBezierTo(75 * s, 82 * s, 80 * s, 78 * s)
        }
        drawPath(m, line, style = Stroke(1.8f * s, cap = StrokeCap.Round))
        val w = Color.White.copy(alpha = 0.85f)
        drawLine(w, o(50f, 74f), o(26f, 70f), strokeWidth = 1.5f * s, cap = StrokeCap.Round)
        drawLine(w, o(50f, 78f), o(26f, 80f), strokeWidth = 1.5f * s, cap = StrokeCap.Round)
        drawLine(w, o(90f, 74f), o(114f, 70f), strokeWidth = 1.5f * s, cap = StrokeCap.Round)
        drawLine(w, o(90f, 78f), o(114f, 80f), strokeWidth = 1.5f * s, cap = StrokeCap.Round)
    }
}

@Composable
fun CatOverlay() {
    var center by remember { mutableStateOf(Offset.Zero) }
    var petting by remember { mutableStateOf(false) }
    var acc by remember { mutableFloatStateOf(0f) }
    var blink by remember { mutableStateOf(false) }
    var say by remember { mutableStateOf("") }
    var sayAt by remember { mutableLongStateOf(0L) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var lastMeow by remember { mutableLongStateOf(0L) }
    val hearts = remember { mutableStateListOf<Pair<Long, Float>>() }

    val inf = rememberInfiniteTransition(label = "cat")
    val tail by inf.animateFloat(0f, 14f, infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "tail")
    val nuzzle by inf.animateFloat(-4f, 4f, infiniteRepeatable(tween(230, easing = LinearEasing), RepeatMode.Reverse), label = "nuzzle")

    LaunchedEffect(Unit) { while (true) { delay(60); now = System.currentTimeMillis(); if (hearts.isNotEmpty()) hearts.removeAll { now - it.first > 1300 } } }
    LaunchedEffect(Unit) { while (true) { delay(2500L + Random.nextLong(3500L)); blink = true; delay(140); blink = false } }
    LaunchedEffect(petting) {
        if (petting) {
            Sound.purrStart(); say = "мурр~"; sayAt = System.currentTimeMillis()
            while (true) { hearts.add(System.currentTimeMillis() to Random.nextFloat()); delay(380) }
        } else Sound.purrStop()
    }
    DisposableEffect(Unit) { onDispose { Sound.purrStop() } }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomEnd) {
        Box(
            Modifier.padding(end = 14.dp, bottom = 96.dp).size(120.dp, 130.dp)
                .onGloballyPositioned { center = it.positionInRoot() + Offset(it.size.width / 2f, it.size.height * 0.45f) }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { acc = 0f },
                        onDragEnd = { petting = false; acc = 0f },
                        onDragCancel = { petting = false; acc = 0f }
                    ) { change, drag ->
                        acc += abs(drag.x) + abs(drag.y)
                        if (acc > 220f) petting = true
                        change.consume()
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(onTap = {
                        val t = System.currentTimeMillis()
                        hearts.add(t to Random.nextFloat())
                        say = listOf("мяу!", "мур?", "мрр", "🐾", "мяу~").random(); sayAt = t
                        if (t - lastMeow > 450) { lastMeow = t; Sound.meow(Random.nextFloat() < 0.4f) }
                    })
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val d0 = Egg.touch - center
                val d = hypot(d0.x, d0.y).coerceAtLeast(1f)
                val k = min(1f, d / 250f) * 4f
                val eye = if (Egg.touch.x < 0f) Offset(0f, 1.5f) else Offset(d0.x / d * k, d0.y / d * k * 1.1f)
                val tilt = if (petting) nuzzle else (d0.x / 400f * 7f).coerceIn(-7f, 7f)
                drawCat(tail, tilt, petting, blink, eye)
            }
            hearts.forEach { (born, frac) ->
                val age = ((now - born) / 1300f).coerceIn(0f, 1f)
                Text("❤", color = Color(0xFFFF5C8A), fontSize = 18.sp, modifier = Modifier.offset(x = (25f + 70f * frac).dp, y = (60f - 90f * age).dp).alpha(1f - age))
            }
            if (say.isNotEmpty() && now - sayAt < 1600) {
                Text(
                    say, color = Ui.pal.text, fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.TopStart).offset(y = (-14).dp).background(Ui.pal.sheet, RoundedCornerShape(10.dp)).padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
    }
}
