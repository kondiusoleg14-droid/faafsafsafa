package app.vpnhub

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLHandshakeException
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * «Умный» автовыбор: вместо одного пинга считаем оценку сервера по истории проверок ИМЕННО в текущей сети
 * (мобильная / Wi-Fi): успешность установки соединения, стабильность (таймауты, разброс задержки),
 * совместимость с активными настройками обхода (UDP, QUIC, подмена SNI) и приоритет группы обхода БС.
 * Проверки идут с защищённых сокетов (мимо туннеля): TCP-соединение + TLS-рукопожатие с тем SNI, который реально используется.
 */
object Health {
    const val SKIP = Int.MIN_VALUE   // не проверяли (UDP-серверы: TCP-проба для них бессмысленна)
    const val TIMEOUT = -2
    const val FAIL = -1
    private const val HISTORY = 10
    private const val MAX_PROBES = 10

    @Volatile var net: String = "wifi"                        // wifi | cell | other — задаёт сервис
    @Volatile var appliedMain: Set<String> = emptySet()       // id серверов, из которых собран основной urltest
    @Volatile var appliedCat: Map<String, Boolean> = emptyMap() // категория -> нашлись ли рабочие серверы при сборке конфига

    private val hist = HashMap<String, MutableList<Int>>()    // "id|сеть" -> последние результаты (мс, либо FAIL/TIMEOUT)
    private val failAt = HashMap<String, Long>()
    private val probedAt = HashMap<String, Long>()
    private var sp: SharedPreferences? = null
    private var dirty = false
    private var lastSave = 0L
    private val exec = Executors.newFixedThreadPool(4) { r -> Thread(r).apply { isDaemon = true } }

    fun init(ctx: Context) {
        if (sp != null) return
        val p = ctx.getSharedPreferences("health", Context.MODE_PRIVATE)
        sp = p
        runCatching {
            val j = JSONObject(p.getString("h", "{}")!!)
            val alive = Store.servers.map { it.id }.toSet()
            synchronized(hist) {
                j.keys().forEach { k ->
                    if (k.substringBefore('|') in alive) {
                        hist[k] = j.getString(k).split(",").mapNotNull { it.toIntOrNull() }.takeLast(HISTORY).toMutableList()
                    }
                }
            }
        }
    }

    fun save(force: Boolean = false) {
        val p = sp ?: return
        val now = System.currentTimeMillis()
        if (!dirty || (!force && now - lastSave < 20_000L)) return
        val j = JSONObject()
        synchronized(hist) { hist.forEach { (k, v) -> j.put(k, v.joinToString(",")) } }
        p.edit().putString("h", j.toString()).apply()
        dirty = false; lastSave = now
    }

    fun record(id: String, net: String, ms: Int) {
        val key = "$id|$net"
        synchronized(hist) {
            val l = hist.getOrPut(key) { ArrayList() }
            l.add(ms)
            while (l.size > HISTORY) l.removeAt(0)
            if (ms < 0) failAt[key] = System.currentTimeMillis()
            dirty = true
        }
    }

    private fun history(id: String, net: String): List<Int> = synchronized(hist) { hist["$id|$net"]?.toList() ?: emptyList() }

    /** Сервер считается неработающим, если последние 3 проверки подряд провалились. Нет данных — считаем рабочим. */
    fun usable(s: Server): Boolean {
        if (!Store.smartAuto) return true
        val h = history(s.id, net)
        return !(h.size >= 3 && h.takeLast(3).all { it < 0 })
    }

    private fun proven(s: Server): Boolean = history(s.id, net).lastOrNull()?.let { it >= 0 } == true

    private data class Prof(val tls: Boolean, val sni: String, val reality: Boolean)
    private val profCache = java.util.concurrent.ConcurrentHashMap<String, Prof>()
    private fun prof(s: Server): Prof = profCache.getOrPut(s.id) {
        val t = runCatching { Parser.outbounds(s, "p").firstOrNull()?.optJSONObject("tls") }.getOrNull()
        Prof(t?.optBoolean("enabled") == true, t?.optString("server_name").orEmpty(), t?.optJSONObject("reality") != null)
    }

    /** Оценка сервера: чем больше, тем лучше. Веса можно подкручивать. wlRank — позиция группы в списке приоритетов обхода БС (-1 — не БС). */
    fun score(s: Server, net: String, wlRank: Int): Double {
        val h = history(s.id, net)
        var sc: Double
        if (h.isEmpty()) {
            sc = 0.45 * 0.5 + 0.20 * 0.5 + 0.15 * 0.5 + 0.10 * 0.5   // данных нет — нейтрально
        } else {
            val ok = h.filter { it >= 0 }
            val succ = ok.size.toDouble() / h.size
            val med = if (ok.isEmpty()) 3000.0 else ok.sorted()[ok.size / 2].toDouble()
            val mean = if (ok.isEmpty()) 0.0 else ok.average()
            val sd = if (ok.size < 2) 0.0 else Math.sqrt(ok.sumOf { (it - mean) * (it - mean) } / ok.size)
            val tmo = h.count { it == TIMEOUT }.toDouble() / h.size
            sc = 0.45 * succ + 0.20 * (1 - (med / 2000.0).coerceIn(0.0, 1.0)) + 0.15 * (1 - (sd / 1000.0).coerceIn(0.0, 1.0)) + 0.10 * (1 - tmo)
        }
        // совместимость с сетью и настройками обхода
        if (s.isUdp && (Store.preferTcp || net == "cell")) sc -= 0.5
        if (s.isUdp && Store.blockQuic) sc -= 0.05
        if (Store.sniOverride.isNotBlank()) { val p = prof(s); if (p.tls && !p.reality) sc += 0.08 }
        // приоритет группы обхода: первая в списке +0.30, дальше по убыванию
        if (wlRank >= 0) sc += 0.30 * (1.0 - wlRank.toDouble() / maxOf(1, Store.wlGroups.size))
        // свежий отказ в этой сети
        val fa = synchronized(hist) { failAt["${s.id}|$net"] }
        if (fa != null && System.currentTimeMillis() - fa < 90_000L) sc -= 0.30
        // липкость: действующие участники не вылетают из-за мелких колебаний
        if (s.id in appliedMain) sc += 0.05
        return sc
    }

    fun rank(list: List<Server>, wl: Boolean = false): List<Server> {
        if (!Store.smartAuto) return list
        val n = net
        val order = Store.wlGroups.toList()
        return list.map { it to score(it, n, if (wl) order.indexOf(it.gkey) else -1) }.sortedByDescending { it.second }.map { it.first }
    }

    fun catHasUsable(catId: String): Boolean = Store.catServers(catId).any { usable(it) }

    /** Серверы, которые стоит проверять в этом раунде. */
    private fun pool(): List<Server> {
        val out = LinkedHashMap<String, Server>()
        val byId = Store.servers.associateBy { it.id }
        appliedMain.forEach { id -> byId[id]?.let { out[it.id] = it } }
        val sel = Store.selected
        if (Vpn.wlActive) Store.servers.filter { it.gkey in Store.wlGroups && !it.kind.contains("⚠") }.forEach { out.putIfAbsent(it.id, it) }
        else if (sel != null) Store.resolve(sel).forEach { out.putIfAbsent(it.id, it) }
        Store.appRules.values.filter { it.startsWith("cat:") }.distinct().forEach { t -> Store.resolve(t).forEach { out.putIfAbsent(it.id, it) } }
        return out.values.toList()
    }

    private fun watchList(): List<Server> {
        val all = pool().filter { !it.isUdp }
        val first = all.filter { it.id in appliedMain }
        val rest = all.filter { it.id !in appliedMain }.sortedBy { probedAt[it.id] ?: 0L }
        return (first + rest).take(MAX_PROBES)
    }

    /** Один раунд проверок: параллельно, не более MAX_PROBES серверов. */
    fun probeRound(protect: (Socket) -> Unit) {
        val cand = watchList()
        if (cand.isEmpty()) return
        val n = net
        val tasks = cand.map { s -> Callable { s.id to probe(s, protect) } }
        val res = runCatching { exec.invokeAll(tasks, 15, TimeUnit.SECONDS) }.getOrNull() ?: return
        val now = System.currentTimeMillis()
        for (f in res) {
            if (f.isCancelled) continue
            val (id, ms) = runCatching { f.get() }.getOrNull() ?: continue
            probedAt[id] = now
            if (ms != SKIP) record(id, n, ms)
        }
        save()
    }

    private fun looksLikeIp(h: String) = h.all { it.isDigit() || it == '.' || it == ':' }

    private fun reachedCert(e: Throwable): Boolean = generateSequence(e) { it.cause }.any {
        it is java.security.cert.CertificateException || it is java.security.cert.CertPathValidatorException ||
            (it.message?.contains("certificate", true) == true) || (it.message?.contains("trust anchor", true) == true)
    }

    /** TCP-соединение (+ TLS-рукопожатие, если сервер на TLS) с защищённого сокета. Ошибка проверки сертификата = «дошли до сертификата» = успех. */
    fun probe(s: Server, protect: (Socket) -> Unit): Int {
        if (s.isUdp) return SKIP
        val hp = Parser.hostPort(s.link) ?: return SKIP
        val p = prof(s)
        val t0 = System.nanoTime()
        val raw = Socket()
        try {
            protect(raw)
            raw.tcpNoDelay = true
            raw.connect(InetSocketAddress(hp.first, hp.second), 3500)
            if (p.tls) {
                raw.soTimeout = 3500
                val sni = if (!p.reality && Store.sniOverride.isNotBlank()) Store.sniOverride.trim() else p.sni.ifEmpty { hp.first }
                val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(raw, sni, hp.second, true) as SSLSocket
                if (!looksLikeIp(sni)) ssl.sslParameters = ssl.sslParameters.also { it.serverNames = listOf(SNIHostName(sni)) }
                try { ssl.startHandshake() } catch (e: SSLHandshakeException) { if (!reachedCert(e)) return FAIL }
            }
            return ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
        } catch (e: Exception) {
            return if (generateSequence<Throwable>(e) { it.cause }.any { it is SocketTimeoutException }) TIMEOUT else FAIL
        } finally {
            runCatching { raw.close() }
        }
    }

    /**
     * Пора ли пересобрать конфиг (быстрый резерв при деградации):
     * основной набор потерял рабочие серверы, а у запасных есть успешные проверки; либо у категории появились/пропали рабочие серверы.
     */
    fun needsRebuild(): Boolean {
        if (!Store.smartAuto) return false
        val byId = Store.servers.associateBy { it.id }
        val set = appliedMain.mapNotNull { byId[it] }
        if (set.isNotEmpty()) {
            val ok = set.count { it.isUdp || (usable(it) && proven(it)) }
            if (ok < minOf(2, set.size)) {
                val others = pool().filter { it.id !in appliedMain && usable(it) && proven(it) }
                if (others.isNotEmpty()) return true
            }
        }
        for ((cid, was) in appliedCat) if (catHasUsable(cid) != was) return true
        return false
    }
}
