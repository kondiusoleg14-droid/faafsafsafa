package app.vpnhub

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Автообновление: сборка в GitHub Actions выкладывает релиз android-latest; приложение сверяет номер сборки и ставит новую. */
object Updater {
    private fun repo(ctx: Context): String = runCatching { ctx.getString(R.string.update_repo) }.getOrDefault("kondiusoleg14-droid/faafsafsafa")
    private fun base(ctx: Context): String = "https://github.com/" + repo(ctx) + "/releases/download/android-latest/"
    private const val SIX_HOURS = 6L * 60 * 60 * 1000

    var status by mutableStateOf("")
    var available by mutableStateOf<String?>(null)   // номер новой сборки
    var busy by mutableStateOf(false)
    var dismissed by mutableStateOf(false)

    fun current(ctx: Context): String = runCatching { ctx.getString(R.string.build_id) }.getOrDefault("dev")

    private fun open(url: String, readMs: Int): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = readMs
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "VPNHub-Updater")
        return c
    }

    fun check(ctx: Context, manual: Boolean) {
        if (busy) return
        busy = true
        if (manual) status = "Проверяю…"
        Thread {
            val cur = current(ctx)
            val res = runCatching {
                val c = open(base(ctx) + "latest.json", 30000)
                try {
                    if (c.responseCode !in 200..299) throw IOException("HTTP " + c.responseCode)
                    JSONObject(c.inputStream.use { String(it.readBytes(), Charsets.UTF_8) }).getString("id")
                } finally { c.disconnect() }
            }
            busy = false
            Ui.lastCheck = System.currentTimeMillis()
            Ui.save()
            res.onSuccess { id ->
                val newer = cur != "dev" && id > cur
                available = if (newer) id else null
                dismissed = false
                status = if (newer) "Доступна новая сборка $id (у тебя $cur)" else "У тебя последняя версия ($cur)"
            }.onFailure { e ->
                if (manual) status = "Не удалось проверить: " + (e.message ?: e.javaClass.simpleName)
            }
        }.start()
    }

    /** Вызывается при запуске: если автообновление включено — раз в 6 часов проверяем. */
    fun autoCheck(ctx: Context) {
        if (Ui.autoUpdate && System.currentTimeMillis() - Ui.lastCheck > SIX_HOURS) check(ctx, false)
    }

    fun downloadAndInstall(ctx: Context) {
        if (busy) return
        busy = true
        status = "Скачиваю обновление…"
        Thread {
            runCatching {
                val dir = File(ctx.cacheDir, "update").apply { mkdirs() }
                val f = File(dir, "app.apk")
                val c = open(base(ctx) + "app-debug.apk", 60000)
                try {
                    if (c.responseCode !in 200..299) throw IOException("HTTP " + c.responseCode)
                    val total = c.contentLengthLong
                    c.inputStream.use { inp ->
                        f.outputStream().use { out ->
                            val buf = ByteArray(65536)
                            var done = 0L
                            var n = inp.read(buf)
                            while (n > 0) {
                                out.write(buf, 0, n)
                                done += n
                                if (total > 0) status = "Скачиваю обновление… " + (done * 100 / total) + "%"
                                n = inp.read(buf)
                            }
                        }
                    }
                } finally { c.disconnect() }
                f
            }.onSuccess { f ->
                busy = false
                status = "Готово — подтверди установку"
                Handler(Looper.getMainLooper()).post { install(ctx, f) }
            }.onFailure { e ->
                busy = false
                status = "Ошибка скачивания: " + (e.message ?: e.javaClass.simpleName)
            }
        }.start()
    }

    private fun install(ctx: Context, f: File) {
        runCatching {
            if (!ctx.packageManager.canRequestPackageInstalls()) {
                Toast.makeText(ctx, "Разреши установку из этого приложения, затем нажми «Обновить» ещё раз", Toast.LENGTH_LONG).show()
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            }
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }.onFailure { e -> status = "Не удалось открыть установщик: " + (e.message ?: e.javaClass.simpleName) }
    }
}
