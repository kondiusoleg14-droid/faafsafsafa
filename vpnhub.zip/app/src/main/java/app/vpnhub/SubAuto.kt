package app.vpnhub

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.runBlocking

/**
 * Автообновление подписок. Работает при запуске приложения и пока включён VPN (раз в 30 минут проверяется расписание).
 * Список серверов заменяется ТОЛЬКО если он реально изменился — иначе VPN не переподключается.
 */
object SubAuto {
    var running by mutableStateOf(false)
    var status by mutableStateOf("")

    fun due(): Boolean =
        Ui.subAuto && Store.subs.isNotEmpty() && System.currentTimeMillis() - Ui.subLast > Ui.subHours * 3600_000L

    /** force = обновить сейчас, не глядя на расписание и переключатель. */
    fun run(force: Boolean) {
        if (running) return
        if (!force && !due()) return
        if (Store.subs.isEmpty()) { if (force) status = "Подписок нет — добавь через «+»"; return }
        running = true
        if (force) status = "Обновляю подписки…"
        Thread {
            var total = 0
            var failed = 0
            var changed = 0
            for (sub in Store.subs.toList()) {
                total++
                try {
                    val l = runBlocking { loadSub(sub.url) }
                    val r = l.result
                    if (r == null || r.links.isEmpty()) {
                        failed++
                        Store.subInfo[sub.id] = l.diag
                        continue
                    }
                    Store.subInfo.remove(sub.id)
                    val oldIds = Store.servers.filter { it.subId == sub.id }.map { it.id }.toSet()
                    val newIds = Store.previewIds(sub.id, r.links)
                    if (newIds.isNotEmpty() && newIds != oldIds) {
                        Store.replaceSub(sub.id, r.links)
                        changed++
                    }
                    val title = l.title
                    if (!title.isNullOrBlank()) {
                        val i = Store.subs.indexOfFirst { it.id == sub.id }
                        if (i >= 0 && Store.subs[i].name != title) { Store.subs[i] = Store.subs[i].copy(name = title); Store.save() }
                    }
                } catch (e: Exception) { failed++ }
            }
            val now = System.currentTimeMillis()
            // если не удалось вообще ничего (нет сети) — повторим через ~30 минут, а не через полные N часов
            Ui.subLast = if (failed == total) now - Ui.subHours * 3600_000L + 30 * 60_000L else now
            Ui.save()
            val time = java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(now))
            status = when {
                failed == total -> "Не удалось обновить ($time) — проверь интернет или ссылку подписки"
                changed > 0 -> "Обновлено $time: изменились серверы в подписках ($changed из $total)"
                failed > 0 -> "Обновлено $time, но часть подписок не ответила ($failed из $total)"
                else -> "Проверено $time: изменений нет"
            }
            running = false
        }.start()
    }
}
