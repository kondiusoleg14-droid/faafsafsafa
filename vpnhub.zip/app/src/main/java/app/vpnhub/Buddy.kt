package app.vpnhub

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.IdentityHashMap
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.random.Random

// Спрайты лежат в res/drawable-nodpi как bk_*.webp (те же, что в ПК-версии).
private val BK_BLINK = setOf("sit", "tea", "cs")     // у этих спрайтов есть кадр с закрытыми глазами (_b)
private val BK_EARS = setOf("sit", "tea")            // и кадры дёргающихся ушей (_e1a/_e1b/_e2a/_e2b)
private const val BK_LIE_N = 9
private const val BK_HUG_N = 9

private val bkMemory = IdentityHashMap<List<String>, MutableList<String>>()

/** Случайная фраза без частых повторов. */
private fun bkPick(pool: List<String>): String {
    if (pool.isEmpty()) return ""
    val h = bkMemory.getOrPut(pool) { mutableListOf() }
    var t = pool.random()
    var n = 0
    while (pool.size > 3 && t in h && n < 8) { t = pool.random(); n++ }
    h.add(t)
    while (h.size > minOf(5, pool.size - 1)) h.removeAt(0)
    return t
}

private fun bkSay(key: String): List<String> {
    val sk = BuddySkins.active()
    if (sk != null) return sk.pools[key] ?: sk.pools.getValue("idle")        // в скине — только его реплики
    return BuddyPhrases.SAY[key] ?: BuddyPhrases.SAY.getValue("idle")
}
private fun bkCanBlink(base: String) = base in BK_BLINK || BuddySkins.def(base)?.blink == true
private fun bkCanEars(base: String) = base in BK_EARS || BuddySkins.def(base)?.ears == true

private fun bkHourPool(): List<String> {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return bkSay(if (h < 5) "night" else if (h < 11) "morning" else if (h < 17) "day" else if (h < 23) "evening" else "night")
}

/**
 * Бойкиссер для телефона: те же спрайты и поведение, что на ПК — моргает и дёргает ушками, реагирует на VPN
 * (подключился — пьёт чай, ошибка — стесняется), гладится рукой, ложится спать, обнимает экран, говорит фразы.
 * Включается 10 нажатиями на название; тема «Скорпион» — ниндзя.
 */
@Composable
fun CatOverlay() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var center by remember { mutableStateOf(Offset.Zero) }
    var petting by remember { mutableStateOf(false) }
    var acc by remember { mutableFloatStateOf(0f) }
    var petStart by remember { mutableLongStateOf(0L) }
    var handPos by remember { mutableStateOf(Offset.Zero) }
    var handFrame by remember { mutableIntStateOf(1) }
    var variant by remember { mutableStateOf("") }
    var say by remember { mutableStateOf("") }
    var sayAt by remember { mutableLongStateOf(0L) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var lastMeow by remember { mutableLongStateOf(0L) }
    var lastActive by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var lying by remember { mutableStateOf(false) }
    var lieFrame by remember { mutableIntStateOf(1) }
    var lieBusy by remember { mutableStateOf(false) }
    var hug by remember { mutableIntStateOf(0) }          // 0 — нет объятий, 1..9 — кадр
    var menu by remember { mutableStateOf(false) }
    var firstVpn by remember { mutableStateOf(true) }
    val clicks = remember { mutableListOf<Long>() }
    val hearts = remember { mutableStateListOf<Pair<Long, Float>>() }
    val hugScale = remember { Animatable(0f) }
    val hugAlpha = remember { Animatable(0f) }

    val scorpion = Ui.scorpion
    val skinDef = BuddySkins.active()
    // какой спрайт показывать: скин → ниндзя (тема «Скорпион») → ошибка VPN (стесняется) → VPN включён (чай и плед) → обычный
    val base = when {
        skinDef != null -> skinDef.id
        scorpion -> "mask"
        Vpn.error != null && Vpn.state != "on" -> "shy"
        Vpn.state == "on" -> "tea"
        else -> "sit"
    }
    val showLie = lying && !scorpion && skinDef == null
    val asleep = lying && !lieBusy

    fun speak(t: String) { say = t; sayAt = System.currentTimeMillis() }

    // ---------- анимации ----------
    val inf = rememberInfiniteTransition(label = "bk")
    val breathe by inf.animateFloat(1f, 1.018f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe")
    val nuzzle by inf.animateFloat(-4f, 4f, infiniteRepeatable(tween(230, easing = LinearEasing), RepeatMode.Reverse), label = "nuzzle")

    LaunchedEffect(Unit) { BuddySkins.load(ctx) }
    LaunchedEffect(Unit) { while (true) { delay(60); now = System.currentTimeMillis(); if (hearts.isNotEmpty()) hearts.removeAll { now - it.first > 1300 } } }

    // моргание и дёргание ушками (только у тех спрайтов, где есть такие кадры)
    LaunchedEffect(base, showLie) {
        variant = ""
        if (showLie) return@LaunchedEffect
        while (true) {
            delay(2200L + Random.nextLong(3200L))
            if (!petting && bkCanBlink(base)) { variant = "_b"; delay(130); variant = "" }
        }
    }
    LaunchedEffect(base, showLie) {
        if (showLie) return@LaunchedEffect
        while (true) {
            delay(3500L + Random.nextLong(4500L))
            if (!petting && bkCanEars(base)) {
                val n = 1 + Random.nextInt(2)
                variant = "_e${n}a"; delay(110); variant = "_e${n}b"; delay(110); variant = "_e${n}a"; delay(110); variant = ""
            }
        }
    }

    // поглаживание: мурлыканье, сердечки, рука по кадрам
    LaunchedEffect(petting) {
        if (petting) {
            petStart = System.currentTimeMillis()
            Sound.purrStart(); speak(bkPick(bkSay("pet")))
            launch { while (true) { handFrame = handFrame % 7 + 1; delay(60) } }
            while (true) { hearts.add(System.currentTimeMillis() to Random.nextFloat()); delay(380) }
        } else {
            Sound.purrStop()
            if (petStart > 0L && System.currentTimeMillis() - petStart > 6000L) speak(bkPick(bkSay("petLong")))
            petStart = 0L
        }
    }
    DisposableEffect(Unit) { onDispose { Sound.purrStop() } }

    // реакции на VPN
    LaunchedEffect(Vpn.state) {
        if (firstVpn) { firstVpn = false; return@LaunchedEffect }
        when (Vpn.state) {
            "starting" -> speak(bkPick(bkSay("vpnConnecting")))
            "on" -> speak(bkPick(bkSay("vpnOn")))
            "off" -> speak(bkPick(bkSay("vpnOff")))
        }
    }
    LaunchedEffect(Vpn.error) { if (Vpn.error != null) speak(bkPick(bkSay("vpnError"))) }

    // реплики по ситуации, в покое — «ты тут?»
    LaunchedEffect(Unit) {
        delay(700)
        speak(bkPick(if (Random.nextBoolean()) bkSay("hello") else bkHourPool()))
        var gap = 12000L
        while (true) {
            delay(1500)
            if (petting || hug > 0 || menu) continue
            if (System.currentTimeMillis() - sayAt > gap) {
                val idle = System.currentTimeMillis() - lastActive
                val pool = when {
                    lying -> bkSay("lie")
                    Ui.scorpion -> bkSay("mask")
                    idle > 120000L && Random.nextFloat() < 0.5f -> bkSay("bored")
                    Vpn.error != null && Vpn.state != "on" -> bkSay("vpnError")
                    Vpn.state == "on" -> if (Random.nextFloat() < 0.45f) bkSay("vpnOnIdle") else if (Random.nextFloat() < 0.3f) bkHourPool() else bkSay("idle")
                    Random.nextFloat() < 0.3f -> bkHourPool()
                    else -> bkSay("idle")
                }
                speak(bkPick(pool))
                gap = 14000L + Random.nextLong(8000L)
            }
        }
    }

    // ---------- команды ----------
    fun lieDown() {
        if (lying || lieBusy) return
        menu = false
        if (Ui.scorpion || BuddySkins.active() != null) { lying = true; speak(bkPick(bkSay("lie"))); return }
        lieBusy = true; lying = true; lieFrame = 1
        speak(bkPick(bkSay("lieStart")))
        scope.launch {
            for (i in 2..BK_LIE_N) { delay(420); lieFrame = i }
            lieBusy = false
            speak(bkPick(bkSay("lie")))
        }
    }
    fun standUp() {
        if (!lying || lieBusy) return
        menu = false
        if (Ui.scorpion || BuddySkins.active() != null) { lying = false; speak(bkPick(bkSay("wake"))); return }
        lieBusy = true
        scope.launch {
            for (i in BK_LIE_N - 1 downTo 1) { delay(240); lieFrame = i }
            lying = false; lieBusy = false
            speak(bkPick(bkSay("wake")))
        }
    }
    fun doHug() {
        if (hug != 0) return
        menu = false; petting = false
        scope.launch {
            speak(bkPick(bkSay("hugStart")))
            hug = 1
            hugAlpha.snapTo(0f); hugScale.snapTo(0f)
            launch { hugAlpha.animateTo(1f, tween(250)) }
            launch { hugScale.animateTo(1f, tween(1500, easing = FastOutSlowInEasing)) }
            for (n in 2..BK_HUG_N) { delay(230); hug = n }
            delay(1700)
            launch { hugScale.animateTo(0f, tween(1100, easing = FastOutSlowInEasing)) }
            for (n in BK_HUG_N - 1 downTo 1) { delay(120); hug = n }
            hugAlpha.animateTo(0f, tween(250))
            hug = 0
            speak(bkPick(bkSay("hugEnd")))
        }
    }

    // ---------- вид ----------
    val d0 = Egg.touch - center
    val tilt = when {
        petting -> nuzzle
        Egg.touch.x < 0f -> 0f
        else -> (d0.x / 400f * 7f).coerceIn(-7f, 7f)
    }
    fun resId(name: String): Int = ctx.resources.getIdentifier(name, "drawable", ctx.packageName)
    val spriteName = if (showLie) "bk_lie$lieFrame" else "bk_$base$variant"
    val sprite = resId(spriteName).takeIf { it != 0 } ?: resId("bk_$base").takeIf { it != 0 } ?: resId("bk_sit")
    val heightDp = if (showLie) 150.dp else if (base == "mask" || base == "smk") 190.dp else 170.dp

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomEnd) {
        Box(
            Modifier.padding(end = 8.dp, bottom = 92.dp)
                .alpha(if (hug > 0) 0f else 1f)
                .onGloballyPositioned { center = it.positionInRoot() + Offset(it.size.width / 2f, it.size.height * 0.45f) }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { p -> acc = 0f; handPos = p; lastActive = System.currentTimeMillis() },
                        onDragEnd = { petting = false; acc = 0f },
                        onDragCancel = { petting = false; acc = 0f }
                    ) { change, drag ->
                        acc += abs(drag.x) + abs(drag.y)
                        handPos = change.position
                        lastActive = System.currentTimeMillis()
                        if (acc > 220f) petting = true
                        change.consume()
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            val t = System.currentTimeMillis()
                            lastActive = t
                            hearts.add(t to Random.nextFloat())
                            clicks.removeAll { t - it > 2500L }
                            clicks.add(t)
                            speak(bkPick(bkSay(if (clicks.size >= 5) "annoyed" else "click")))
                            if (t - lastMeow > 450) { lastMeow = t; Sound.meow(Random.nextFloat() < 0.4f) }
                        },
                        onLongPress = { menu = true }
                    )
                }
        ) {
            Image(
                painter = painterResource(sprite),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.height(heightDp).graphicsLayer {
                    rotationZ = tilt
                    scaleY = breathe
                    transformOrigin = TransformOrigin(0.5f, 1f)
                }
            )
            hearts.forEach { (born, frac) ->
                val age = ((now - born) / 1300f).coerceIn(0f, 1f)
                Text("❤", color = Color(0xFFFF5C8A), fontSize = 18.sp, modifier = Modifier.offset(x = (30f + 90f * frac).dp, y = (70f - 100f * age).dp).alpha(1f - age))
            }
            if (asleep) Text("💤", fontSize = 22.sp, modifier = Modifier.align(Alignment.TopEnd).padding(end = 14.dp, top = 4.dp).alpha(0.5f + 0.5f * (breathe - 1f) / 0.018f))
            if (petting) {
                val handRes = resId("bk_hand$handFrame")
                if (handRes != 0) Image(
                    painter = painterResource(handRes),
                    contentDescription = null,
                    modifier = Modifier
                        .requiredSize(110.dp, 112.dp)
                        .offset { IntOffset((handPos.x - 0.88f * 110.dp.toPx()).roundToInt(), (handPos.y - 0.52f * 112.dp.toPx()).roundToInt()) }
                        .graphicsLayer { rotationZ = 14f; transformOrigin = TransformOrigin(0.88f, 0.52f) }
                )
            }
            if (say.isNotEmpty() && now - sayAt < 3600L) {
                Text(
                    say, color = Ui.pal.text, fontSize = 13.sp,
                    modifier = Modifier.align(Alignment.TopStart).offset(x = (-110).dp, y = (-20).dp)
                        .background(Ui.pal.sheet, RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text(if (lying) "Сесть" else "Лечь") }, onClick = { if (lying) standUp() else lieDown() })
                if (skinDef == null) DropdownMenuItem(text = { Text("Обнять экран") }, onClick = { doHug() })
                DropdownMenuItem(text = { Text("Скин: " + BuddySkins.name(BuddySkins.current)) }, onClick = { BuddySkins.cycle(ctx); menu = false; speak(bkPick(bkSay("idle"))) })
                DropdownMenuItem(text = { Text("Спрятать (вернуть: 10 нажатий на название)") }, onClick = { menu = false; Egg.cat = false })
            }
        }
    }

    // объятие: кадры из гифки на весь экран, кот «подъезжает» из правого нижнего угла и обнимает экран
    if (hug > 0) {
        val hugRes = resId("bk_hug$hug")
        if (hugRes != 0) Box(
            Modifier.fillMaxSize().pointerInput(Unit) {
                awaitPointerEventScope { while (true) { awaitPointerEvent().changes.forEach { it.consume() } } }
            }
        ) {
            Image(
                painter = painterResource(hugRes),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().graphicsLayer {
                    val p = hugScale.value
                    val k0 = 0.28f
                    val k = k0 + (1f - k0) * p
                    scaleX = k; scaleY = k
                    translationX = (1f - p) * (size.width / 2f - 90.dp.toPx())
                    translationY = (1f - p) * (size.height / 2f - 190.dp.toPx())
                    alpha = hugAlpha.value
                }
            )
        }
    }
}
