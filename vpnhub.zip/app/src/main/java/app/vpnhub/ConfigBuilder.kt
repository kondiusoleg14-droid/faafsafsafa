package app.vpnhub

import org.json.JSONArray
import org.json.JSONObject

object ConfigBuilder {
    private const val MAX_AUTO = 40

    private fun tweak(o: JSONObject, sni: String) {
        val type = o.optString("type")
        val tls = o.optJSONObject("tls") ?: return
        if (!tls.optBoolean("enabled")) return
        val reality = tls.optJSONObject("reality") != null
        if (reality) return
        if (sni.isNotEmpty()) tls.put("server_name", sni)
        if (type !in setOf("hysteria2", "hysteria", "tuic") && !tls.has("utls"))
            tls.put("utls", JSONObject().put("enabled", true).put("fingerprint", "chrome"))
    }

    private fun urltest(tag: String, tags: List<String>) = JSONObject().put("type", "urltest").put("tag", tag)
        .put("outbounds", JSONArray(tags))
        .put("url", "https://www.gstatic.com/generate_204").put("interval", "3m").put("tolerance", 50)

    fun build(): String {
        val all = Store.servers.toList()
        val sel = Store.selected
        val members: List<Server> = when {
            sel == "auto" -> all.take(MAX_AUTO)
            sel != null && sel.startsWith("g:") -> all.filter { it.gkey == sel.removePrefix("g:") }
            else -> listOfNotNull(all.firstOrNull { it.id == sel })
        }
        if (members.isEmpty()) error(if (all.isEmpty()) "Нет серверов" else "Не выбран сервер")
        val memberIds = members.map { it.id }.toSet()
        val used = LinkedHashMap<String, Server>()
        members.forEach { used[it.id] = it }
        Store.appRules.values.forEach { id -> all.firstOrNull { it.id == id }?.let { used[id] = it } }

        val sni = Store.sniOverride.trim()
        val outbounds = JSONArray()
        val memberTags = mutableListOf<String>()
        used.values.forEach { s ->
            val obs = Parser.outbounds(s, "s-" + s.id)
            obs.forEach { tweak(it, sni); outbounds.put(it) }
            if (obs.isNotEmpty() && s.id in memberIds) memberTags.add("s-" + s.id)
        }
        if (memberTags.isEmpty()) {
            if (members.any { it.kind.contains("⚠") }) error("Этот сервер использует транспорт (XHTTP/mKCP), который ядро sing-box не поддерживает. Выбери сервер без значка ⚠.")
            error("Ни один сервер не удалось разобрать")
        }
        val defTag = if (memberTags.size > 1) {
            outbounds.put(urltest("main", memberTags)); "main"
        } else memberTags[0]
        outbounds.put(JSONObject().put("type", "direct").put("tag", "direct"))

        val rules = JSONArray()
        rules.put(JSONObject().put("action", "sniff"))
        rules.put(JSONObject().put("protocol", "dns").put("action", "hijack-dns"))
        val byTag = LinkedHashMap<String, MutableList<String>>()
        Store.appRules.forEach { (pkg, target) ->
            val tag = if (target == "direct") "direct" else if (used.containsKey(target)) "s-$target" else null
            if (tag != null) byTag.getOrPut(tag) { mutableListOf() }.add(pkg)
        }
        byTag.forEach { (tag, pkgs) -> rules.put(JSONObject().put("package_name", JSONArray(pkgs)).put("outbound", tag)) }
        rules.put(JSONObject().put("ip_is_private", true).put("outbound", "direct"))
        if (Store.ruDirect) rules.put(JSONObject().put("domain_suffix", JSONArray(listOf("ru", "su", "xn--p1ai"))).put("outbound", "direct"))

        // "local" в старом виде на Android не работает (нет системных DNS) — используем явный адрес напрямую
        val dns = JSONObject()
            .put("servers", JSONArray()
                .put(JSONObject().put("tag", "local").put("address", "77.88.8.8").put("detour", "direct"))
                .put(JSONObject().put("tag", "remote").put("address", "tls://1.1.1.1").put("detour", defTag)))
            .put("rules", JSONArray().put(JSONObject().put("outbound", "any").put("server", "local")))
            .put("final", "remote")

        val tun = JSONObject().put("type", "tun").put("tag", "tun-in")
            .put("address", JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
            .put("mtu", 9000).put("auto_route", true).put("stack", "mixed")

        return JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", dns)
            .put("inbounds", JSONArray().put(tun))
            .put("outbounds", outbounds)
            .put("route", JSONObject().put("rules", rules).put("final", defTag).put("auto_detect_interface", true))
            .toString()
    }
}
