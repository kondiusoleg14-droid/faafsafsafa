package app.vpnhub

import org.json.JSONArray
import org.json.JSONObject

object ConfigBuilder {
    private const val MAX_AUTO = 40

    private fun tweak(o: JSONObject, sni: String) {
        val type = o.optString("type")
        val tls = o.optJSONObject("tls") ?: return
        if (!tls.optBoolean("enabled")) return
        val reality = tls.optJSONObject("reality") != null
        if (reality) return
        if (sni.isNotEmpty()) tls.put("server_name", sni)
        if (type !in setOf("hysteria2", "hysteria", "tuic") && !tls.has("utls"))
            tls.put("utls", JSONObject().put("enabled", true).put("fingerprint", "chrome"))
    }

    fun build(): String {
        val auto = Store.selected == "auto"
        if (auto && Store.servers.isEmpty()) error("Нет серверов")
        val sel = if (auto) null else (Store.servers.firstOrNull { it.id == Store.selected } ?: error("Не выбран сервер"))
        val autoIds = if (auto) Store.servers.take(MAX_AUTO).map { it.id }.toSet() else emptySet()
        val used = LinkedHashMap<String, Server>()
        if (auto) Store.servers.filter { it.id in autoIds }.forEach { used[it.id] = it } else used[sel!!.id] = sel
        Store.appRules.values.forEach { id -> Store.servers.firstOrNull { it.id == id }?.let { used[id] = it } }

        val sni = Store.sniOverride.trim()
        val outbounds = JSONArray()
        val autoTags = mutableListOf<String>()
        used.values.forEach { s ->
            Parser.outbound(s, "s-" + s.id)?.let { o ->
                tweak(o, sni); outbounds.put(o)
                if (s.id in autoIds) autoTags.add(o.getString("tag"))
            }
        }
        if (auto) {
            if (autoTags.isEmpty()) error("Ни один сервер не удалось разобрать")
            outbounds.put(JSONObject().put("type", "urltest").put("tag", "auto")
                .put("outbounds", JSONArray(autoTags))
                .put("url", "https://www.gstatic.com/generate_204").put("interval", "3m").put("tolerance", 50))
        }
        outbounds.put(JSONObject().put("type", "direct").put("tag", "direct"))
        val defTag = if (auto) "auto" else "s-" + sel!!.id

        val rules = JSONArray()
        rules.put(JSONObject().put("action", "sniff"))
        rules.put(JSONObject().put("protocol", "dns").put("action", "hijack-dns"))
        val byTag = LinkedHashMap<String, MutableList<String>>()
        Store.appRules.forEach { (pkg, target) ->
            val tag = if (target == "direct") "direct" else if (used.containsKey(target)) "s-$target" else null
            if (tag != null) byTag.getOrPut(tag) { mutableListOf() }.add(pkg)
        }
        byTag.forEach { (tag, pkgs) -> rules.put(JSONObject().put("package_name", JSONArray(pkgs)).put("outbound", tag)) }
        rules.put(JSONObject().put("ip_is_private", true).put("outbound", "direct"))
        if (Store.ruDirect) rules.put(JSONObject().put("domain_suffix", JSONArray(listOf("ru", "su", "xn--p1ai"))).put("outbound", "direct"))

        val dns = JSONObject()
            .put("servers", JSONArray()
                .put(JSONObject().put("tag", "local").put("address", "local"))
                .put(JSONObject().put("tag", "remote").put("address", "tls://1.1.1.1").put("detour", defTag)))
            .put("rules", JSONArray().put(JSONObject().put("outbound", "any").put("server", "local")))
            .put("final", "remote")

        val tun = JSONObject().put("type", "tun").put("tag", "tun-in")
            .put("address", JSONArray().put("172.19.0.1/30"))
            .put("mtu", 9000).put("auto_route", true).put("stack", "mixed")

        return JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", dns)
            .put("inbounds", JSONArray().put(tun))
            .put("outbounds", outbounds)
            .put("route", JSONObject().put("rules", rules).put("final", defTag).put("auto_detect_interface", true))
            .toString()
    }
}
