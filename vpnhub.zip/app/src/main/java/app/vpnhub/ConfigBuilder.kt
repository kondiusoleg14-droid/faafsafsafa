package app.vpnhub

import org.json.JSONArray
import org.json.JSONObject

object ConfigBuilder {
    fun build(): String {
        val sel = Store.servers.firstOrNull { it.id == Store.selected } ?: error("Не выбран сервер")
        val used = LinkedHashMap<String, Server>()
        used[sel.id] = sel
        Store.appRules.values.forEach { id -> Store.servers.firstOrNull { it.id == id }?.let { used[id] = it } }

        val outbounds = JSONArray()
        used.values.forEach { s -> Parser.outbound(s, "s-" + s.id)?.let { outbounds.put(it) } }
        outbounds.put(JSONObject().put("type", "direct").put("tag", "direct"))
        val defTag = "s-" + sel.id

        val rules = JSONArray()
        rules.put(JSONObject().put("action", "sniff"))
        rules.put(JSONObject().put("protocol", "dns").put("action", "hijack-dns"))
        val byTag = LinkedHashMap<String, MutableList<String>>()
        Store.appRules.forEach { (pkg, target) ->
            val tag = if (target == "direct") "direct" else if (used.containsKey(target)) "s-$target" else null
            if (tag != null) byTag.getOrPut(tag) { mutableListOf() }.add(pkg)
        }
        byTag.forEach { (tag, pkgs) -> rules.put(JSONObject().put("package_name", JSONArray(pkgs)).put("outbound", tag)) }
        rules.put(JSONObject().put("ip_is_private", true).put("outbound", "direct"))

        val dns = JSONObject()
            .put("servers", JSONArray()
                .put(JSONObject().put("tag", "local").put("address", "local"))
                .put(JSONObject().put("tag", "remote").put("address", "tls://1.1.1.1").put("detour", defTag)))
            .put("rules", JSONArray().put(JSONObject().put("outbound", "any").put("server", "local")))
            .put("final", "remote")

        val tun = JSONObject().put("type", "tun").put("tag", "tun-in")
            .put("address", JSONArray().put("172.19.0.1/30"))
            .put("mtu", 9000).put("auto_route", true).put("stack", "mixed")

        return JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", dns)
            .put("inbounds", JSONArray().put(tun))
            .put("outbounds", outbounds)
            .put("route", JSONObject().put("rules", rules).put("final", defTag).put("auto_detect_interface", true))
            .toString()
    }
}
