package app.vpnhub

import org.json.JSONArray
import org.json.JSONObject

object ConfigBuilder {
    private const val MAX_AUTO = 40

    /** Серверы, которые ядро не приняло при проверке конфига (id → причина): исключаем их, чтобы один неподдерживаемый сервер не ронял запуск. */
    val skip = HashMap<String, String>()
    private val tagOwner = HashMap<String, String>()     // тег outbound → id сервера
    fun serverOfTag(tag: String): String? = tagOwner[tag]
    private const val WL_TOPK = 12     // сколько лучших серверов обхода БС отдаём urltest
    private const val CAT_TOPK = 6     // сколько лучших серверов категории

    private fun tweak(o: JSONObject, sni: String) {
        val type = o.optString("type")
        val tls = o.optJSONObject("tls") ?: return
        if (!tls.optBoolean("enabled")) return
        val reality = tls.optJSONObject("reality") != null
        if (reality) return
        if (sni.isNotEmpty()) tls.put("server_name", sni)
        if (type !in setOf("hysteria2", "hysteria", "tuic") && !tls.has("utls"))
            tls.put("utls", JSONObject().put("enabled", true).put("fingerprint", "chrome"))
    }

    private fun urltest(tag: String, tags: List<String>, interval: String = "5m", interrupt: Boolean = false) = JSONObject().put("type", "urltest").put("tag", tag)
        .put("outbounds", JSONArray(tags))
        .put("url", "https://www.gstatic.com/generate_204").put("interval", interval).put("tolerance", if (interrupt) 100 else 200).put("interrupt_exist_connections", interrupt)

    /** «Авто» и группы выбирают среди TCP-серверов: UDP-протоколы (Hysteria2) часто режутся провайдером и дают долгую загрузку видео. */
    private fun preferTcp(list: List<Server>, target: String?): List<Server> {
        if (!Store.preferTcp || target == null || !(target == "auto" || target.startsWith("g:"))) return list
        val tcp = list.filter { !it.isUdp }
        return if (tcp.isNotEmpty()) tcp else list
    }

    private fun tcpFirst(list: List<Server>): List<Server> {
        if (!Store.preferTcp) return list
        val tcp = list.filter { !it.isUdp }
        return if (tcp.isNotEmpty()) tcp else list
    }

    fun build(wl: Boolean = false): String {
        val all = Store.servers.toList()
        // режим белых списков: серверы выбранных групп; порядок — по оценке (успешность, стабильность, сеть, настройки обхода, приоритет группы),
        // лучшие отдаём urltest, он выбирает живой по задержке
        val wlPool = if (wl && Store.wlAuto) all.filter { it.gkey in Store.wlGroups && !it.kind.contains("⚠") } else emptyList()
        val wlList = if (wlPool.isEmpty()) emptyList() else Health.rank(tcpFirst(wlPool).filter { Health.usable(it) }.ifEmpty { tcpFirst(wlPool) }, wl = true).take(WL_TOPK)
        val useWl = wlList.isNotEmpty()
        Vpn.wlActive = useWl
        val sel = Store.selected
        val members0: List<Server> = if (useWl) wlList else if (sel == null) emptyList() else preferTcp(Store.resolve(sel), sel)
        // служебные записи подписки (127.0.0.1:1 — «осталось N дней» и т.п.) в группу не берём: через них трафик не пойдёт,
        // а до первой проверки urltest отправляет всё в первый сервер списка — и интернет «пропадает»
        val members = members0.filter { !it.dummy }
        if (members0.isNotEmpty() && members.isEmpty()) error("Выбрана служебная запись подписки (адрес 127.0.0.1), а не сервер. Выбери другой сервер или «Авто».")
        if (members.isEmpty()) error(if (all.isEmpty()) "Нет серверов" else "Не выбран сервер")

        // какие серверы нужны: выбранные по умолчанию + назначенные приложениям (в том числе группами)
        val needed = LinkedHashMap<String, Server>()
        members.forEach { needed[it.id] = it }
        Store.appRules.values.forEach { target ->
            if (target != "direct") Store.resolve(target).forEach { needed[it.id] = it }
            if (target.startsWith("cat:") && Store.catById(target.removePrefix("cat:"))?.fallback == "auto") Store.resolve("auto").forEach { needed[it.id] = it }
        }

        val sni = Store.sniOverride.trim()
        val outbounds = JSONArray()
        val built = HashMap<String, Boolean>() // serverId -> удалось ли собрать
        tagOwner.clear()
        needed.values.forEach { s ->
            val obs = if (s.id in skip) emptyList() else Parser.outbounds(s, "s-" + s.id)
            obs.forEach { tweak(it, sni); outbounds.put(it); tagOwner[it.optString("tag")] = s.id }
            built[s.id] = obs.isNotEmpty()
        }
        val memberTags = members.filter { built[it.id] == true }.map { "s-" + it.id }
        if (memberTags.isEmpty()) {
            members.firstOrNull { it.id in skip }?.let { error("Ядро не приняло этот сервер: " + skip[it.id]) }
            if (members.any { it.kind.contains("⚠") }) error("Ядро sing-box 1.11 не поддерживает протокол или транспорт этого сервера (XHTTP, mKCP, AnyTLS, Naive). Выбери сервер без значка ⚠.")
            error("Ни один сервер не удалось разобрать")
        }
        Health.appliedMain = members.filter { built[it.id] == true }.map { it.id }.toSet()
        val defTag = if (memberTags.size > 1) {
            outbounds.put(urltest("main", memberTags, if (useWl) "30s" else "2m", useWl)); "main"   // 2 мин: если первая проверка не прошла (сеть ещё не поднялась), ждать 5 минут слишком долго
        } else memberTags[0]
        outbounds.put(JSONObject().put("type", "direct").put("tag", "direct"))

        val catState = HashMap<String, Boolean>()
        fun groupTag(tag: String, ms: List<Server>, interval: String): String {
            var exists = false
            for (i in 0 until outbounds.length()) if (outbounds.getJSONObject(i).optString("tag") == tag) exists = true
            if (!exists) outbounds.put(urltest(tag, ms.map { "s-" + it.id }, interval))
            return tag
        }
        /** Категория: подходящие по названию серверы (лучшие по оценке) → если нет совпадений или все недоступны, запасной вариант категории. */
        fun catTag(target: String): String? {
            val cat = Store.catById(target.removePrefix("cat:")) ?: return null       // категорию удалили — основной сервер
            val matched = tcpFirst(Store.resolve(target).filter { built[it.id] == true })
            val top = Health.rank(matched.filter { Health.usable(it) }).take(CAT_TOPK)
            catState[cat.id] = top.isNotEmpty()
            if (top.size == 1) return "s-" + top[0].id
            if (top.size > 1) return groupTag("grp-cat-" + cat.id, top, "3m")
            return when (cat.fallback) {
                "direct" -> "direct"
                "auto" -> {
                    val a = Health.rank(tcpFirst(Store.resolve("auto").filter { built[it.id] == true })).take(CAT_TOPK)
                    when { a.isEmpty() -> null; a.size == 1 -> "s-" + a[0].id; else -> groupTag("grp-auto", a, "5m") }
                }
                else -> null                                                              // «основной сервер»: правило не нужно
            }
        }

        fun tagFor(target: String): String? {
            if (target == "direct") return "direct"
            if (target.startsWith("cat:")) return catTag(target)
            val ms = preferTcp(Store.resolve(target), target).filter { built[it.id] == true }
            return when {
                ms.isEmpty() -> null
                ms.size == 1 -> "s-" + ms[0].id
                else -> {
                    val tag = "grp-" + target.hashCode().toUInt().toString(16)
                    var exists = false
                    for (i in 0 until outbounds.length()) if (outbounds.getJSONObject(i).optString("tag") == tag) exists = true
                    if (!exists) outbounds.put(urltest(tag, ms.map { "s-" + it.id }))
                    tag
                }
            }
        }

        val rules = JSONArray()
        rules.put(JSONObject().put("action", "sniff"))
        rules.put(JSONObject().put("protocol", "dns").put("action", "hijack-dns"))
        // QUIC (UDP 443) через VLESS по TCP работает медленно и рвётся — отклоняем, приложения сами переходят на обычный HTTPS
        if (Store.blockQuic) rules.put(JSONObject().put("network", "udp").put("port", 443).put("action", "reject"))
        if (Store.blockIpv6) rules.put(JSONObject().put("ip_version", 6).put("action", "reject"))
        val byTag = LinkedHashMap<String, MutableList<String>>()
        Store.appRules.forEach { (pkg, target) ->
            val tag = tagFor(target)
            // правило, которое совпадает с сервером по умолчанию, не нужно — оно только замедляет (проверка владельца каждого соединения)
            if (tag != null && tag != defTag) byTag.getOrPut(tag) { mutableListOf() }.add(pkg)
        }
        byTag.forEach { (tag, pkgs) -> rules.put(JSONObject().put("package_name", JSONArray(pkgs)).put("outbound", tag)) }
        Health.appliedCat = catState
        rules.put(JSONObject().put("ip_is_private", true).put("outbound", "direct"))
        if (Store.ruDirect) rules.put(JSONObject().put("domain_suffix", JSONArray(listOf("ru", "su", "xn--p1ai"))).put("outbound", "direct"))

        // "local" в старом виде на Android не работает (нет системных DNS) — используем явный адрес напрямую.
        // ipv4_only: иначе приложения пробуют IPv6 первым, ждут таймаут и всё тормозит.
        val dns = JSONObject()
            .put("servers", JSONArray()
                .put(JSONObject().put("tag", "local").put("address", "77.88.8.8").put("detour", "direct"))
                .put(JSONObject().put("tag", "remote").put("address", "tls://1.1.1.1").put("detour", defTag)))
            .put("rules", JSONArray().put(JSONObject().put("outbound", "any").put("server", "local")))
            .put("final", "remote")
            .put("strategy", "ipv4_only")

        val tun = JSONObject().put("type", "tun").put("tag", "tun-in")
            .put("address", JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
            .put("mtu", 9000).put("auto_route", true).put("stack", "mixed")

        return JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", dns)
            .put("inbounds", JSONArray().put(tun))
            .put("outbounds", outbounds)
            .put("route", JSONObject().put("rules", rules).put("final", defTag).put("auto_detect_interface", true))
            .toString()
    }
}
