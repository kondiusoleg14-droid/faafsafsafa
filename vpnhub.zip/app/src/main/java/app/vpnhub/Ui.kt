package app.vpnhub

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class Pal(
    val bg: Color, val card: Color, val sheet: Color, val sel: Color, val chip: Color, val hdr: Color,
    val text: Color, val dim: Color, val accent: Color, val accent2: Color, val green: Color, val isLight: Boolean,
    val on2: Color = Color(0xFF1AA37A)
)

/** Оформление. Хранится отдельно от Store: смена оформления НЕ переподключает VPN. */
object Ui {
    private lateinit var sp: SharedPreferences

    var mode by mutableStateOf("dark")          // system | dark | light | custom
    var systemDark by mutableStateOf(true)
    var customBg by mutableStateOf("0B0F1A")
    var customCard by mutableStateOf("151B2B")
    var accentHex by mutableStateOf("")         // пусто = по умолчанию для темы
    var bgKind by mutableStateOf("none")        // none | grad0..grad5 | image
    var dim by mutableFloatStateOf(0.35f)
    var blur by mutableFloatStateOf(0f)
    var cardAlpha by mutableFloatStateOf(0.92f)
    var corner by mutableFloatStateOf(1f)
    var control by mutableStateOf("button")     // button | switch
    var title by mutableStateOf("VPN Hub")
    var haptic by mutableStateOf(true)
    var tv by mutableStateOf(false)             // режим телевизора (определяется при запуске)
    var scorpion by mutableStateOf(false)       // пасхалка: тема Mortal Kombat
    var femboy by mutableStateOf(false)         // пасхалка UwU
    var bgImage by mutableStateOf<ImageBitmap?>(null)
    var hasImage by mutableStateOf(false)
    var imageVersion by mutableIntStateOf(0)

    val grads: List<Triple<String, Color, Color>> = listOf(
        Triple("Закат", Color(0xFFFF7A59), Color(0xFF8E2DE2)),
        Triple("Океан", Color(0xFF00C6FF), Color(0xFF0052D4)),
        Triple("Лес", Color(0xFF38EF7D), Color(0xFF0B6E4F)),
        Triple("Роза", Color(0xFFFF6FD8), Color(0xFF3813C2)),
        Triple("Лава", Color(0xFFFF512F), Color(0xFFDD2476)),
        Triple("Лёд", Color(0xFFA1C4FD), Color(0xFF5B6CFF))
    )
    val accents = listOf("6C7BFF", "9B5CFF", "2ED3A0", "3AA0FF", "FF7A59", "FF4D8D", "F5C542", "FF5A5A")

    fun parseHex(s: String): Color? {
        val t = s.trim().removePrefix("#")
        if (t.length != 6 && t.length != 8) return null
        val v = t.toLongOrNull(16) ?: return null
        return if (t.length == 6) Color(0xFF000000L or v) else Color(v)
    }

    private fun shift(c: Color): Color {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(c.toArgb(), hsv)
        hsv[0] = (hsv[0] + 35f) % 360f
        return Color(android.graphics.Color.HSVToColor(hsv))
    }

    private fun compute(): Pal {
        val m = mode
        var light = false
        var bg = Color(0xFF0B0F1A)
        var card = Color(0xFF151B2B)
        when (m) {
            "light" -> { light = true }
            "system" -> { light = !systemDark }
            "custom" -> {
                bg = parseHex(customBg) ?: bg
                card = parseHex(customCard) ?: card
                light = bg.luminance() > 0.5f
            }
        }
        if (m == "light" || (m == "system" && light)) { bg = Color(0xFFF2F4FA); card = Color(0xFFFFFFFF) }
        val fem = femboy
        val mk = scorpion && !femboy
        if (fem) { light = true; bg = Color(0xFFFFE2F0); card = Color(0xFFFFFFFF) }
        if (mk) { light = false; bg = Color(0xFF0A0706); card = Color(0xFF1C1210) }
        val text = if (fem) Color(0xFF581845) else if (mk) Color(0xFFFFE7C2) else if (light) Color(0xFF141A2E) else Color.White
        val dimC = if (fem) Color(0xFFAA628C) else if (mk) Color(0xFFB98B5E) else if (light) Color(0xFF667086) else Color(0xFF8A93A8)
        val green = if (fem) Color(0xFFFF4FA3) else if (mk) Color(0xFFFFC21A) else if (light) Color(0xFF12A37C) else Color(0xFF2ED3A0)
        val custom = if (fem || mk) null else parseHex(accentHex)
        val accent = if (fem) Color(0xFFFF69B4) else if (mk) Color(0xFFFF6A00) else (custom ?: if (light) Color(0xFF4F5DFF) else Color(0xFF6C7BFF))
        val accent2 = if (fem) Color(0xFFBE82FF) else if (mk) Color(0xFFE0231B) else if (custom != null) shift(custom) else if (light) Color(0xFF8A4DFF) else Color(0xFF9B5CFF)
        val on2 = if (fem) Color(0xFFFF9ACB) else if (mk) Color(0xFFFF6A00) else Color(0xFF1AA37A)
        val cardOpaque = card.copy(alpha = 1f)
        return Pal(
            bg = bg,
            card = cardOpaque.copy(alpha = cardAlpha),
            sheet = lerp(bg, cardOpaque, 0.5f),
            sel = lerp(cardOpaque, accent, 0.28f),
            chip = lerp(cardOpaque, text, 0.10f),
            hdr = lerp(cardOpaque, accent, 0.12f),
            text = text, dim = dimC, accent = accent, accent2 = accent2, green = green, isLight = light, on2 = on2
        )
    }

    val pal: Pal by derivedStateOf { compute() }

    fun init(ctx: Context) {
        if (::sp.isInitialized) return
        sp = ctx.getSharedPreferences("ui", Context.MODE_PRIVATE)
        mode = sp.getString("mode", "dark") ?: "dark"
        customBg = sp.getString("customBg", "0B0F1A") ?: "0B0F1A"
        customCard = sp.getString("customCard", "151B2B") ?: "151B2B"
        accentHex = sp.getString("accent", "") ?: ""
        bgKind = sp.getString("bgKind", "none") ?: "none"
        dim = sp.getFloat("dim", 0.35f)
        blur = sp.getFloat("blur", 0f)
        cardAlpha = sp.getFloat("cardAlpha", 0.92f)
        corner = sp.getFloat("corner", 1f)
        control = sp.getString("control", "button") ?: "button"
        title = sp.getString("title", "VPN Hub") ?: "VPN Hub"
        haptic = sp.getBoolean("haptic", true)
        femboy = sp.getBoolean("femboy", false)
        scorpion = sp.getBoolean("scorpion", false)
        hasImage = File(ctx.filesDir, "bg.jpg").exists()
    }

    fun save() {
        if (!::sp.isInitialized) return
        sp.edit().putString("mode", mode).putString("customBg", customBg).putString("customCard", customCard)
            .putString("accent", accentHex).putString("bgKind", bgKind).putFloat("dim", dim).putFloat("blur", blur)
            .putFloat("cardAlpha", cardAlpha).putFloat("corner", corner).putString("control", control)
            .putString("title", title).putBoolean("haptic", haptic).putBoolean("femboy", femboy).putBoolean("scorpion", scorpion).apply()
    }

    fun reset(ctx: Context) {
        mode = "dark"; customBg = "0B0F1A"; customCard = "151B2B"; accentHex = ""; bgKind = "none"
        dim = 0.35f; blur = 0f; cardAlpha = 0.92f; corner = 1f; control = "button"; title = "VPN Hub"; haptic = true; femboy = false; scorpion = false
        runCatching { File(ctx.filesDir, "bg.jpg").delete() }
        bgImage = null; hasImage = false
        save()
    }

    /** Копирует выбранную картинку внутрь приложения, уменьшает и поворачивает по EXIF. */
    fun importBg(ctx: Context, uri: Uri): Boolean = runCatching {
        val raw = File(ctx.filesDir, "bg_raw")
        ctx.contentResolver.openInputStream(uri)!!.use { i -> raw.outputStream().use { o -> i.copyTo(o) } }
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(raw.path, o)
        var sample = 1
        while (maxOf(o.outWidth, o.outHeight) / sample > 2200) sample *= 2
        val d = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = BitmapFactory.decodeFile(raw.path, d) ?: return@runCatching false
        val rot = when (android.media.ExifInterface(raw.path).getAttributeInt("Orientation", 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        if (rot != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot) }, true)
        File(ctx.filesDir, "bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        raw.delete()
        true
    }.getOrDefault(false)

    suspend fun loadImage(ctx: Context) = withContext(Dispatchers.IO) {
        val f = File(ctx.filesDir, "bg.jpg")
        val b = if (f.exists()) runCatching { BitmapFactory.decodeFile(f.path)?.asImageBitmap() }.getOrNull() else null
        bgImage = b
        hasImage = b != null
    }
}
