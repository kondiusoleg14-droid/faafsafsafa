package app.vpnhub

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import io.nekohasekai.libbox.BoxService
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.SetupOptions
import io.nekohasekai.libbox.StringIterator
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState
import java.net.InetSocketAddress
import java.net.NetworkInterface as JNetworkInterface

private class StrIter(list: List<String>) : StringIterator {
    private val it = list.iterator()
    private val n = list.size
    override fun hasNext() = it.hasNext()
    override fun len() = n
    override fun next(): String = it.next()
}

class HubVpnService : VpnService(), PlatformInterface {
    private var box: BoxService? = null
    private var pfd: ParcelFileDescriptor? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private val cm by lazy { getSystemService(ConnectivityManager::class.java) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") { stopBox(); return START_NOT_STICKY }
        if (box != null) return START_NOT_STICKY
        startForeground(1, notification("Подключение…"))
        Vpn.state = "starting"; Vpn.error = null
        Thread {
            try {
                val base = filesDir.also { it.mkdirs() }
                val work = java.io.File(base, "work").also { it.mkdirs() }
                Libbox.setup(SetupOptions().also {
                    it.basePath = base.path; it.workingPath = work.path; it.tempPath = cacheDir.path
                    it.fixAndroidStack = true
                })
                val cfg = ConfigBuilder.build()
                Libbox.checkConfig(cfg)
                val svc = Libbox.newService(cfg, this)
                svc.start()
                box = svc
                Vpn.state = "on"
                (getSystemService(NotificationManager::class.java)).notify(1, notification("Подключено"))
            } catch (e: Throwable) {
                Vpn.error = e.message ?: e.toString()
                stopBox()
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun stopBox() {
        runCatching { box?.close() }
        box = null
        runCatching { pfd?.close() }
        pfd = null
        netCb?.let { runCatching { cm.unregisterNetworkCallback(it) } }
        netCb = null
        Vpn.state = "off"
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { stopBox(); super.onDestroy() }
    override fun onRevoke() { stopBox() }

    private fun notification(text: String): android.app.Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vpn", "VPN", NotificationManager.IMPORTANCE_LOW))
        return android.app.Notification.Builder(this, "vpn")
            .setContentTitle("VPN Hub").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock).setOngoing(true).build()
    }

    // ---- PlatformInterface ----
    override fun usePlatformAutoDetectInterfaceControl() = true
    override fun autoDetectInterfaceControl(fd: Int) { protect(fd) }

    override fun openTun(options: TunOptions): Int {
        val b = Builder().setSession("VPN Hub").setMtu(options.mtu)
        runCatching { b.addDisallowedApplication(packageName) }
        val v4 = options.inet4Address
        while (v4.hasNext()) { val a = v4.next(); b.addAddress(a.address(), a.prefix()) }
        val v6 = options.inet6Address
        while (v6.hasNext()) { val a = v6.next(); b.addAddress(a.address(), a.prefix()) }
        if (options.autoRoute) {
            b.addDnsServer(options.dnsServerAddress.value)
            b.addRoute("0.0.0.0", 0)
            b.addRoute("::", 0)
        }
        val p = b.establish() ?: error("Не удалось создать туннель (нет разрешения VPN?)")
        pfd = p
        return p.fd
    }

    override fun useProcFS() = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q

    override fun findConnectionOwner(ipProtocol: Int, sourceAddress: String, sourcePort: Int, destinationAddress: String, destinationPort: Int): Int =
        cm.getConnectionOwnerUid(ipProtocol, InetSocketAddress(sourceAddress, sourcePort), InetSocketAddress(destinationAddress, destinationPort))

    override fun packageNameByUid(uid: Int): String =
        packageManager.getPackagesForUid(uid)?.firstOrNull() ?: error("package not found")

    override fun uidByPackageName(packageName: String): Int =
        packageManager.getPackageUid(packageName, 0)

    override fun usePlatformDefaultInterfaceMonitor() = true

    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        val cb = object : ConnectivityManager.NetworkCallback() {
            private fun push(n: Network) {
                val name = cm.getLinkProperties(n)?.interfaceName ?: return
                val idx = runCatching { JNetworkInterface.getByName(name).index }.getOrNull() ?: return
                val caps = cm.getNetworkCapabilities(n)
                val metered = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == false
                listener.updateDefaultInterface(name, idx, metered, false)
            }
            override fun onAvailable(network: Network) = push(network)
            override fun onLinkPropertiesChanged(network: Network, lp: android.net.LinkProperties) = push(network)
            override fun onLost(network: Network) { listener.updateDefaultInterface("", -1, false, false) }
        }
        netCb = cb
        val req = NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build()
        if (Build.VERSION.SDK_INT >= 31) cm.registerBestMatchingNetworkCallback(req, cb, android.os.Handler(mainLooper))
        else cm.requestNetwork(req, cb)
    }

    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        netCb?.let { runCatching { cm.unregisterNetworkCallback(it) } }
        netCb = null
    }

    override fun usePlatformInterfaceGetter() = true

    override fun getInterfaces(): NetworkInterfaceIterator {
        val list = mutableListOf<io.nekohasekai.libbox.NetworkInterface>()
        for (n in cm.allNetworks) {
            val lp = cm.getLinkProperties(n) ?: continue
            val caps = cm.getNetworkCapabilities(n) ?: continue
            val ni = runCatching { JNetworkInterface.getByName(lp.interfaceName) }.getOrNull() ?: continue
            val box = io.nekohasekai.libbox.NetworkInterface()
            box.name = lp.interfaceName
            box.index = ni.index
            box.mtu = runCatching { ni.mtu }.getOrDefault(1500)
            box.dnsServer = StrIter(lp.dnsServers.mapNotNull { it.hostAddress })
            box.type = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> Libbox.InterfaceTypeWIFI
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> Libbox.InterfaceTypeCellular
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> Libbox.InterfaceTypeEthernet
                else -> Libbox.InterfaceTypeOther
            }
            box.addresses = StrIter(ni.interfaceAddresses.map { it.address.hostAddress + "/" + it.networkPrefixLength })
            var flags = 0
            if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) flags = OsConstants.IFF_UP or OsConstants.IFF_RUNNING
            if (ni.isLoopback) flags = flags or OsConstants.IFF_LOOPBACK
            if (ni.isPointToPoint) flags = flags or OsConstants.IFF_POINTOPOINT
            if (ni.supportsMulticast()) flags = flags or OsConstants.IFF_MULTICAST
            box.flags = flags
            box.metered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
            list.add(box)
        }
        val it = list.iterator()
        return object : NetworkInterfaceIterator {
            override fun hasNext() = it.hasNext()
            override fun next() = it.next()
        }
    }

    override fun underNetworkExtension() = false
    override fun includeAllNetworks() = false
    override fun clearDNSCache() {}
    override fun readWIFIState(): WIFIState? = null
    override fun systemCertificates(): StringIterator = StrIter(emptyList())
    override fun writeLog(message: String?) {}
    override fun sendNotification(notification: io.nekohasekai.libbox.Notification?) {}
}
