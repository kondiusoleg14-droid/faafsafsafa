package app.vpnhub

import org.json.JSONArray
import org.json.JSONObject

object Subscription {
    class Result(val format: String, val links: List<String>)

    private val proxyTypes = setOf("vless", "vmess", "trojan", "shadowsocks", "hysteria2", "hysteria", "tuic", "anytls")

    fun parse(body: String): Result {
        val t = body.trim().removePrefix("\uFEFF")
        if (t.startsWith("{") || t.startsWith("[")) return parseJson(t)
        val plain = t.contains("://")
        val text = if (plain) t else runCatching { Parser.b64(t) }.getOrDefault(t)
        val links = text.lines().map { it.trim() }.filter { Parser.nameOf(it) != null }
        return Result(if (plain) "список ключей" else "base64-список", links)
    }

    private fun parseJson(t: String): Result = try {
        val out = mutableListOf<String>()
        if (t.startsWith("{")) {
            val o = JSONObject(t)
            val arr = o.optJSONArray("outbounds")
            if (arr != null) {
                var singbox = false
                for (i in 0 until arr.length()) {
                    val ob = arr.optJSONObject(i) ?: continue
                    if (ob.optString("type") in proxyTypes) { out.add("json:$ob"); singbox = true }
                }
                if (!singbox) xray(o)?.let { out.add("json:$it") }
            }
            Result(if (out.isEmpty()) "JSON (не распознан)" else "JSON", out)
        } else {
            val a = JSONArray(t)
            for (i in 0 until a.length()) a.optJSONObject(i)?.let { xray(it) }?.let { out.add("json:$it") }
            Result("Xray JSON", out)
        }
    } catch (e: Exception) {
        Result("JSON-ошибка", emptyList())
    }

    private fun xray(cfg: JSONObject): JSONObject? {
        val name = cfg.optString("remarks").ifEmpty { cfg.optString("tag") }.ifEmpty { "server" }
        val obs = cfg.optJSONArray("outbounds") ?: return null
        for (i in 0 until obs.length()) {
            val ob = obs.optJSONObject(i) ?: continue
            val proto = ob.optString("protocol")
            if (proto !in setOf("vless", "vmess", "trojan", "shadowsocks")) continue
            val s = ob.optJSONObject("settings") ?: continue
            val st = ob.optJSONObject("streamSettings") ?: JSONObject()
            val o = JSONObject().put("type", proto).put("tag", name)
            when (proto) {
                "vless", "vmess" -> {
                    val v = s.getJSONArray("vnext").getJSONObject(0)
                    val u = v.getJSONArray("users").getJSONObject(0)
                    o.put("server", v.getString("address")).put("server_port", v.getInt("port")).put("uuid", u.getString("id"))
                    if (proto == "vless") {
                        u.optString("flow").takeIf { it.isNotEmpty() }?.let { o.put("flow", it) }
                        o.put("packet_encoding", "xudp")
                    } else {
                        o.put("security", u.optString("security", "auto")).put("alter_id", u.optInt("alterId", 0))
                    }
                }
                "trojan", "shadowsocks" -> {
                    val sv = s.getJSONArray("servers").getJSONObject(0)
                    o.put("server", sv.getString("address")).put("server_port", sv.getInt("port")).put("password", sv.getString("password"))
                    if (proto == "shadowsocks") o.put("method", sv.getString("method"))
                }
            }
            val sec = st.optString("security", "none")
            if (sec == "tls" || sec == "reality" || proto == "trojan") {
                val ts = st.optJSONObject(if (sec == "reality") "realitySettings" else "tlsSettings") ?: JSONObject()
                val t = JSONObject().put("enabled", true).put("server_name", ts.optString("serverName").ifEmpty { o.getString("server") })
                if (ts.optBoolean("allowInsecure")) t.put("insecure", true)
                ts.optJSONArray("alpn")?.let { t.put("alpn", it) }
                val fp = ts.optString("fingerprint")
                if (fp.isNotEmpty()) t.put("utls", JSONObject().put("enabled", true).put("fingerprint", fp))
                if (sec == "reality") {
                    t.put("reality", JSONObject().put("enabled", true).put("public_key", ts.optString("publicKey")).put("short_id", ts.optString("shortId")))
                    if (fp.isEmpty()) t.put("utls", JSONObject().put("enabled", true).put("fingerprint", "chrome"))
                }
                o.put("tls", t)
            }
            when (st.optString("network", "tcp")) {
                "ws" -> {
                    val w = st.optJSONObject("wsSettings") ?: JSONObject()
                    val tr = JSONObject().put("type", "ws").put("path", w.optString("path", "/"))
                    val host = w.optJSONObject("headers")?.optString("Host").orEmpty().ifEmpty { w.optString("host") }
                    if (host.isNotEmpty()) tr.put("headers", JSONObject().put("Host", host))
                    o.put("transport", tr)
                }
                "grpc" -> o.put("transport", JSONObject().put("type", "grpc").put("service_name", st.optJSONObject("grpcSettings")?.optString("serviceName").orEmpty()))
                "httpupgrade" -> {
                    val w = st.optJSONObject("httpupgradeSettings") ?: JSONObject()
                    o.put("transport", JSONObject().put("type", "httpupgrade").put("path", w.optString("path", "/")).put("host", w.optString("host")))
                }
            }
            return o
        }
        return null
    }
}
