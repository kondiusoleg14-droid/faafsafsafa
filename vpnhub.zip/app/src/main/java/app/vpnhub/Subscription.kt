package app.vpnhub

import org.json.JSONArray
import org.json.JSONObject

object Subscription {
    class Result(val format: String, val links: List<String>)

    private val proxyTypes = setOf("vless", "vmess", "trojan", "shadowsocks", "hysteria2", "hysteria", "tuic", "anytls")

    fun parse(body: String): Result {
        val t = body.trim().removePrefix("\uFEFF")
        if (t.startsWith("{") || t.startsWith("[")) return parseJson(t)
        val plain = t.contains("://")
        val text = if (plain) t else runCatching { Parser.b64(t) }.getOrDefault(t)
        val links = text.lines().map { it.trim() }.filter { Parser.nameOf(it) != null }
        return Result(if (plain) "список ключей" else "base64-список", links)
    }

    /** Один «сервер» из нескольких ключей (как в Happ): если ключ один — обычный outbound, если несколько — multi. */
    private fun multi(name: String, list: List<JSONObject>): JSONObject? = when {
        list.isEmpty() -> null
        list.size == 1 -> list[0].put("tag", name)
        else -> JSONObject().put("multi", true).put("tag", name).put("outbounds", JSONArray(list))
    }

    private fun configName(cfg: JSONObject): String =
        cfg.optString("remarks").ifEmpty { cfg.optString("tag") }.ifEmpty { cfg.optString("name") }.ifEmpty { "server" }

    private fun configToServer(cfg: JSONObject): JSONObject? {
        val arr = cfg.optJSONArray("outbounds") ?: return null
        val sb = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.filter { it.optString("type") in proxyTypes }
        return if (sb.isNotEmpty()) multi(configName(cfg), sb) else xray(cfg)
    }

    private fun parseJson(t: String): Result = try {
        val out = mutableListOf<String>()
        if (t.startsWith("{")) {
            val o = JSONObject(t)
            val arr = o.optJSONArray("outbounds")
            if (arr != null) {
                var singbox = false
                for (i in 0 until arr.length()) {
                    val ob = arr.optJSONObject(i) ?: continue
                    if (ob.optString("type") in proxyTypes) { out.add("json:$ob"); singbox = true }
                }
                if (!singbox) xray(o)?.let { out.add("json:$it") }
            }
            Result(if (out.isEmpty()) "JSON (не распознан)" else "JSON", out)
        } else {
            val a = JSONArray(t)
            for (i in 0 until a.length()) a.optJSONObject(i)?.let { configToServer(it) }?.let { out.add("json:$it") }
            Result("JSON-конфиги", out)
        }
    } catch (e: Exception) {
        Result("JSON-ошибка", emptyList())
    }

    private fun xray(cfg: JSONObject): JSONObject? {
        val name = configName(cfg)
        val obs = cfg.optJSONArray("outbounds") ?: return null
        val list = mutableListOf<JSONObject>()
        for (i in 0 until obs.length()) obs.optJSONObject(i)?.let { runCatching { xrayOutbound(it, name) }.getOrNull() }?.let { list.add(it) }
        return multi(name, list)
    }

    private fun xrayOutbound(ob: JSONObject, name: String): JSONObject? {
        val proto = ob.optString("protocol")
        if (proto !in setOf("vless", "vmess", "trojan", "shadowsocks", "hysteria")) return null
        val s = ob.optJSONObject("settings") ?: return null
        val st = ob.optJSONObject("streamSettings") ?: JSONObject()
        val isHy = proto == "hysteria"
        val o = JSONObject().put("type", if (isHy) "hysteria2" else proto).put("tag", name)
        when (proto) {
            "vless", "vmess" -> {
                val (addr, port, u) = if (s.has("vnext")) {
                    val v = s.getJSONArray("vnext").getJSONObject(0)
                    Triple(v.getString("address"), v.getInt("port"), v.getJSONArray("users").getJSONObject(0))
                } else Triple(s.getString("address"), s.getInt("port"), s)
                o.put("server", addr).put("server_port", port).put("uuid", u.getString("id"))
                if (proto == "vless") {
                    u.optString("flow").takeIf { it.isNotEmpty() }?.let { o.put("flow", it) }
                    o.put("packet_encoding", "xudp")
                } else {
                    o.put("security", u.optString("security", "auto")).put("alter_id", u.optInt("alterId", 0))
                }
            }
            "trojan", "shadowsocks" -> {
                val sv = if (s.has("servers")) s.getJSONArray("servers").getJSONObject(0) else s
                o.put("server", sv.getString("address")).put("server_port", sv.getInt("port")).put("password", sv.getString("password"))
                if (proto == "shadowsocks") o.put("method", sv.getString("method"))
            }
            "hysteria" -> {
                o.put("server", s.getString("address")).put("server_port", s.getInt("port"))
                o.put("password", st.optJSONObject("hysteriaSettings")?.optString("auth").orEmpty())
            }
        }
        val sec = st.optString("security", "none")
        if (sec == "tls" || sec == "reality" || proto == "trojan" || isHy) {
            val ts = st.optJSONObject(if (sec == "reality") "realitySettings" else "tlsSettings") ?: JSONObject()
            val t = JSONObject().put("enabled", true).put("server_name", ts.optString("serverName").ifEmpty { o.getString("server") })
            if (ts.optBoolean("allowInsecure")) t.put("insecure", true)
            ts.optJSONArray("alpn")?.let { t.put("alpn", it) }
            val fp = ts.optString("fingerprint")
            if (fp.isNotEmpty() && !isHy) t.put("utls", JSONObject().put("enabled", true).put("fingerprint", fp))
            if (sec == "reality") {
                t.put("reality", JSONObject().put("enabled", true).put("public_key", ts.optString("publicKey")).put("short_id", ts.optString("shortId")))
                if (fp.isEmpty()) t.put("utls", JSONObject().put("enabled", true).put("fingerprint", "chrome"))
            }
            o.put("tls", t)
        }
        if (!isHy) when (st.optString("network", "tcp")) {
            "ws" -> {
                val w = st.optJSONObject("wsSettings") ?: JSONObject()
                val tr = JSONObject().put("type", "ws").put("path", w.optString("path", "/"))
                val host = w.optJSONObject("headers")?.optString("Host").orEmpty().ifEmpty { w.optString("host") }
                if (host.isNotEmpty()) tr.put("headers", JSONObject().put("Host", host))
                o.put("transport", tr)
            }
            "grpc" -> o.put("transport", JSONObject().put("type", "grpc").put("service_name", st.optJSONObject("grpcSettings")?.optString("serviceName").orEmpty()))
            "httpupgrade" -> {
                val w = st.optJSONObject("httpupgradeSettings") ?: JSONObject()
                o.put("transport", JSONObject().put("type", "httpupgrade").put("path", w.optString("path", "/")).put("host", w.optString("host")))
            }
        }
        return o
    }
}
