package app.vpnhub

import android.content.Context
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.unit.dp
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.security.SecureRandom

/** Как clickable, но на ТВ при наведении пультом рисует заметную рамку. */
fun Modifier.tvClickable(onClick: () -> Unit): Modifier = composed {
    var f by remember { mutableStateOf(false) }
    this.onFocusChanged { f = it.isFocused }
        .then(if (f && Ui.tv) Modifier.border(3.dp, Ui.pal.text, RoundedCornerShape(14.dp)) else Modifier)
        .clickable(onClick = onClick)
}

/**
 * «Добавить с телефона»: на время открытого диалога ТВ поднимает маленький сайт в домашней сети.
 * Открываешь адрес с телефона, вводишь ПИН с экрана ТВ и вставляешь ключ/подписку — не нужно печатать пультом.
 */
object Remote {
    var inbox by mutableStateOf<String?>(null)
    var url by mutableStateOf("")
    var pin by mutableStateOf("")
    @Volatile private var server: ServerSocket? = null
    @Volatile private var attempts = 0

    fun start(ctx: Context) {
        if (server != null) return
        attempts = 0
        pin = (1000 + SecureRandom().nextInt(9000)).toString()
        val ss = runCatching { ServerSocket(8080) }.getOrNull() ?: runCatching { ServerSocket(0) }.getOrNull() ?: return
        server = ss
        url = "http://" + (localIp() ?: "IP-телевизора") + ":" + ss.localPort
        Thread {
            while (!ss.isClosed) {
                val c = runCatching { ss.accept() }.getOrNull() ?: break
                runCatching { handle(c) }
                runCatching { c.close() }
            }
        }.start()
    }

    fun stop() {
        runCatching { server?.close() }
        server = null
        url = ""
        pin = ""
    }

    private fun handle(c: Socket) {
        c.soTimeout = 5000
        val inp = c.getInputStream().bufferedReader(Charsets.ISO_8859_1)
        val first = inp.readLine() ?: return
        var len = 0
        while (true) {
            val h = inp.readLine() ?: break
            if (h.isEmpty()) break
            if (h.startsWith("content-length:", ignoreCase = true)) len = h.substringAfter(':').trim().toIntOrNull() ?: 0
        }
        val out = c.getOutputStream()
        if (first.startsWith("POST") && len in 1..20000) {
            val buf = CharArray(len)
            var n = 0
            while (n < len) { val r = inp.read(buf, n, len - n); if (r < 0) break; n += r }
            val form = String(buf, 0, n).split('&').associate { it.substringBefore('=') to URLDecoder.decode(it.substringAfter('=', ""), "UTF-8") }
            val text = form["text"]?.trim().orEmpty()
            when {
                attempts >= 10 -> send(out, 429, page("Слишком много попыток. Закрой окно на ТВ и открой заново."))
                form["pin"]?.trim() != pin -> { attempts++; send(out, 403, page("Неверный ПИН. Проверь цифры на экране ТВ.", true)) }
                text.isEmpty() -> send(out, 400, page("Пусто. Вставь ключ или ссылку подписки.", true))
                else -> { inbox = text; send(out, 200, page("Готово ✅ Отправлено на ТВ.")) }
            }
        } else send(out, 200, page(null, true))
    }

    private fun page(msg: String?, form: Boolean = false): String {
        val m = if (msg != null) "<p><b>$msg</b></p>" else ""
        val f = if (form || msg == null)
            "<form method=post><p>ПИН с экрана ТВ:<br><input name=pin inputmode=numeric style='font-size:22px;width:100%'></p>" +
                "<p>Ключ или ссылка подписки:<br><textarea name=text rows=6 style='font-size:16px;width:100%'></textarea></p>" +
                "<button style='font-size:20px;padding:10px 24px'>Отправить</button></form>"
        else ""
        return "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>" +
            "<body style='font-family:sans-serif;max-width:560px;margin:20px auto;padding:0 14px'><h2>VPN Hub — добавить на ТВ</h2>$m$f</body>"
    }

    private fun send(out: OutputStream, code: Int, html: String) {
        val b = html.toByteArray(Charsets.UTF_8)
        out.write("HTTP/1.1 $code OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${b.size}\r\nConnection: close\r\n\r\n".toByteArray(Charsets.ISO_8859_1))
        out.write(b)
        out.flush()
    }

    private fun localIp(): String? {
        val c = ArrayList<Pair<String, String>>()
        runCatching {
            for (ni in NetworkInterface.getNetworkInterfaces().toList()) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name.lowercase()
                if (n.startsWith("tun") || n.startsWith("rmnet") || n.startsWith("ppp") || n.startsWith("dummy")) continue
                for (a in ni.inetAddresses.toList()) if (a is Inet4Address && !a.isLoopbackAddress) c.add(n to (a.hostAddress ?: ""))
            }
        }
        return (c.firstOrNull { it.first.startsWith("wlan") || it.first.startsWith("eth") } ?: c.firstOrNull())?.second
    }
}
