package app.vpnhub

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/** Смена иконки приложения: включаем один из алиасов лаунчера (IconDefault / IconFem / IconMk). */
object AppIcon {
    private val aliases = linkedMapOf("default" to "IconDefault", "fem" to "IconFem", "mk" to "IconMk")

    fun effective(): String = when (Ui.iconMode) {
        "default", "fem", "mk" -> Ui.iconMode
        else -> if (Ui.femboy) "fem" else if (Ui.scorpion) "mk" else "default"
    }

    fun apply(ctx: Context) {
        runCatching {
            val want = effective()
            val pm = ctx.packageManager
            fun cn(n: String) = ComponentName(ctx.packageName, "app.vpnhub.$n")
            // сначала включаем нужный, потом выключаем остальные — лаунчер не остаётся без иконки
            for ((k, n) in aliases) {
                if (k == want && pm.getComponentEnabledSetting(cn(n)) != PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
                    pm.setComponentEnabledSetting(cn(n), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            }
            for ((k, n) in aliases) {
                if (k != want && pm.getComponentEnabledSetting(cn(n)) != PackageManager.COMPONENT_ENABLED_STATE_DISABLED)
                    pm.setComponentEnabledSetting(cn(n), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            }
        }
    }
}
