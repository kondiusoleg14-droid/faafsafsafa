# VPN Hub (Android)
Приложение-оболочка вокруг sing-box: одна кнопка, ключи и подписки (vless/vmess/trojan/ss/hysteria2),
выбор сервера для каждого приложения.
Сборка: GitHub → Actions → Build APK → Run workflow → внизу Artifacts → VpnHub-apk.
